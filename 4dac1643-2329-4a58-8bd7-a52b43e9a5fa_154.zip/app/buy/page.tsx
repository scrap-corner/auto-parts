
'use client';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useLanguage } from '../../components/LanguageProvider';

export default function Buy() {
  const router = useRouter();
  const { language, t, isRTL, theme } = useLanguage();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('');
  const [selectedModel, setSelectedModel] = useState('');
  const [selectedYear, setSelectedYear] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('');
  const [showCountryModal, setShowCountryModal] = useState(false);
  const [showBrandModal, setShowBrandModal] = useState(false);
  const [showModelModal, setShowModelModal] = useState(false);
  const [showYearModal, setShowYearModal] = useState(false);

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';
    if (!loggedIn) {
      sessionStorage.setItem('returnUrl', '/buy');
      router.push('/login');
      return;
    }
    setIsLoggedIn(true);

    const savedCountry = localStorage.getItem('selectedCountry') || 'OM';
    setSelectedCountry(savedCountry);
  }, [router]);

  const countries = [
    { code: 'OM', name: language === 'ar' ? 'عُمان' : 'Oman', flag: '🇴🇲', currency: language === 'ar' ? 'ريال عماني' : 'OMR' },
    { code: 'SA', name: language === 'ar' ? 'السعودية' : 'Saudi Arabia', flag: '🇸🇦', currency: language === 'ar' ? 'ریال سعودی' : 'SAR' },
    { code: 'AE', name: language === 'ar' ? 'الإمارات' : 'UAE', flag: '🇦🇪', currency: language === 'ar' ? 'درهم إماراتي' : 'AED' },
    { code: 'KW', name: language === 'ar' ? 'الكويت' : 'Kuwait', flag: '🇰🇼', currency: language === 'ar' ? 'دينار كويتي' : 'KWD' },
    { code: 'QA', name: language === 'ar' ? 'قطر' : 'Qatar', flag: '🇶🇦', currency: language === 'ar' ? 'ریال قطری' : 'QAR' },
    { code: 'BH', name: language === 'ar' ? 'البحرين' : 'Bahrain', flag: '🇧🇭', currency: language === 'ar' ? 'دينار بحريني' : 'BHD' }
  ];

  const categories = [
    { id: 'engine', name: language === 'ar' ? 'أجزاء المحرك' : 'Engine Parts', icon: 'ri-settings-4-fill', color: 'text-blue-500' },
    { id: 'brakes', name: language === 'ar' ? 'فرامل' : 'Brakes', icon: 'ri-stop-circle-fill', color: 'text-red-500' },
    { id: 'tires', name: language === 'ar' ? 'إطارات' : 'Tires', icon: 'ri-steering-2-fill', color: 'text-green-500' },
    { id: 'lights', name: language === 'ar' ? 'أنوار' : 'Lights', icon: 'ri-lightbulb-fill', color: 'text-yellow-500' },
    { id: 'ac', name: language === 'ar' ? 'تكييف' : 'AC System', icon: 'ri-temp-cold-fill', color: 'text-cyan-500' },
    { id: 'transmission', name: language === 'ar' ? 'ناقل حركة' : 'Transmission', icon: 'ri-roadster-fill', color: 'text-purple-500' },
    { id: 'suspension', name: language === 'ar' ? 'تعليق' : 'Suspension', icon: 'ri-car-washing-fill', color: 'text-indigo-500' },
    { id: 'exhaust', name: language === 'ar' ? 'عادم' : 'Exhaust', icon: 'ri-fire-fill', color: 'text-gray-500' },
    { id: 'body', name: language === 'ar' ? 'بودي' : 'Body Parts', icon: 'ri-car-fill', color: 'text-orange-500' }
  ];

  const carBrands = [
    { id: 'toyota', name: language === 'ar' ? 'تويوتا' : 'Toyota' },
    { id: 'nissan', name: language === 'ar' ? 'نيسان' : 'Nissan' },
    { id: 'hyundai', name: language === 'ar' ? 'هيونداي' : 'Hyundai' },
    { id: 'honda', name: language === 'ar' ? 'هوندا' : 'Honda' },
    { id: 'ford', name: language === 'ar' ? 'فورد' : 'Ford' },
    { id: 'chevrolet', name: language === 'ar' ? 'شيفروليه' : 'Chevrolet' },
    { id: 'kia', name: language === 'ar' ? 'كيا' : 'KIA' },
    { id: 'bmw', name: language === 'ar' ? 'بي إم دبليو' : 'BMW' },
    { id: 'mercedes', name: language === 'ar' ? 'مرسيدس' : 'Mercedes-Benz' },
    { id: 'lexus', name: language === 'ar' ? 'لكزس' : 'Lexus' },
    { id: 'mazda', name: language === 'ar' ? 'مازدا' : 'Mazda' },
    { id: 'volkswagen', name: language === 'ar' ? 'فولكس فاجن' : 'Volkswagen' },
    { id: 'audi', name: language === 'ar' ? 'أودي' : 'Audi' },
    { id: 'mitsubishi', name: language === 'ar' ? 'ميتسوبيشي' : 'Mitsubishi' },
    { id: 'subaru', name: language === 'ar' ? 'سوبارو' : 'Subaru' },
    { id: 'infiniti', name: language === 'ar' ? 'إنفينيتي' : 'Infiniti' },
    { id: 'acura', name: language === 'ar' ? 'أكورا' : 'Acura' },
    { id: 'suzuki', name: language === 'ar' ? 'سوزوكي' : 'Suzuki' },
    { id: 'isuzu', name: language === 'ar' ? 'إيسوزو' : 'Isuzu' },
    { id: 'jeep', name: language === 'ar' ? 'جيب' : 'Jeep' },
    { id: 'dodge', name: language === 'ar' ? 'دودج' : 'Dodge' },
    { id: 'chrysler', name: language === 'ar' ? 'كرايسلر' : 'Chrysler' },
    { id: 'cadillac', name: language === 'ar' ? 'كاديلاك' : 'Cadillac' },
    { id: 'gmc', name: language === 'ar' ? 'جی إم سی' : 'GMC' },
    { id: 'buick', name: language === 'ar' ? 'بويك' : 'Buick' },
    { id: 'lincoln', name: language === 'ar' ? 'لينكولن' : 'Lincoln' },
    { id: 'jaguar', name: language === 'ar' ? 'جاكوار' : 'Jaguar' },
    { id: 'landrover', name: language === 'ar' ? 'لاند روفر' : 'Land Rover' },
    { id: 'volvo', name: language === 'ar' ? 'فولفو' : 'Volvo' },
    { id: 'peugeot', name: language === 'ar' ? 'بيجو' : 'Peugeot' },
    { id: 'renault', name: language === 'ar' ? 'رينو' : 'Renault' },
    { id: 'citroen', name: language === 'ar' ? 'ستروين' : 'Citroen' },
    { id: 'fiat', name: language === 'ar' ? 'فيات' : 'Fiat' },
    { id: 'alfa', name: language === 'ar' ? 'ألفا روميو' : 'Alfa Romeo' },
    { id: 'maserati', name: language === 'ar' ? 'مازيراتي' : 'Maserati' },
    { id: 'ferrari', name: language === 'ar' ? 'فيراري' : 'Ferrari' },
    { id: 'lamborghini', name: language === 'ar' ? 'لامبورجيني' : 'Lamborghini' },
    { id: 'bentley', name: language === 'ar' ? 'بنتلي' : 'Bentley' },
    { id: 'rollsroyce', name: language === 'ar' ? 'رولز رويس' : 'Rolls-Royce' },
    { id: 'porsche', name: language === 'ar' ? 'بورش' : 'Porsche' },
    { id: 'mini', name: language === 'ar' ? 'ميني' : 'MINI' },
    { id: 'smart', name: language === 'ar' ? 'سمارت' : 'Smart' },
    { id: 'skoda', name: language === 'ar' ? 'سكودا' : 'Skoda' },
    { id: 'seat', name: language === 'ar' ? 'سيات' : 'SEAT' },
    { id: 'opel', name: language === 'ar' ? 'أوبل' : 'Opel' },
    { id: 'geely', name: language === 'ar' ? 'جيلي' : 'Geely' },
    { id: 'chery', name: language === 'ar' ? 'شيري' : 'Chery' },
    { id: 'byd', name: language === 'ar' ? 'بي واي دي' : 'BYD' },
    { id: 'great_wall', name: language === 'ar' ? 'جريت وول' : 'Great Wall' },
    { id: 'haval', name: language === 'ar' ? 'هافال' : 'Haval' },
    { id: 'mg', name: language === 'ar' ? 'إم جی' : 'MG' },
    { id: 'jac', name: language === 'ar' ? 'جاك' : 'JAC' }
  ];

  const carModels = {
    toyota: language === 'ar' ? ['كامري', 'كورولا', 'أفالون', 'هايلاندر', 'برادو', 'راف4', 'فورتشنر', 'يارس', 'لاندكروزر', 'سي إتش آر', 'سوبرا', 'أفينسيس', 'فينزا', 'سيكويا', 'سيينا', 'تاكوما', 'تندرا', 'أوريس', 'إي تي إس', 'إيجو'] : ['Camry', 'Corolla', 'Avalon', 'Highlander', 'Prado', 'RAV4', 'Fortuner', 'Yaris', 'Land Cruiser', 'C-HR', 'Supra', 'Avensis', 'Venza', 'Sequoia', 'Sienna', 'Tacoma', 'Tundra', 'Auris', 'ETS', 'Aygo'],
    nissan: language === 'ar' ? ['ألتيما', 'سنترا', 'باترول', 'إكس تريل', 'كيك', 'مورانو', 'آرميدا', 'صني', 'تيتان', 'فرونتير', 'ماكسيما', 'روج', 'فيرسا', 'جوك', 'كاشكاي', 'باثفايندر', 'نافارا', 'ميكرا', 'تيدا', 'نوت'] : ['Altima', 'Sentra', 'Patrol', 'X-Trail', 'Kicks', 'Murano', 'Armada', 'Sunny', 'Titan', 'Frontier', 'Maxima', 'Rogue', 'Versa', 'Juke', 'Qashqai', 'Pathfinder', 'Navara', 'Micra', 'Tiida', 'Note'],
    hyundai: language === 'ar' ? ['النترا', 'سوناتا', 'توكسون', 'سانتافي', 'أكسنت', 'كونا', 'كريتا', 'فيلوستر', 'جينيسيس', 'أيونيك', 'فيراكروز', 'إكس جي', 'أزيرا', 'جيتز', 'ماتريكس', 'فيرنا', 'جراند إي 10', 'إتش 1'] : ['Elantra', 'Sonata', 'Tucson', 'Santa Fe', 'Accent', 'Kona', 'Creta', 'Veloster', 'Genesis', 'Ioniq', 'Veracruz', 'XG', 'Azera', 'Getz', 'Matrix', 'Verna', 'Grand i10', 'H1'],
    honda: language === 'ar' ? ['أكورد', 'سيفيك', 'سي آر في', 'بايلوت', 'سيتي', 'فيت', 'إتش آر في', 'أوديسي', 'ريدجلاين', 'باسبورت', 'إنسايت', 'كروس تور', 'إليمنت', 'إس 2000', 'بروتيج', 'إن إس إكس', 'ريدجلاين'] : ['Accord', 'Civic', 'CR-V', 'Pilot', 'City', 'Fit', 'HR-V', 'Odyssey', 'Ridgeline', 'Passport', 'Insight', 'Crosstour', 'Element', 'S2000', 'Prelude', 'NSX', 'Ridgeline'],
    ford: language === 'ar' ? ['فوكس', 'إكسبلورر', 'إكسبيديشن', 'إف 150', 'موستانج', 'فيوجن', 'إسكايب', 'إيدج', 'رامجر', 'برونكو', 'إيكو سبورت', 'فييستا', 'إكسكورشن', 'تورينو', 'كاونفيروس', 'ويندستار', 'إف 250', 'إف 350'] : ['Focus', 'Explorer', 'Expedition', 'F-150', 'Mustang', 'Fusion', 'Escape', 'Edge', 'Ranger', 'Bronco', 'EcoSport', 'Fiesta', 'Excursion', 'Torino', 'Crown Victoria', 'Freestar', 'Windstar', 'F-250', 'F-350'],
    chevrolet: language === 'ar' ? ['كامارو', 'كورفيت', 'إكوينوكس', 'تاهو', 'سيلفرادو', 'ماليبو', 'إمبالا', 'كروز', 'سبارك', 'تريل بليزر', 'سابربان', 'أفيو', 'كابتيفا', 'إكسبريس', 'كولورادو', 'أوبترا', 'إبيكا', 'لومينا'] : ['Camaro', 'Corvette', 'Equinox', 'Tahoe', 'Silverado', 'Malibu', 'Impala', 'Cruze', 'Spark', 'Trailblazer', 'Suburban', 'Aveo', 'Captiva', 'Express', 'Colorado', 'Optra', 'Epica', 'Lumina'],
    kia: language === 'ar' ? ['أوبتيما', 'ريو', 'سورينتو', 'سبورتاج', 'سيراتو', 'بيكانتو', 'كادينزا', 'سولتو', 'كارنيفال', 'نيرو', 'ستينجر', 'سيد', 'موهاف', 'سولوتو', 'فورت', 'روندو', 'سبيكترا', 'أمانتي', 'سيفيا'] : ['Optima', 'Rio', 'Sorento', 'Sportage', 'Cerato', 'Picanto', 'Cadenza', 'Soul', 'Carnival', 'Niro', 'Stinger', 'Ceed', 'Mohave', 'Soluto', 'Forte', 'Rondo', 'Spectra', 'Amanti', 'Sephia'],
    bmw: language === 'ar' ? ['الفئة الثالثة', 'الفئة الخامسة', 'الفئة السابعة', 'إكس 1', 'إكس 3', 'إكس 5', 'إكس 6', 'إكس 7', 'الفئة الأولى', 'الفئة الثانية', 'الفئة الرابعة', 'الفئة السادسة', 'الفئة الثامنة', 'زد 3', 'زد 4', 'زد 8', 'إم 2', 'إم 3', 'إم 4', 'إم 5'] : ['3 Series', '5 Series', '7 Series', 'X1', 'X3', 'X5', 'X6', 'X7', '1 Series', '2 Series', '4 Series', '6 Series', '8 Series', 'Z3', 'Z4', 'Z8', 'M2', 'M3', 'M4', 'M5'],
    mercedes: language === 'ar' ? ['الفئة سي', 'الفئة إي', 'الفئة إس', 'جي إل إيه', 'جي إل سي', 'جي إل إي', 'جي إل إس', 'الفئة أيه', 'الفئة بي', 'سي إل إس', 'سي إل كي', 'إس إل كي', 'إس إل', 'جي', 'في', 'سي إل', 'إم إل', 'جي إل', 'أر'] : ['C-Class', 'E-Class', 'S-Class', 'GLA', 'GLC', 'GLE', 'GLS', 'A-Class', 'B-Class', 'CLS', 'CLK', 'SLK', 'SL', 'G-Class', 'V-Class', 'CL', 'ML', 'GL', 'R-Class'],
    lexus: language === 'ar' ? ['إي إس', 'إل إس', 'جي إس', 'آر إكس', 'جي إكس', 'إل إكس', 'إن إكس', 'يو إكس', 'إل سي', 'آر سي', 'إس سي', 'إي إكس', 'سي تي', 'آي إس', 'هاي برد', 'إل إف إيه', 'إل سي إف'] : ['ES', 'LS', 'GS', 'RX', 'GX', 'LX', 'NX', 'UX', 'LC', 'RC', 'SC', 'EX', 'CT', 'IS', 'Hybrid', 'LFA', 'LCF'],
    mazda: language === 'ar' ? ['مازدا 3', 'مازدا 6', 'سي إكس 3', 'سي إكس 5', 'سي إكس 9', 'إم إكس 5', 'مازدا 2', 'بي تي 50', 'مازدا 5', 'سي إكس 7', 'آر إكس 7', 'آر إكس 8', 'مازدا 323', 'مازدا 626', 'مازدا 929', 'ميلينيا', 'بروتيج', 'تريبيوت'] : ['Mazda 3', 'Mazda 6', 'CX-3', 'CX-5', 'CX-9', 'MX-5', 'Mazda 2', 'BT-50', 'Mazda 5', 'CX-7', 'RX-7', 'RX-8', 'Mazda 323', 'Mazda 626', 'Mazda 929', 'Millenia', 'Protege', 'Tribute'],
    volkswagen: language === 'ar' ? ['جولف', 'باسات', 'جيتا', 'تيجوان', 'توران', 'أطلس', 'أرتيون', 'بولو', 'تي كروس', 'أماروك', 'شاران', 'كادي', 'بيتل', 'فايتون', 'تي 5', 'كروسبر', 'جولف سبورت فاجن', 'بولو سيدان'] : ['Golf', 'Passat', 'Jetta', 'Tiguan', 'Touran', 'Atlas', 'Arteon', 'Polo', 'T-Cross', 'Amarok', 'Sharan', 'Caddy', 'Beetle', 'Phaeton', 'T5', 'Crafter', 'Golf SportWagen', 'Polo Sedan'],
    audi: language === 'ar' ? ['أيه 3', 'أيه 4', 'أيه 6', 'أيه 8', 'كيو 3', 'كيو 5', 'كيو 7', 'كيو 8', 'تي تي', 'آر 8', 'أيه 1', 'أيه 2', 'أيه 5', 'أيه 7', 'كيو 2', 'إي ترون', 'آر إس 3', 'آر إس 4', 'آر إس 5', 'آر إس 6'] : ['A3', 'A4', 'A6', 'A8', 'Q3', 'Q5', 'Q7', 'Q8', 'TT', 'R8', 'A1', 'A2', 'A5', 'A7', 'Q2', 'e-tron', 'RS3', 'RS4', 'RS5', 'RS6'],
    mitsubishi: language === 'ar' ? ['لانسر', 'إكليبس كروس', 'أوتلاندر', 'باجيرو', 'إل 200', 'أي إس إكس', 'مايتي', 'أتراج', 'غالانت', 'إكليبس', 'مونتيرو', 'ديامانت', 'لانسر إيفو', 'ميراج', 'إنديفور', 'تشالنجر', 'غراندس'] : ['Lancer', 'Eclipse Cross', 'Outlander', 'Pajero', 'L200', 'ASX', 'Mighty', 'Attrage', 'Galant', 'Eclipse', 'Montero', 'Diamante', 'Lancer Evo', 'Mirage', 'Endeavor', 'Challenger', 'Grandis'],
    subaru: language === 'ar' ? ['إمبريزا', 'فورستر', 'أوتباك', 'ليجاسي', 'إكس في', 'أسنت', 'تريبيكا', 'جاستي', 'ليبرو', 'إس في إكس', 'بي آر زد', 'دبليو آر إكس'] : ['Impreza', 'Forester', 'Outback', 'Legacy', 'XV', 'Ascent', 'Tribeca', 'Justy', 'Libero', 'SVX', 'BRZ', 'WRX'],
    infiniti: language === 'ar' ? ['كيو 50', 'كيو 60', 'كيو إكس 50', 'كيو إكس 60', 'كيو إكس 70', 'كيو إكس 80', 'جي 35', 'جي 37', 'إم 35', 'إم 45', 'إف إكس 35', 'إف إكس 45', 'كيو 30', 'كيو 40'] : ['Q50', 'Q60', 'QX50', 'QX60', 'QX70', 'QX80', 'G35', 'G37', 'M35', 'M45', 'FX35', 'FX45', 'Q30', 'Q40'],
    acura: language === 'ar' ? ['تي إل إكس', 'آي إل إكس', 'آر إل إكس', 'آر دي إكس', 'إم دي إكس', 'إن إس إكس', 'تي إل', 'آر إل', 'سي إل', 'إنتغرا', 'ليجند', 'فيجور', 'تي إس إكس'] : ['TLX', 'ILX', 'RLX', 'RDX', 'MDX', 'NSX', 'TL', 'RL', 'CL', 'Integra', 'Legend', 'Vigor', 'TSX'],
    suzuki: language === 'ar' ? ['سويفت', 'فيتارا', 'جيمني', 'بالينو', 'سيليريو', 'إس كروس', 'إكس إل 7', 'ألتو', 'واغون آر', 'لانا', 'آر إم زد 4', 'جراند فيتارا', 'كيزاشي', 'سيدكيك'] : ['Swift', 'Vitara', 'Jimny', 'Baleno', 'Celerio', 'S-Cross', 'XL7', 'Alto', 'Wagon R', 'Liana', 'RMZ4', 'Grand Vitara', 'Kizashi', 'Sidekick'],
    isuzu: language === 'ar' ? ['دي ماكس', 'مو إكس', 'تروبر', 'رودو', 'إن بي آر', 'إف آر آر', 'إلف', 'فوروارد', 'جيميني', 'أسكندر', 'فيهي كروس', 'إمبولز'] : ['D-Max', 'MU-X', 'Trooper', 'Rodeo', 'NPR', 'FRR', 'Elf', 'Forward', 'Gemini', 'Ascender', 'VehiCross', 'Impulse'],
    jeep: language === 'ar' ? ['رانجلر', 'جراند شيروكي', 'شيروكي', 'كومباس', 'رينيجيد', 'جلاديتور', 'باتريوت', 'ليبرتي', 'كوماندر', 'جراند واغونير'] : ['Wrangler', 'Grand Cherokee', 'Cherokee', 'Compass', 'Renegade', 'Gladiator', 'Patriot', 'Liberty', 'Commander', 'Grand Wagoneer'],
    dodge: language === 'ar' ? ['تشالنجر', 'تشارجر', 'دورانجو', 'جورني', 'كارافان', 'نيون', 'إنتريبد', 'ستراتوس', 'داكوتا', 'رام', 'نيترو', 'كاليبر', 'أفنجر'] : ['Challenger', 'Charger', 'Durango', 'Journey', 'Caravan', 'Neon', 'Intrepid', 'Stratus', 'Dakota', 'Ram', 'Nitro', 'Caliber', 'Avenger'],
    chrysler: language === 'ar' ? ['300', 'باسيفيكا', 'فويجر', 'سيبرينج', 'كونكورد', 'إل إتش إس', 'نيو يوركر', 'تاون كنتري', 'أسبن', 'كروس فاير', 'بي تي كروزر'] : ['300', 'Pacifica', 'Voyager', 'Sebring', 'Concorde', 'LHS', 'New Yorker', 'Town & Country', 'Aspen', 'Crossfire', 'PT Cruiser'],
    cadillac: language === 'ar' ? ['إسكاليد', 'سي تي إس', 'إيه تي إس', 'إكس تي إس', 'سي تي 5', 'سي تي 6', 'إس آر إكس', 'إكس تي 4', 'إكس تي 5', 'إكس تي 6', 'ديفيل', 'إلدورادو', 'سي تي سي', 'دي تي إس'] : ['Escalade', 'CTS', 'ATS', 'XTS', 'CT5', 'CT6', 'SRX', 'XT4', 'XT5', 'XT6', 'DeVille', 'Eldorado', 'CTC', 'DTS'],
    gmc: language === 'ar' ? ['سييرا', 'يوكون', 'أكاديا', 'تيرين', 'كانيون', 'سافانا', 'انفوي', 'جيمي', 'يوكون دينالي'] : ['Sierra', 'Yukon', 'Acadia', 'Terrain', 'Canyon', 'Savana', 'Envoy', 'Jimmy', 'Yukon Denali'],
    buick: language === 'ar' ? ['انكليف', 'انكور', 'انفيجن', 'لاكروس', 'ريجال', 'فيرانو', 'سكاي لارك', 'سنشري', 'ليساب', 'رينديفو'] : ['Enclave', 'Encore', 'Envision', 'LaCrosse', 'Regal', 'Verano', 'Skylark', 'Century', 'LeSabre', 'Rendezvous'],
    lincoln: language === 'ar' ? ['نافيجيتر', 'إسكاليد', 'إم كيه زد', 'إم كيه إكس', 'كورساير', 'آفياتور', 'كونتيننتال', 'إم كيه إس', 'تاون كار'] : ['Navigator', 'Escalade', 'MKZ', 'MKX', 'Corsair', 'Aviator', 'Continental', 'MKS', 'Town Car'],
    jaguar: language === 'ar' ? ['إكس إف', 'إكس جي', 'إكس إي', 'إف بيس', 'إي بيس', 'إف تايب', 'إكس كي', 'إكس جي آر', 'إس تايب', 'إكس تايب', 'أي بيس'] : ['XF', 'XJ', 'XE', 'F-Pace', 'E-Pace', 'F-Type', 'XK', 'XJR', 'S-Type', 'X-Type', 'I-Pace'],
    landrover: language === 'ar' ? ['رينج روفر', 'ديسكفري', 'إيفوك', 'فيلار', 'سبورت', 'فريلاندر', 'ديفندر', 'لاند روفر 90', 'لاند روفر 110'] : ['Range Rover', 'Discovery', 'Evoque', 'Velar', 'Sport', 'Freelander', 'Defender', 'Land Rover 90', 'Land Rover 110'],
    volvo: language === 'ar' ? ['إكس سي 60', 'إكس سي 90', 'إس 60', 'إس 90', 'في 40', 'في 60', 'في 90', 'إكس سي 40', 'سي 30', 'سي 70', 'إس 40', 'إس 80', 'إكس سي 70'] : ['XC60', 'XC90', 'S60', 'S90', 'V40', 'V60', 'V90', 'XC40', 'C30', 'C70', 'S40', 'S80', 'XC70'],
    peugeot: language === 'ar' ? ['208', '308', '508', '2008', '3008', '5008', '207', '307', '407', '607', '206', '306', '406', '807', '1007', 'بارتنر', 'بيبر'] : ['208', '308', '508', '2008', '3008', '5008', '207', '307', '407', '607', '206', '306', '406', '807', '1007', 'Partner', 'Bipper'],
    renault: language === 'ar' ? ['كليو', 'ميجان', 'لاجونا', 'سينيك', 'كابتور', 'كوليوس', 'داستر', 'لوجان', 'سانديرو', 'كانجو', 'ماستر', 'تاليسمان', 'كاديجار'] : ['Clio', 'Megane', 'Laguna', 'Scenic', 'Captur', 'Koleos', 'Duster', 'Logan', 'Sandero', 'Kangoo', 'Master', 'Talisman', 'Kadjar'],
    citroen: language === 'ar' ? ['سي 3', 'سي 4', 'سي 5', 'سي 6', 'بيكاسو', 'إكس سارا', 'بيرلينجو', 'سي كروسر', 'سي 1', 'سي 2', 'جامبر', 'سبيس تورير'] : ['C3', 'C4', 'C5', 'C6', 'Picasso', 'Xsara', 'Berlingo', 'C-Crosser', 'C1', 'C2', 'Jumper', 'SpaceTourer'],
    fiat: language === 'ar' ? ['500', 'باندا', 'بونتو', 'تيبو', 'براڤو', 'لينيا', 'أونو', 'سيينا', 'ستيلو', 'دوبلو', 'فريمونت', '500 إكس'] : ['500', 'Panda', 'Punto', 'Tipo', 'Bravo', 'Linea', 'Uno', 'Siena', 'Stilo', 'Doblo', 'Freemont', '500X'],
    alfa: language === 'ar' ? ['جوليتا', 'ميتو', 'جوليا', 'ستيلفيو', 'سبايدر', '159', '156', '147', '166', 'جی تی', 'بريرا', '4سی'] : ['Giulietta', 'MiTo', 'Giulia', 'Stelvio', 'Spider', '159', '156', '147', '166', 'GT', 'Brera', '4C'],
    maserati: language === 'ar' ? ['جيبلي', 'كواتروبورت', 'ليفانت', 'جران توریزمو', 'جران کابریو', 'جران اسپورت', '3200 جی تی', 'کوپه'] : ['Ghibli', 'Quattroporte', 'Levante', 'GranTurismo', 'GranCabrio', 'GranSport', '3200 GT', 'Coupe'],
    ferrari: language === 'ar' ? ['458', '488', 'إف 12', 'جتي سي 4', 'کالیفورنیا', 'برلینتا', 'دیتونا', 'تستاروزا', '360', 'انزو', 'لافيراری', 'إف إف'] : ['458', '488', 'F12', 'GTC4', 'California', 'Berlinetta', 'Daytona', 'Testarossa', '360', 'Enzo', 'LaFerrari', 'FF'],
    lamborghini: language === 'ar' ? ['هوراکان', 'آونتادور', 'یوروس', 'گالاردو', 'مورسیلاگو', 'دیابلو', 'کانتاب', 'میورا', 'اسپادا', 'جالپا'] : ['Huracan', 'Aventador', 'Urus', 'Gallardo', 'Murcielago', 'Diablo', 'Countach', 'Miura', 'Espada', 'Jalpa'],
    bentley: language === 'ar' ? ['کنتیننتال', 'فلاینگ اسپور', 'مولسان', 'بنتایگا', 'آرناج', 'آزور', 'بروک لندز', 'ترنر'] : ['Continental', 'Flying Spur', 'Mulsanne', 'Bentayga', 'Arnage', 'Azure', 'Brooklands', 'Turnier'],
    rollsroyce: language === 'ar' ? ['فانتوم', 'غوست', 'ریث', 'داون', 'کولینان', 'سیلور اسپور', 'سیلور کلاد', 'سیلور شدو'] : ['Phantom', 'Ghost', 'Wraith', 'Dawn', 'Cullinan', 'Silver Spur', 'Silver Cloud', 'Silver Shadow'],
    porsche: language === 'ar' ? ['911', 'کاین', 'ماکAN', 'پانامرا', 'تیکان', 'باکستر', 'کایمن', 'کاران جی تی', '918', '928', '944', '968'] : ['911', 'Cayenne', 'Macan', 'Panamera', 'Taycan', 'Boxster', 'Cayman', 'Carrera GT', '918', '928', '944', '968'],
    mini: language === 'ar' ? ['کوپر', 'کانتریمان', 'کلوبمن', 'پیسمن', 'کوپه', 'رودستر', 'جان کپر ورکز', 'هچ'] : ['Cooper', 'Countryman', 'Clubman', 'Paceman', 'Coupe', 'Roadster', 'John Cooper Works', 'Hatch'],
    smart: language === 'ar' ? ['فورتو', 'فورفور', 'رودستر', 'کراسبلید', 'ای کیو', 'سیتی کابریو'] : ['ForTwo', 'ForFour', 'Roadster', 'Crossblade', 'EQ', 'City Cabrio'],
    skoda: language === 'ar' ? ['اوکتاویا', 'فابیا', 'سوپرب', 'کدیاک', 'کاروک', 'اسکالا', 'کامیق', 'یتی', 'فلیسيا', 'رپید'] : ['Octavia', 'Fabia', 'Superb', 'Kodiaq', 'Karoq', 'Scala', 'Kamiq', 'Yeti', 'Felicia', 'Rapid'],
    seat: language === 'ar' ? ['لیون', 'ایμπیزا', 'اتیکا', 'آرونا', 'تاراکو', 'میی', 'آلتئا', 'کوردوبا', 'تولدو', 'آلامبرا'] : ['Leon', 'Ibiza', 'Ateca', 'Arona', 'Tarraco', 'Mii', 'Altea', 'Cordoba', 'Toledo', 'Alhambra'],
    opel: language === 'ar' ? ['آسترا', 'کورسا', 'انسیگنیا', 'موکا', 'کراسلند', 'گراندلند', 'زافیرا', 'مریوا', 'ویکترا', 'امگا'] : ['Astra', 'Corsa', 'Insignia', 'Mokka', 'Crossland', 'Grandland', 'Zafira', 'Meriva', 'Vectra', 'Omega'],
    geely: language === 'ar' ? ['إیمگرند', 'کولری', 'بویو', 'آtlas', 'تیگو', 'جی سی 6', 'جی سی 9', 'جی ایکس 7', 'وی الف 11'] : ['Emgrand', 'Coolray', 'Boyue', 'Atlas', 'Tiggo', 'GC6', 'GC9', 'GX7', 'VF11'],
    chery: language === 'ar' ? ['تیگو', 'آریزو', 'کی کیو', 'ای 5', 'فولوین', '액터코', 'اینی', 'فیس', 'ایکس 1', 'جی 5'] : ['Tiggo', 'Arrizo', 'QQ', 'E5', 'Fulwin', 'Acteco', 'Envy', 'Face', 'X1', 'G5'],
    byd: language === 'ar' ? ['تانگ', 'هان', 'سونگ', 'یوان', 'سلی', 'ای 3', 'ای 6', 'اس 6', 'اس 7', 'ای 6'] : ['Tang', 'Han', 'Song', 'Yuan', 'Sealy', 'F3', 'F6', 'S6', 'S7', 'E6'],
    great_wall: language === 'ar' ? ['هوفر', 'وینگل', 'سیف', 'فولکس', 'پری', 'دیر', 'فلورید', 'ام 4', 'ولکس سی 30'] : ['Hover', 'Wingle', 'Safe', 'Voleex', 'Peri', 'Deer', 'Florid', 'M4', 'Voleex C30'],
    haval: language === 'ar' ? ['اچ 6', 'اچ 2', 'اچ 9', 'اچ 4', 'اچ 7', 'اف 7', 'اف 5', 'جولیون'] : ['H6', 'H2', 'H9', 'H4', 'H7', 'F7', 'F5', 'Jolion'],
    mg: language === 'ar' ? ['ام جی 6', 'ام جی 5', 'ام جی 3', 'ام جی زد اس', 'ام جی اچ اس', 'ام جی ایکس 5', 'ام جی 350', 'رایز', 'جی تی'] : ['MG6', 'MG5', 'MG3', 'MG ZS', 'MG HS', 'MG RX5', 'MG350', 'Rize', 'GT'],
    jac: language === 'ar' ? ['اس 5', 'اس 3', 'اس 2', 'تی 6', 'تی 8', 'جی 3', 'جی 5', 'ریفاین', 'رفای'] : ['S5', 'S3', 'S2', 'T6', 'T8', 'J3', 'J5', 'Refine', 'Reva']
  };

  const years = [];
  const currentYear = new Date().getFullYear();
  for (let year = currentYear; year >= 1985; year--) {
    years.push(year.toString());
  }

  const getCurrentCountry = () => countries.find(c => c.code === selectedCountry) || countries[0];
  const getCurrentBrand = () => carBrands.find(b => b.id === selectedBrand);
  const getAvailableModels = () => {
    if (!selectedBrand || !carModels[selectedBrand]) return [];
    return carModels[selectedBrand];
  };

  const handleCountryChange = (countryCode) => {
    setSelectedCountry(countryCode);
    localStorage.setItem('selectedCountry', countryCode);
    setShowCountryModal(false);
  };

  const handleBrandChange = (brandId) => {
    setSelectedBrand(brandId);
    setSelectedModel('');
    setShowBrandModal(false);
  };

  if (!isLoggedIn) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'}`}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600 mx-auto mb-4"></div>
          <p className={`${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
            {language === 'ar' ? 'جاري التحقق من تسجيل الدخول...' : 'Checking login...'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`min-h-screen pb-20 ${theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}`}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Navigation Bar */}
      <div className={`fixed top-0 left-0 right-0 z-50 text-white p-4 ${theme === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-gradient-to-r from-gray-700 to-gray-800'}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className={`${isRTL ? 'ml-3' : 'mr-3'}`}>
              <i className={`ri-arrow-${isRTL ? 'right' : 'left'}-line text-xl`}></i>
            </Link>
            <h1 className="text-lg font-bold">
              {language === 'ar' ? 'شراء قطع غيار' : 'Buy Auto Parts'}
            </h1>
          </div>

          {/* Country Selector */}
          <button
            onClick={() => setShowCountryModal(true)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg !rounded-button ${theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-600 hover:bg-gray-700'}`}
          >
            <span className="text-lg">{countries.find(c => c.code === selectedCountry)?.flag}</span>
            <span className="text-sm font-medium">{countries.find(c => c.code === selectedCountry)?.name}</span>
            <i className="ri-arrow-down-s-line text-sm"></i>
          </button>
        </div>
      </div>

      {/* Country Selection Modal */}
      {showCountryModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className={`rounded-lg w-full max-w-sm ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
            <div className={`p-4 border-b ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
              <div className="flex items-center justify-between">
                <h3 className={`text-lg font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  {language === 'ar' ? 'اختر الدولة' : 'Select Country'}
                </h3>
                <button
                  onClick={() => setShowCountryModal(false)}
                  className={`w-8 h-8 flex items-center justify-center rounded-full !rounded-button transition-colors ${theme === 'dark' ? 'text-gray-400 hover:bg-gray-700' : 'text-gray-500 hover:bg-gray-100'}`}
                >
                  <i className="ri-close-line"></i>
                </button>
              </div>
            </div>
            <div className="p-4 max-h-80 overflow-y-auto">
              {countries.map((country) => (
                <button
                  key={country.code}
                  onClick={() => handleCountryChange(country.code)}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg mb-2 transition-colors !rounded-button ${selectedCountry === country.code ? 'bg-red-50 border-2 border-red-500' : theme === 'dark' ? 'hover:bg-gray-700 border-2 border-transparent' : 'hover:bg-gray-50 border-2 border-transparent'} ${isRTL ? 'text-right' : 'text-left'}`}
                >
                  <span className="text-xl">{country.flag}</span>
                  <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                    <div className={`font-medium ${selectedCountry === country.code ? 'text-red-800' : theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
                      {country.name}
                    </div>
                    <div className={`text-sm ${selectedCountry === country.code ? 'text-red-600' : theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                      {country.currency}
                    </div>
                  </div>
                  {selectedCountry === country.code && (
                    <i className="ri-check-line text-red-500 text-xl"></i>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Brand Selection Modal */}
      {showBrandModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className={`rounded-lg w-full max-w-sm ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
            <div className={`p-4 border-b ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
              <div className="flex items-center justify-between">
                <h3 className={`text-lg font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  {language === 'ar' ? 'اختر الماركة' : 'Select Brand'}
                </h3>
                <button
                  onClick={() => setShowBrandModal(false)}
                  className={`w-8 h-8 flex items-center justify-center rounded-full !rounded-button transition-colors ${theme === 'dark' ? 'text-gray-400 hover:bg-gray-700' : 'text-gray-500 hover:bg-gray-100'}`}
                >
                  <i className="ri-close-line"></i>
                </button>
              </div>
            </div>
            <div className="p-4 max-h-80 overflow-y-auto">
              {carBrands.map((brand) => (
                <button
                  key={brand.id}
                  onClick={() => handleBrandChange(brand.id)}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg mb-2 transition-colors !rounded-button ${selectedBrand === brand.id ? 'bg-red-50 border-2 border-red-500' : theme === 'dark' ? 'hover:bg-gray-700 border-2 border-transparent' : 'hover:bg-gray-50 border-2 border-transparent'}`}
                >
                  <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center">
                    <i className="ri-car-line text-lg text-gray-600"></i>
                  </div>
                  <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                    <div className={`font-medium ${selectedBrand === brand.id ? 'text-red-800' : theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
                      {brand.name}
                    </div>
                  </div>
                  {selectedBrand === brand.id && (
                    <i className="ri-check-line text-red-500 text-xl"></i>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Model Selection Modal */}
      {showModelModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className={`rounded-lg w-full max-w-sm ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
            <div className={`p-4 border-b ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
              <div className="flex items-center justify-between">
                <h3 className={`text-lg font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  {language === 'ar' ? 'اختر الموديل' : 'Select Model'}
                </h3>
                <button
                  onClick={() => setShowModelModal(false)}
                  className={`w-8 h-8 flex items-center justify-center rounded-full !rounded-button transition-colors ${theme === 'dark' ? 'text-gray-400 hover:bg-gray-700' : 'text-gray-500 hover:bg-gray-100'}`}
                >
                  <i className="ri-close-line"></i>
                </button>
              </div>
            </div>
            <div className="p-4 max-h-80 overflow-y-auto">
              {getAvailableModels().map((model) => (
                <button
                  key={model}
                  onClick={() => {
                    setSelectedModel(model);
                    setShowModelModal(false);
                  }}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg mb-2 transition-colors !rounded-button ${selectedModel === model ? 'bg-red-50 border-2 border-red-500' : theme === 'dark' ? 'hover:bg-gray-700 border-2 border-transparent' : 'hover:bg-gray-50 border-2 border-transparent'}`}
                >
                  <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center">
                    <i className="ri-car-fill text-lg text-gray-600"></i>
                  </div>
                  <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                    <div className={`font-medium ${selectedModel === model ? 'text-red-800' : theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
                      {model}
                    </div>
                  </div>
                  {selectedModel === model && (
                    <i className="ri-check-line text-red-500 text-xl"></i>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Year Selection Modal */}
      {showYearModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className={`rounded-lg w-full max-w-sm ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
            <div className={`p-4 border-b ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
              <div className="flex items-center justify-between">
                <h3 className={`text-lg font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  {language === 'ar' ? 'اختر السنة' : 'Select Year'}
                </h3>
                <button
                  onClick={() => setShowYearModal(false)}
                  className={`w-8 h-8 flex items-center justify-center rounded-full !rounded-button transition-colors ${theme === 'dark' ? 'text-gray-400 hover:bg-gray-700' : 'text-gray-500 hover:bg-gray-100'}`}
                >
                  <i className="ri-close-line"></i>
                </button>
              </div>
            </div>
            <div className="p-4 max-h-80 overflow-y-auto">
              {years.map((year) => (
                <button
                  key={year}
                  onClick={() => {
                    setSelectedYear(year);
                    setShowYearModal(false);
                  }}
                  className={`${selectedYear === year ? 'bg-red-50 border-2 border-red-500' : theme === 'dark' ? 'hover:bg-gray-700 border-2 border-transparent' : 'hover:bg-gray-50 border-2 border-transparent'} w-full flex items-center gap-3 p-3 rounded-lg mb-2 transition-colors !rounded-button`}
                >
                  <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center">
                    <i className="ri-calendar-line text-lg text-gray-600"></i>
                  </div>
                  <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                    <div className={`font-medium ${selectedYear === year ? 'text-red-800' : theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
                      {year}
                    </div>
                  </div>
                  {selectedYear === year && (
                    <i className="ri-check-line text-red-500 text-xl"></i>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Content */}
      <div className="pt-20 px-4">
        {/* Search Bar and Smart Filters */}
        <div className={`rounded-lg p-4 mb-4 shadow-sm ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
          <div className="relative mb-4">
            <input
              type="text"
              placeholder={language === 'ar' ? 'ابحث عن القطعة التي تحتاجها...' : 'Search for the part you need...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full py-3 border rounded-lg text-sm focus:outline-none focus:border-red-500 ${isRTL ? 'pl-12 pr-4' : 'pl-12 pr-4'} ${theme === 'dark' ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400' : 'bg-white border-gray-300 text-gray-900'}`}
            />
            <div className={`absolute top-1/2 transform -translate-y-1/2 w-6 h-6 flex items-center justify-center ${isRTL ? 'right-3' : 'left-3'}`}>
              <i className={`ri-search-line ${theme === 'dark' ? 'text-gray-400' : 'text-gray-400'}`}></i>
            </div>
          </div>

          {/* Smart Filters */}
          <h3 className={`text-sm font-bold mb-3 ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
            {language === 'ar' ? 'بحث ذكي' : 'Smart Search'}
          </h3>

          <div className="grid grid-cols-2 gap-3 mb-3">
            {/* Brand Selector */}
            <button
              onClick={() => setShowBrandModal(true)}
              className={`p-3 rounded-lg border flex items-center justify-between !rounded-button ${theme === 'dark' ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300 text-gray-700'}`}
            >
              <span className="text-sm">
                {selectedBrand ? getCurrentBrand()?.name : (language === 'ar' ? 'الماركة' : 'Brand')}
              </span>
              <i className="ri-arrow-down-s-line text-sm"></i>
            </button>

            {/* Model Selector */}
            <button
              onClick={() => selectedBrand ? setShowModelModal(true) : null}
              disabled={!selectedBrand}
              className={`p-3 rounded-lg border flex items-center justify-between !rounded-button ${!selectedBrand ? 'opacity-50 cursor-not-allowed' : ''} ${theme === 'dark' ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300 text-gray-700'}`}
            >
              <span className="text-sm">
                {selectedModel || (language === 'ar' ? 'الموديل' : 'Model')}
              </span>
              <i className="ri-arrow-down-s-line text-sm"></i>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* Year Selector */}
            <button
              onClick={() => setShowYearModal(true)}
              className={`p-3 rounded-lg border flex items-center justify-between !rounded-button ${theme === 'dark' ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300 text-gray-700'}`}
            >
              <span className="text-sm">
                {selectedYear || (language === 'ar' ? 'السنة' : 'Year')}
              </span>
              <i className="ri-arrow-down-s-line text-sm"></i>
            </button>

            {/* Clear Filters */}
            <button
              onClick={() => {
                setSelectedBrand('');
                setSelectedModel('');
                setSelectedYear('');
                setSelectedCategory('');
                setSearchQuery('');
              }}
              className={`p-3 rounded-lg border flex items-center justify-center !rounded-button ${theme === 'dark' ? 'bg-red-600 border-red-600 text-white hover:bg-red-700' : 'bg-red-600 border-red-600 text-white hover:bg-red-700'}`}
            >
              <i className="ri-refresh-line text-sm mr-1"></i>
              <span className="text-sm">{language === 'ar' ? 'مسح' : 'Clear'}</span>
            </button>
          </div>
        </div>

        {/* Categories Section */}
        <div className={`rounded-lg p-4 mb-4 shadow-sm ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
          <h3 className={`text-sm font-bold mb-3 ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
            {language === 'ar' ? 'أقسام قطع الغيار' : 'Auto Parts Categories'}
          </h3>
          <div className="grid grid-cols-3 gap-3">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(selectedCategory === category.id ? '' : category.id)}
                className={`p-3 rounded-lg border-2 transition-all !rounded-button ${selectedCategory === category.id ? 'border-red-500 bg-red-50' : theme === 'dark' ? 'border-gray-700 bg-gray-800 hover:border-gray-600' : 'border-gray-200 bg-gray-50 hover:border-gray-300'}`}
              >
                <div className="w-10 h-10 mx-auto mb-2 rounded-lg bg-gray-100 flex items-center justify-center">
                  <i className={`${category.icon} text-lg ${category.color}`}></i>
                </div>
                <span className={`text-xs font-medium ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {category.name}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Country Info */}
        <div className={`rounded-lg p-4 mb-4 shadow-sm ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-2xl">{countries.find(c => c.code === selectedCountry)?.flag}</span>
              <div>
                <h3 className={`font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
                  {language === 'ar' ? `قطع غيار من ${countries.find(c => c.code === selectedCountry)?.name}` : `Auto Parts from ${countries.find(c => c.code === selectedCountry)?.name}`}
                </h3>
                <p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                  {language === 'ar' ? `الأسعار بالعملة المحلية (${countries.find(c => c.code === selectedCountry)?.currency})` : `Prices in local currency (${countries.find(c => c.code === selectedCountry)?.currency})`}
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold text-red-600">0</div>
              <div className={`text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                {language === 'ar' ? 'قطعة متوفرة' : 'parts available'}
              </div>
            </div>
          </div>
        </div>

        {/* Empty State */}
        <div className="text-center py-12">
          <div className={`w-16 h-16 flex items-center justify-center mx-auto mb-4 ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
            <i className="ri-car-line text-4xl"></i>
          </div>
          <h3 className={`text-lg font-semibold mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
            {language === 'ar' ? 'قريباً!' : 'Coming Soon!'}
          </h3>
          <p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
            {language === 'ar' ? 'سنضيف المزيد من المنتجات قريباً' : 'We will add more products soon'}
          </p>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className={`fixed bottom-0 left-0 right-0 border-t z-50 ${theme === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-gradient-to-r from-gray-700 to-gray-800 border-gray-600'}`}>
        <div className="grid grid-cols-4 py-2">
          <Link href="/" className="flex flex-col items-center py-2 text-gray-300 hover:text-white">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-home-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('home')}</span>
          </Link>
          <Link href="/search" className="flex flex-col items-center py-2 text-gray-300 hover:text-white">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-search-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('search')}</span>
          </Link>
          <Link href="/chat" className="flex flex-col items-center py-2 text-gray-300 hover:text-white">
            <div className="w-6 h-6 flex items-center justify-center relative">
              <i className="ri-chat-3-line text-lg"></i>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                <span className="text-xs text-white font-bold">3</span>
              </div>
            </div>
            <span className="text-xs mt-1">{t('chat')}</span>
          </Link>
          <Link href="/profile" className="flex flex-col items-center py-2 text-red-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-user-line text-lg"></i>
            </div>
            <span className="text-xs mt-1 font-medium">{t('profile')}</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

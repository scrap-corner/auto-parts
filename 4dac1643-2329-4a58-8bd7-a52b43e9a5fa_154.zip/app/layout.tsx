
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { LanguageProvider } from '../components/LanguageProvider';
import ErrorBoundary from '../components/ErrorBoundary';
import PushNotifications from '../components/PushNotifications';

const inter = Inter({ subsets: ['latin', 'latin-ext'] });

export const metadata: Metadata = {
  title: 'سكراب كورنر - أفضل مكان لبيع وشراء قطع غيار السيارات | Scrap Corner - Best Auto Parts Marketplace',
  description: 'منصة متخصصة في بيع وشراء قطع غيار السيارات المستعملة بأفضل الأسعار وأعلى جودة في الشرق الأوسط | Specialized platform for buying and selling used auto parts at the best prices and highest quality in the Middle East',
  keywords: 'قطع غيار, سيارات, مستعمل, بيع, شراء, محركات, فرامل, إطارات, auto parts, cars, used, sell, buy, engines, brakes, tires',
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover',
  robots: 'index, follow',
  openGraph: {
    title: 'سكراب كورنر - قطع غيار السيارات | Scrap Corner - Auto Parts',
    description: 'أفضل مكان لبيع وشراء قطع غيار السيارات المستعملة | Best place to buy and sell used auto parts',
    type: 'website',
    locale: 'ar_SA',
    alternateLocale: 'en_US',
  }
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        <link rel="manifest" href="/manifest.json" />
        <link rel="apple-touch-icon" href="/icon-192x192.png" />
        <meta name="theme-color" content="#dc2626" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="سكراب كورنر" />
        <script src="/capacitor.js" defer></script>
      </head>
      <body className={`${inter.className} rtl safe-area-full`} suppressHydrationWarning>
        <ErrorBoundary>
          <LanguageProvider>
            <div className="min-h-screen bg-white dark:bg-gray-900">
              {children}
              <PushNotifications />
            </div>
          </LanguageProvider>
        </ErrorBoundary>
      </body>
    </html>
  );
}

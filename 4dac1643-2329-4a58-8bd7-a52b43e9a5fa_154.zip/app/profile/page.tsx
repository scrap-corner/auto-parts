
'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useLanguage } from '../../components/LanguageProvider';

export default function Profile() {
  const router = useRouter();
  const { language, t, isRTL, theme } = useLanguage();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';
    if (!loggedIn) {
      sessionStorage.setItem('returnUrl', '/profile');
      router.push('/login');
      return;
    }
    
    setIsLoggedIn(true);
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('user');
    router.push('/login');
  };

  const stats = [
    { 
      label: language === 'ar' ? 'منتجاتي' : 'My Products', 
      value: '12', 
      color: 'blue' 
    },
    { 
      label: language === 'ar' ? 'المباع' : 'Sold', 
      value: '8', 
      color: 'green' 
    },
    { 
      label: language === 'ar' ? 'التقييم' : 'Rating', 
      value: '4.9', 
      color: 'yellow' 
    },
    { 
      label: language === 'ar' ? 'المشتريات' : 'Purchases', 
      value: '5', 
      color: 'purple' 
    }
  ];

  const menuItems = [
    {
      icon: 'ri-product-hunt-line',
      title: language === 'ar' ? 'منتجاتي' : 'My Products',
      subtitle: language === 'ar' ? 'إدارة منتجاتك المعروضة' : 'Manage your listed products',
      href: '/my-products',
      color: 'blue'
    },
    {
      icon: 'ri-shopping-bag-3-line',
      title: language === 'ar' ? 'مشترياتي' : 'My Purchases',
      subtitle: language === 'ar' ? 'عرض تاريخ المشتريات' : 'View purchase history',
      href: '/my-purchases',
      color: 'green'
    },
    {
      icon: 'ri-heart-line',
      title: language === 'ar' ? 'المفضلة' : 'Favorites',
      subtitle: language === 'ar' ? 'المنتجات المحفوظة' : 'Saved products',
      href: '/favorites',
      color: 'red'
    },
    {
      icon: 'ri-settings-3-line',
      title: language === 'ar' ? 'الإعدادات' : 'Settings',
      subtitle: language === 'ar' ? 'إعدادات الحساب' : 'Account settings',
      href: '/settings',
      color: 'gray'
    },
    {
      icon: 'ri-customer-service-2-line',
      title: language === 'ar' ? 'الدعم الفني' : 'Support',
      subtitle: language === 'ar' ? 'تواصل معنا' : 'Contact us',
      href: '/support',
      color: 'orange'
    }
  ];

  if (!isLoggedIn) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'}`}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className={`${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
            {language === 'ar' ? 'جاري التحقق من تسجيل الدخول...' : 'Checking login...'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div 
      className={`min-h-screen pb-20 ${
        theme === 'dark' 
          ? 'bg-gray-900' 
          : 'bg-gradient-to-br from-blue-50 to-indigo-100'
      }`}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Navigation Bar */}
      <div className={`fixed top-0 left-0 right-0 z-50 border-b shadow-sm ${
        theme === 'dark'
          ? 'bg-gray-800/95 backdrop-blur-md border-gray-700'
          : 'bg-white/95 backdrop-blur-md border-gray-100'
      }`}>
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <Link href="/" className={`${isRTL ? 'ml-3' : 'mr-3'}`}>
              <i className={`ri-arrow-${isRTL ? 'right' : 'left'}-line text-xl ${
                theme === 'dark' ? 'text-gray-300' : 'text-gray-700'
              }`}></i>
            </Link>
            <h1 className={`text-lg font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
              {t('profile')}
            </h1>
          </div>
          <button 
            onClick={handleLogout}
            className={`text-sm font-medium transition-colors ${
              theme === 'dark'
                ? 'text-red-400 hover:text-red-300'
                : 'text-red-600 hover:text-red-700'
            }`}
          >
            {language === 'ar' ? 'تسجيل خروج' : 'Logout'}
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 px-4">
        {/* Profile Header */}
        <div className={`rounded-2xl p-6 mb-6 border shadow-sm ${
          theme === 'dark'
            ? 'bg-gray-800/90 backdrop-blur-sm border-gray-700'
            : 'bg-white/90 backdrop-blur-sm border-white/50'
        }`}>
          <div className={`flex items-center mb-6 ${isRTL ? 'space-x-reverse space-x-4' : 'space-x-4'}`}>
            <div className="w-20 h-20 rounded-2xl overflow-hidden flex-shrink-0">
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20male%20portrait%2C%20Saudi%20businessman%2C%20clean%20background%2C%20realistic%20photography%20style%2C%20friendly%20appearance&width=120&height=120&seq=profile_avatar&orientation=squarish"
                alt={language === 'ar' ? 'صورة المستخدم' : 'User Avatar'}
                className="w-full h-full object-cover object-top"
              />
            </div>
            <div className="flex-1">
              <h2 className={`text-xl font-bold mb-1 ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
                {user?.name || (language === 'ar' ? 'المستخدم' : 'User')}
              </h2>
              <p className={`text-sm mb-1 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                {user?.email}
              </p>
              <p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                {user?.phone}
              </p>
              <div className={`flex items-center mt-2 ${isRTL ? 'space-x-reverse space-x-2' : 'space-x-2'}`}>
                <div className="flex items-center">
                  <i className={`ri-star-fill text-yellow-400 text-sm ${isRTL ? 'ml-1' : 'mr-1'}`}></i>
                  <span className={`text-sm font-medium ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                    4.9
                  </span>
                </div>
                <span className={`${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>•</span>
                <span className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                  {language === 'ar' ? 'عضو منذ 2023' : 'Member since 2023'}
                </span>
              </div>
            </div>
            <Link 
              href="/profile/edit"
              className={`w-10 h-10 rounded-full flex items-center justify-center ${
                theme === 'dark'
                  ? 'bg-gray-700 hover:bg-gray-600'
                  : 'bg-blue-100 hover:bg-blue-200'
              } transition-colors`}
            >
              <i className={`ri-edit-line ${
                theme === 'dark' ? 'text-gray-300' : 'text-blue-600'
              }`}></i>
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-4 gap-4">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className={`text-2xl font-bold mb-1 ${ 
                  stat.color === 'blue' ? 'text-blue-600 dark:text-blue-400' :
                  stat.color === 'green' ? 'text-green-600 dark:text-green-400' :
                  stat.color === 'yellow' ? 'text-yellow-500 dark:text-yellow-400' :
                  'text-purple-600 dark:text-purple-400'
                }`}>
                  {stat.value}
                </div>
                <div className={`text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Link 
            href="/sell"
            className="bg-gradient-to-r from-emerald-500 to-green-500 text-white p-4 rounded-2xl text-center shadow-lg hover:shadow-xl transition-all transform hover:scale-105 !rounded-button"
          >
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-2">
              <i className="ri-add-circle-fill text-xl"></i>
            </div>
            <span className="text-sm font-semibold">
              {language === 'ar' ? 'إضافة منتج' : 'Add Product'}
            </span>
          </Link>
          <Link 
            href="/my-products"
            className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white p-4 rounded-2xl text-center shadow-lg hover:shadow-xl transition-all transform hover:scale-105 !rounded-button"
          >
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-2">
              <i className="ri-product-hunt-fill text-xl"></i>
            </div>
            <span className="text-sm font-semibold">
              {language === 'ar' ? 'إدارة منتجاتي' : 'Manage Products'}
            </span>
          </Link>
        </div>

        {/* Menu Items */}
        <div className="space-y-3 mb-6">
          {menuItems.map((item, index) => (
            <Link 
              key={index}
              href={item.href}
              className={`border rounded-2xl p-4 flex items-center shadow-sm hover:shadow-md transition-all ${
                isRTL ? 'space-x-reverse space-x-4' : 'space-x-4'
              } ${
                theme === 'dark'
                  ? 'bg-gray-800/90 backdrop-blur-sm border-gray-700 hover:bg-gray-700'
                  : 'bg-white/90 backdrop-blur-sm border-white/50 hover:bg-white'
              }`}
            >
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${ 
                item.color === 'blue' ? 'bg-blue-100 dark:bg-blue-900/30' :
                item.color === 'green' ? 'bg-green-100 dark:bg-green-900/30' :
                item.color === 'red' ? 'bg-red-100 dark:bg-red-900/30' :
                item.color === 'emerald' ? 'bg-emerald-100 dark:bg-emerald-900/30' :
                item.color === 'orange' ? 'bg-orange-100 dark:bg-orange-900/30' :
                'bg-gray-100 dark:bg-gray-700'
              }`}>
                <i className={`${item.icon} text-xl ${ 
                  item.color === 'blue' ? 'text-blue-600 dark:text-blue-400' :
                  item.color === 'green' ? 'text-green-600 dark:text-green-400' :
                  item.color === 'red' ? 'text-red-600 dark:text-red-400' :
                  item.color === 'emerald' ? 'text-emerald-600 dark:text-emerald-400' :
                  item.color === 'orange' ? 'text-orange-600 dark:text-orange-400' :
                  'text-gray-600 dark:text-gray-400'
                }`}></i>
              </div>
              <div className="flex-1">
                <h4 className={`font-semibold text-sm ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
                  {item.title}
                </h4>
                <p className={`text-xs mt-1 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                  {item.subtitle}
                </p>
              </div>
              <i className={`ri-arrow-${isRTL ? 'left' : 'right'}-s-line ${
                theme === 'dark' ? 'text-gray-500' : 'text-gray-400'
              }`}></i>
            </Link>
          ))}
        </div>

        {/* App Info */}
        <div className={`rounded-2xl p-4 border mb-6 ${
          theme === 'dark'
            ? 'bg-gray-800/80 backdrop-blur-sm border-gray-700'
            : 'bg-white/80 backdrop-blur-sm border-white/50'
        }`}>
          <div className="text-center">
            <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-3">
              <i className="ri-car-line text-white text-xl"></i>
            </div>
            <h3 className={`font-['Pacifico'] text-lg mb-1 ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
              {language === 'ar' ? 'سكراب كورنر' : 'Scrap Corner'}
            </h3>
            <p className={`text-xs mb-3 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
              {language === 'ar' ? 'الإصدار 1.0.0' : 'Version 1.0.0'}
            </p>
            <div className={`flex justify-center gap-6 ${isRTL ? 'space-x-reverse' : ''}`}>
              <Link href="/about" className={`text-xs transition-colors ${
                theme === 'dark' ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'
              }`}>
                {language === 'ar' ? 'حول التطبيق' : 'About App'}
              </Link>
              <Link href="/privacy" className={`text-xs transition-colors ${
                theme === 'dark' ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'
              }`}>
                {language === 'ar' ? 'سياسة الخصوصية' : 'Privacy Policy'}
              </Link>
              <Link href="/terms" className={`text-xs transition-colors ${
                theme === 'dark' ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'
              }`}>
                {language === 'ar' ? 'الشروط والأحكام' : 'Terms & Conditions'}
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className={`fixed bottom-0 left-0 right-0 border-t z-50 ${
        theme === 'dark'
          ? 'bg-gray-800/95 backdrop-blur-md border-gray-700'
          : 'bg-white/95 backdrop-blur-md border-gray-100'
      }`}>
        <div className="grid grid-cols-5 py-2">
          <Link href="/" className={`flex flex-col items-center py-2 transition-colors ${
            theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'
          }`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-home-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('home')}</span>
          </Link>
          <Link href="/search" className={`flex flex-col items-center py-2 transition-colors ${
            theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'
          }`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-search-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('search')}</span>
          </Link>
          <Link href="/chat" className={`flex flex-col items-center py-2 transition-colors ${
            theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'
          }`}>
            <div className="w-6 h-6 flex items-center justify-center relative">
              <i className="ri-chat-3-line text-lg"></i>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                <span className="text-xs text-white font-bold">3</span>
              </div>
            </div>
            <span className="text-xs mt-1">{t('chat')}</span>
          </Link>
          <Link href="/favorites" className={`flex flex-col items-center py-2 transition-colors ${
            theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'
          }`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-heart-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('favorites')}</span>
          </Link>
          <Link href="/profile" className={`flex flex-col items-center py-2 ${
            theme === 'dark' ? 'text-blue-400' : 'text-blue-600'
          }`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-user-fill text-lg"></i>
            </div>
            <span className="text-xs mt-1 font-medium">{t('profile')}</span>
          </Link>
        </div>
      </div>
    </div>
  );
}


'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useLanguage } from '../../components/LanguageProvider';

export default function Favorites() {
  const router = useRouter();
  const { language, t, isRTL, theme } = useLanguage();
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';
    if (!loggedIn) {
      sessionStorage.setItem('returnUrl', '/favorites');
      router.push('/login');
      return;
    }
    setIsLoggedIn(true);
  }, [router]);

  // دالة تحويل التاريخ للهجري
  const toHijri = (gregorianDate) => {
    const options = { 
      calendar: 'islamic-umalqura',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      locale: 'ar-SA'
    };
    return new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', options).format(gregorianDate);
  };

  const formatDualDate = (dateString) => {
    const date = new Date();
    const daysAgo = dateString.includes('يومين') ? 2 : 
                    dateString.includes('3 أيام') || dateString.includes('3 days') ? 3 : 
                    dateString.includes('أسبوع') || dateString.includes('week') ? 7 : 
                    dateString.includes('4 أيام') || dateString.includes('4 days') ? 4 : 2;
    
    date.setDate(date.getDate() - daysAgo);

    // التاريخ الميلادي
    const gregorian = date.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', {
      day: 'numeric',
      month: 'short'
    });

    // التاريخ الهجري
    const hijri = toHijri(date);
    const hijriShort = hijri.replace(/\d+\s*هـ/, '').trim();

    if (language === 'ar') {
      if (daysAgo === 1) {
        return `أمس - ${gregorian} م / ${hijriShort} هـ`;
      } else if (daysAgo < 7) {
        return `منذ ${daysAgo} أيام - ${gregorian} م / ${hijriShort} هـ`;
      } else {
        return `منذ أسبوع - ${gregorian} م / ${hijriShort} هـ`;
      }
    } else {
      if (daysAgo === 1) {
        return `Yesterday - ${gregorian} / ${hijriShort} AH`;
      } else if (daysAgo < 7) {
        return `${daysAgo} days ago - ${gregorian} / ${hijriShort} AH`;
      } else {
        return `1 week ago - ${gregorian} / ${hijriShort} AH`;
      }
    }
  };

  const favorites = [
    {
      id: 1,
      name: language === 'ar' ? 'إطار ميشلان مقاس 195/65R15' : 'Michelin Tire 195/65R15',
      price: language === 'ar' ? '280 ريال' : '280 SAR',
      originalPrice: language === 'ar' ? '350 ريال' : '350 SAR',
      location: language === 'ar' ? 'جدة' : 'Jeddah',
      condition: language === 'ar' ? 'مستعمل - ممتاز' : 'Used - Excellent',
      seller: language === 'ar' ? 'سعد العتيبي' : 'Saad Al-Otaibi',
      rating: 4.9,
      discount: '20%',
      image: 'Michelin tire automotive wheel, clean background, professional product photography, high quality tire, premium automotive part',
      addedDate: language === 'ar' ? 'منذ يومين' : '2 days ago'
    },
    {
      id: 2,
      name: language === 'ar' ? 'فرامل أمامية نيسان التيما' : 'Nissan Altima Front Brakes',
      price: language === 'ar' ? '180 ريال' : '180 SAR',
      originalPrice: language === 'ar' ? '220 ريال' : '220 SAR',
      location: language === 'ar' ? 'الرياض' : 'Riyadh',
      condition: language === 'ar' ? 'جديد' : 'New',
      seller: language === 'ar' ? 'علي حسن' : 'Ali Hassan',
      rating: 4.7,
      discount: '18%',
      image: 'Nissan Altima brake pads automotive parts, clean background, professional product photography, premium brake components',
      addedDate: language === 'ar' ? 'منذ 3 أيام' : '3 days ago'
    },
    {
      id: 3,
      name: language === 'ar' ? 'زيت محرك موبيل 1 سينثيتك' : 'Mobil 1 Synthetic Engine Oil',
      price: language === 'ar' ? '95 ريال' : '95 SAR',
      originalPrice: language === 'ar' ? '120 ريال' : '120 SAR',
      location: language === 'ar' ? 'الدمام' : 'Dammam',
      condition: language === 'ar' ? 'جديد' : 'New',
      seller: language === 'ar' ? 'خالد السالم' : 'Khalid Al-Salem',
      rating: 4.8,
      discount: '21%',
      image: 'Mobil 1 synthetic engine oil automotive lubricant, clean background, professional product photography, premium motor oil',
      addedDate: language === 'ar' ? 'منذ أسبوع' : '1 week ago'
    },
    {
      id: 4,
      name: language === 'ar' ? 'مرآة جانبية هوندا اكورد' : 'Honda Accord Side Mirror',
      price: language === 'ar' ? '85 ريال' : '85 SAR',
      originalPrice: language === 'ar' ? '110 ريال' : '110 SAR',
      location: language === 'ar' ? 'مكة' : 'Makkah',
      condition: language === 'ar' ? 'مستعمل - جيد' : 'Used - Good',
      seller: language === 'ar' ? 'محمد الأحمد' : 'Mohammed Al-Ahmad',
      rating: 4.6,
      discount: '23%',
      image: 'Honda Accord side mirror automotive part, clean background, professional product photography, used car part',
      addedDate: language === 'ar' ? 'منذ 4 أيام' : '4 days ago'
    }
  ];

  const removeFavorite = (id: number) => {
    // هنا يمكن إضافة منطق إزالة العنصر من المفضلة
    console.log('Remove favorite:', id);
  };

  if (!isLoggedIn) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'}`}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className={`${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
            {language === 'ar' ? 'جاري التحقق من تسجيل الدخول...' : 'Checking login...'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen pb-20 ${theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Navigation Bar */}
      <div className={`fixed top-0 left-0 right-0 z-50 border-b shadow-sm ${theme === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <Link href="/" className={`${isRTL ? 'ml-3' : 'mr-3'}`}>
              <i className={`ri-arrow-${isRTL ? 'right' : 'left'}-line text-xl ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}></i>
            </Link>
            <h1 className={`text-lg font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
              {t('favorites')}
            </h1>
          </div>
          <div className="flex items-center">
            <span className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
              {favorites.length} {language === 'ar' ? 'عنصر' : 'items'}
            </span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 px-4">
        {favorites.length > 0 ? (
          <div className="space-y-4">
            {favorites.map((item) => (
              <div key={item.id} className={`rounded-2xl shadow-sm border overflow-hidden ${theme === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100'}`}>
                <div className="p-4">
                  <div className={`flex items-start ${isRTL ? 'space-x-reverse space-x-4' : 'space-x-4'}`}>
                    {/* Product Image */}
                    <div className="relative w-24 h-24 rounded-2xl overflow-hidden flex-shrink-0">
                      <Link href={`/product/${item.id}`}>
                        <img 
                          src={`https://readdy.ai/api/search-image?query=${item.image}&width=150&height=150&seq=favorite_${item.id}&orientation=squarish`}
                          alt={item.name}
                          className="w-full h-full object-cover object-top"
                        />
                      </Link>
                      <div className={`absolute top-2 bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full font-bold ${isRTL ? 'left-2' : 'right-2'}`}>
                        -{item.discount}
                      </div>
                    </div>

                    {/* Product Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <Link href={`/product/${item.id}`} className="flex-1 min-w-0">
                          <h3 className={`font-semibold text-sm leading-tight mb-1 truncate ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
                            {item.name}
                          </h3>
                        </Link>
                        <button 
                          onClick={() => removeFavorite(item.id)}
                          className={`w-8 h-8 bg-red-50 dark:bg-red-900/30 rounded-full flex items-center justify-center flex-shrink-0 transition-colors ${isRTL ? 'mr-2' : 'ml-2'} hover:bg-red-100 dark:hover:bg-red-900/50`}
                        >
                          <i className="ri-heart-fill text-red-500 text-sm"></i>
                        </button>
                      </div>

                      <div className="flex items-center mb-2">
                        <span className={`text-lg font-bold ${theme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'}`}>
                          {item.price}
                        </span>
                        <span className={`text-sm line-through ${isRTL ? 'mr-2' : 'ml-2'} ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
                          {item.originalPrice}
                        </span>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${isRTL ? 'mr-2' : 'ml-2'} ${theme === 'dark' ? 'bg-blue-900/30 text-blue-400' : 'bg-blue-100 text-blue-800'}`}>
                          {item.condition}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-xs mb-2">
                        <div className={`flex items-center ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                          <i className={`ri-map-pin-2-line text-xs ${isRTL ? 'ml-1' : 'mr-1'}`}></i>
                          <span>{item.location}</span>
                        </div>
                        <div className={`flex items-center ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                          <div className={`flex items-center ${isRTL ? 'ml-3' : 'mr-3'}`}>
                            <i className={`ri-star-fill text-yellow-400 text-xs ${isRTL ? 'ml-1' : 'mr-1'}`}></i>
                            <span className="font-medium">{item.rating}</span>
                          </div>
                          <span className="truncate max-w-20">{item.seller}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className={`text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                          {formatDualDate(item.addedDate)}
                        </span>
                        <div className={`flex gap-2 ${isRTL ? 'space-x-reverse' : ''}`}>
                          <Link 
                            href={`/chat/new?product=${item.id}`}
                            className={`px-3 py-1 rounded-lg text-xs font-medium !rounded-button transition-colors ${theme === 'dark' ? 'bg-blue-900/30 text-blue-400 hover:bg-blue-900/50' : 'bg-blue-50 text-blue-600 hover:bg-blue-100'}`}
                          >
                            {language === 'ar' ? 'تواصل' : 'Contact'}
                          </Link>
                          <Link 
                            href={`/product/${item.id}`}
                            className={`px-3 py-1 rounded-lg text-xs font-medium !rounded-button transition-colors ${theme === 'dark' ? 'bg-gray-700 text-gray-300 hover:bg-gray-600' : 'bg-gray-50 text-gray-700 hover:bg-gray-100'}`}
                          >
                            {language === 'ar' ? 'عرض' : 'View'}
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          // Empty State
          <div className="text-center py-16">
            <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 ${theme === 'dark' ? 'bg-gray-800' : 'bg-gray-100'}`}>
              <i className={`ri-heart-line text-3xl ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}></i>
            </div>
            <h3 className={`text-lg font-semibold mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
              {language === 'ar' ? 'لا توجد مفضلات' : 'No favorites'}
            </h3>
            <p className={`text-sm mb-6 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
              {language === 'ar' ? 'لم تقم بإضافة أي منتجات للمفضلة بعد' : "You haven't added any products to favorites yet"}
            </p>
            <Link 
              href="/search"
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-medium !rounded-button inline-block hover:bg-blue-700 transition-colors"
            >
              {language === 'ar' ? 'تصفح المنتجات' : 'Browse Products'}
            </Link>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className={`fixed bottom-0 left-0 right-0 border-t z-50 ${theme === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
        <div className="grid grid-cols-5 py-2">
          <Link href="/" className={`flex flex-col items-center py-2 transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'}`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-home-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('home')}</span>
          </Link>
          <Link href="/search" className={`flex flex-col items-center py-2 transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'}`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-search-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('search')}</span>
          </Link>
          <Link href="/chat" className={`flex flex-col items-center py-2 transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'}`}>
            <div className="w-6 h-6 flex items-center justify-center relative">
              <i className="ri-chat-3-line text-lg"></i>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                <span className="text-xs text-white font-bold">3</span>
              </div>
            </div>
            <span className="text-xs mt-1">{t('chat')}</span>
          </Link>
          <Link href="/favorites" className={`flex flex-col items-center py-2 ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-heart-fill text-lg"></i>
            </div>
            <span className="text-xs mt-1 font-medium">{t('favorites')}</span>
          </Link>
          <Link href="/profile" className={`flex flex-col items-center py-2 transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'}`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-user-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('profile')}</span>
          </Link>
        </div>
      </div>
    </div>
  );
}


'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface Ad {
  id: string;
  title: string;
  category: string;
  brand: string;
  model: string;
  price: string;
  location: string;
  createdAt: string;
  expiresAt: string;
  isExpired: boolean;
}

export default function MyAds() {
  const router = useRouter();
  const [ads, setAds] = useState<Ad[]>([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';
    if (!loggedIn) {
      router.push('/login');
      return;
    }
    setIsLoggedIn(true);
    loadUserAds();
  }, [router]);

  const loadUserAds = () => {
    const userAds = JSON.parse(localStorage.getItem('userAds') || '[]');
    const currentUserId = localStorage.getItem('currentUser') || 'user1';

    // فلترة إعلانات المستخدم الحالي وتحديث حالة الانتهاء
    const myAds = userAds
      .filter((ad: Ad) => ad.userId === currentUserId)
      .map((ad: Ad) => {
        const now = new Date();
        const expiryDate = new Date(ad.expiresAt);
        return {
          ...ad,
          isExpired: now > expiryDate
        };
      });

    setAds(myAds);
  };

  const renewAd = (adId: string) => {
    const userAds = JSON.parse(localStorage.getItem('userAds') || '[]');
    const updatedAds = userAds.map((ad: Ad) => {
      if (ad.id === adId) {
        const newExpiryDate = new Date();
        newExpiryDate.setMonth(newExpiryDate.getMonth() + 2);
        return {
          ...ad,
          expiresAt: newExpiryDate.toISOString(),
          isExpired: false
        };
      }
      return ad;
    });

    localStorage.setItem('userAds', JSON.stringify(updatedAds));
    loadUserAds();
    alert('تم تجديد الإعلان بنجاح لمدة شهرين إضافيين!');
  };

  const deleteAd = (adId: string) => {
    if (confirm('هل أنت متأكد من حذف هذا الإعلان؟')) {
      const userAds = JSON.parse(localStorage.getItem('userAds') || '[]');
      const filteredAds = userAds.filter((ad: Ad) => ad.id !== adId);
      localStorage.setItem('userAds', JSON.stringify(filteredAds));
      loadUserAds();
      alert('تم حذف الإعلان بنجاح!');
    }
  };

  const getRemainingTime = (expiresAt: string) => {
    const now = new Date();
    const expiry = new Date(expiresAt);
    const diffTime = expiry.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      return 'انتهت';
    } else if (diffDays === 0) {
      return 'ينتهي اليوم';
    } else if (diffDays < 7) {
      return `${diffDays} أيام متبقية`;
    } else {
      const weeks = Math.floor(diffDays / 7);
      const days = diffDays % 7;
      return weeks === 1 ? `أسبوع${days > 0 ? ` و${days} أيام` : ''} متبقي` : `${weeks} أسابيع${days > 0 ? ` و${days} أيام` : ''} متبقية`;
    }
  };

  // دالة تحويل التاريخ للهجري
  const toHijri = (gregorianDate) => {
    const options = { 
      calendar: 'islamic-umalqura',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      locale: 'ar-SA'
    };
    return new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', options).format(gregorianDate);
  };

  const formatDualDate = (dateString) => {
    const date = new Date(dateString);

    // التاريخ الميلادي
    const gregorian = date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });

    // التاريخ الهجري
    const hijri = toHijri(date);

    return `${gregorian} م - ${hijri.replace(/\d+\s*هـ/, '')} هـ`;
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحقق من تسجيل الدخول...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Navigation Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-green-600 text-white p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="ml-3">
              <i className="ri-arrow-right-line text-xl"></i>
            </Link>
            <h1 className="text-lg font-bold">إعلاناتي</h1>
          </div>
          <Link href="/sell" className="w-8 h-8 flex items-center justify-center">
            <i className="ri-add-line text-xl"></i>
          </Link>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 px-4 py-6">
        {ads.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 flex items-center justify-center mx-auto mb-4 text-gray-300">
              <i className="ri-advertisement-line text-4xl"></i>
            </div>
            <h3 className="text-lg font-medium text-gray-600 mb-2">لا توجد إعلانات</h3>
            <p className="text-gray-500 text-sm mb-6">ابدأ بنشر أول إعلان لك الآن</p>
            <Link
              href="/sell"
              className="inline-block bg-green-600 text-white px-6 py-3 rounded-lg font-medium !rounded-button hover:bg-green-700 transition-colors"
            >
              أضف إعلان جديد
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {ads.map((ad) => (
              <div key={ad.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
                <div className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-gray-800 text-sm flex-1 ml-2">{ad.title}</h3>
                    <div className={`px-2 py-1 rounded-full text-xs font-medium ${ad.isExpired ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                      {ad.isExpired ? 'منتهي' : 'نشط'}
                    </div>
                  </div>

                  <div className="flex items-center text-xs text-gray-500 mb-2">
                    <span>{ad.brand} {ad.model}</span>
                    <span className="mx-2">•</span>
                    <span>{ad.category}</span>
                    <span className="mx-2">•</span>
                    <span>{ad.location}</span>
                  </div>

                  <div className="flex items-center justify-between mb-3">
                    <span className="text-lg font-bold text-green-600">{ad.price} ريال</span>
                    <div className={`text-xs ${ad.isExpired ? 'text-red-500' : getRemainingTime(ad.expiresAt).includes('أيام') ? 'text-orange-500' : 'text-gray-500'}`}>
                      {getRemainingTime(ad.expiresAt)}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    {ad.isExpired ? (
                      <button
                        onClick={() => renewAd(ad.id)}
                        className="flex-1 bg-green-600 text-white py-2 rounded-lg text-sm font-medium !rounded-button hover:bg-green-700 transition-colors"
                      >
                        <i className="ri-refresh-line ml-1"></i>
                        تجديد لمدة شهرين
                      </button>
                    ) : (
                      <button
                        onClick={() => renewAd(ad.id)}
                        className="flex-1 bg-blue-600 text-white py-2 rounded-lg text-sm font-medium !rounded-button hover:bg-blue-700 transition-colors"
                      >
                        <i className="ri-time-line ml-1"></i>
                        مد الصلاحية
                      </button>
                    )}

                    <button
                      onClick={() => deleteAd(ad.id)}
                      className="px-4 bg-red-100 text-red-600 py-2 rounded-lg text-sm font-medium !rounded-button hover:bg-red-200 transition-colors"
                    >
                      <i className="ri-delete-bin-line"></i>
                    </button>
                  </div>
                </div>

                <div className="bg-gray-50 px-4 py-2 text-xs text-gray-500">
                  نُشر في: {formatDualDate(ad.createdAt)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2">
        <div className="grid grid-cols-5 gap-1">
          <Link href="/" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-home-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">الرئيسية</span>
          </Link>
          <Link href="/search" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-search-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">البحث</span>
          </Link>
          <Link href="/sell" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-add-circle-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">بيع</span>
          </Link>
          <Link href="/my-ads" className="flex flex-col items-center py-2 text-green-600">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-advertisement-fill text-lg"></i>
            </div>
            <span className="text-xs mt-1">إعلاناتي</span>
          </Link>
          <Link href="/profile" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-user-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">الملف</span>
          </Link>
        </div>
      </div>
    </div>
  );
}


'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import AppLogo from '../components/AppLogo';
import { useLanguage } from '../components/LanguageProvider';
import LanguageSwitcher from '../components/LanguageSwitcher';
import ThemeSwitcher from '../components/ThemeSwitcher';

export default function Home() {
  const router = useRouter();
  const { language, t, isRTL, theme } = useLanguage();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState('OM');
  const [showCountryModal, setShowCountryModal] = useState(false);

  const countriesData = {
    OM: { 
      code: 'OM', 
      name: language === 'ar' ? 'عُمان' : 'Oman', 
      flag: '🇴🇲', 
      currency: language === 'ar' ? 'ريال عماني' : 'OMR',
      locations: language === 'ar' ? ['مسقط، عُمان', 'صلالة، عُمان', 'نزوى، عُمان', 'صحار، عُمان'] : ['Muscat, Oman', 'Salalah, Oman', 'Nizwa, Oman', 'Sohar, Oman']
    },
    SA: { 
      code: 'SA', 
      name: language === 'ar' ? 'السعودية' : 'Saudi Arabia', 
      flag: '🇸🇦', 
      currency: language === 'ar' ? 'ریال سعودی' : 'SAR',
      locations: language === 'ar' ? ['الرياض، السعودية', 'جدة، السعودية', 'الدمام، السعودية', 'مكة، السعودية'] : ['Riyadh, Saudi Arabia', 'Jeddah, Saudi Arabia', 'Dammam, Saudi Arabia', 'Mecca, Saudi Arabia']
    },
    AE: { 
      code: 'AE', 
      name: language === 'ar' ? 'الإمارات' : 'UAE', 
      flag: '🇦🇪', 
      currency: language === 'ar' ? 'درهم إماراتي' : 'AED',
      locations: language === 'ar' ? ['دبي، الإمارات', 'أبوظبي، الإمارات', 'الشارقة، الإمارات', 'العين، الإمارات'] : ['Dubai, UAE', 'Abu Dhabi, UAE', 'Sharjah, UAE', 'Al Ain, UAE']
    },
    KW: { 
      code: 'KW', 
      name: language === 'ar' ? 'الكويت' : 'Kuwait', 
      flag: '🇰🇼', 
      currency: language === 'ar' ? 'دينار كويتي' : 'KWD',
      locations: language === 'ar' ? ['مدينة الكويت، الكويت', 'الأحمدي، الكويت', 'حولي، الكويت', 'الفروانية، الكويت'] : ['Kuwait City, Kuwait', 'Ahmadi, Kuwait', 'Hawalli, Kuwait', 'Farwaniya, Kuwait']
    },
    QA: { 
      code: 'QA', 
      name: language === 'ar' ? 'قطر' : 'Qatar', 
      flag: '🇶🇦', 
      currency: language === 'ar' ? 'ریال قطری' : 'QAR',
      locations: language === 'ar' ? ['الدوحة، قطر', 'الريان، قطر', 'الوكرة، قطر', 'أم صلال، قطر'] : ['Doha, Qatar', 'Al Rayyan, Qatar', 'Al Wakrah, Qatar', 'Umm Salal, Qatar']
    },
    BH: { 
      code: 'BH', 
      name: language === 'ar' ? 'البحرين' : 'Bahrain', 
      flag: '🇧🇭', 
      currency: language === 'ar' ? 'دينار بحريني' : 'BHD',
      locations: language === 'ar' ? ['المنامة، البحرين', 'المحرق، البحرين', 'الرفاع، البحرين', 'عيسى، البحرين'] : ['Manama, Bahrain', 'Muharraq, Bahrain', 'Riffa, Bahrain', 'Isa, Bahrain']
    }
  };

  const countries = Object.values(countriesData);

  const categories = [
    { id: 'engine', name: t('engineParts'), icon: 'ri-settings-4-fill', color: 'text-blue-500' },
    { id: 'brakes', name: t('brakes'), icon: 'ri-stop-circle-fill', color: 'text-red-500' },
    { id: 'tires', name: t('tires'), icon: 'ri-steering-2-fill', color: 'text-green-500' },
    { id: 'lights', name: t('lights'), icon: 'ri-lightbulb-fill', color: 'text-yellow-500' },
    { id: 'transmission', name: t('transmission'), icon: 'ri-roadster-fill', color: 'text-purple-500' },
    { id: 'body', name: t('exterior'), icon: 'ri-car-fill', color: 'text-orange-500' }
  ];

  const getRecentPosts = (countryCode) => {
    const country = countriesData[countryCode];
    const locations = country.locations;
    const currency = country.currency;

    const basePosts = [
      {
        id: 1,
        titleAr: 'محرك كامري 2020 نظيف جداً',
        titleEn: 'Camry 2020 Engine Very Clean',
        basePrice: countryCode === 'OM' ? 850 : countryCode === 'SA' ? 950 : countryCode === 'AE' ? 920 : countryCode === 'KW' ? 270 : countryCode === 'QA' ? 870 : 230,
        image: 'https://readdy.ai/api/search-image?query=Car%20engine%20part%20clean%20automotive%20spare%20part%20realistic%20professional%20product%20photography%20isolated%20white%20background%20mechanical%20engine%20component&width=120&height=80&seq=engine_part_1&orientation=landscape',
        condition: t('new'),
        sellerAr: 'محمد أحمد',
        sellerEn: 'Mohammed Ahmed'
      },
      {
        id: 2,
        titleAr: 'فرامل BMW X5 أصلية',
        titleEn: 'Original BMW X5 Brakes',
        basePrice: countryCode === 'OM' ? 420 : countryCode === 'SA' ? 470 : countryCode === 'AE' ? 460 : countryCode === 'KW' ? 135 : countryCode === 'QA' ? 440 : 115,
        image: 'https://readdy.ai/api/search-image?query=BMW%20brake%20pads%20automotive%20spare%20parts%20professional%20product%20photography%20realistic%20brake%20disc%20clean%20isolated%20white%20background&width=120&height=80&seq=brake_part_1&orientation=landscape',
        condition: t('usedExcellent'),
        sellerAr: 'سالم الشيبي',
        sellerEn: 'Salem Al Shaibi'
      },
      {
        id: 3,
        titleAr: 'إطارات ميشلان 4 حبات',
        titleEn: 'Michelin Tires Set of 4',
        basePrice: countryCode === 'OM' ? 320 : countryCode === 'SA' ? 360 : countryCode === 'AE' ? 350 : countryCode === 'KW' ? 100 : countryCode === 'QA' ? 330 : 85,
        image: 'https://readdy.ai/api/search-image?query=Michelin%20car%20tires%20automotive%20spare%20parts%20professional%20product%20photography%20realistic%20tire%20clean%20isolated%20white%20background&width=120&height=80&seq=tire_part_1&orientation=landscape',
        condition: t('usedGood'),
        sellerAr: 'فاطمة الكندي',
        sellerEn: 'Fatima Al Kindi'
      },
      {
        id: 4,
        titleAr: 'مصابيح LED للسيارة',
        titleEn: 'LED Car Lights',
        basePrice: countryCode === 'OM' ? 75 : countryCode === 'SA' ? 85 : countryCode === 'AE' ? 80 : countryCode === 'KW' ? 25 : countryCode === 'QA' ? 78 : 20,
        image: 'https://readdy.ai/api/search-image?query=LED%20car%20headlight%20automotive%20spare%20parts%20professional%20product%20photography%20realistic%20light%20clean%20isolated%20white%20background&width=120&height=80&seq=light_part_1&orientation=landscape',
        condition: t('new'),
        sellerAr: 'عبدالله الرواحي',
        sellerEn: 'Abdullah Al Rawahi'
      }
    ];

    const toHijri = (gregorianDate) => {
      const options = { 
        calendar: 'islamic-umalqura',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
        locale: 'ar-SA'
      };
      return new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', options).format(gregorianDate);
    };

    const formatDualDate = (hoursAgo) => {
      const now = new Date();
      const postDate = new Date(now.getTime() - (hoursAgo * 60 * 60 * 1000));

      const gregorian = postDate.toLocaleDateString('ar-SA', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });

      const hijri = toHijri(postDate);

      if (language === 'ar') {
        if (hoursAgo < 24) {
          return `منذ ${hoursAgo} ساعة`;
        } else {
          const daysAgo = Math.floor(hoursAgo / 24);
          return `${gregorian} م - ${hijri.replace(/\\d+\\s*هـ/, '')} هـ${daysAgo === 1 ? ' (أمس)' : daysAgo < 7 ? ` (منذ ${daysAgo} أيام)` : ''}`;
        }
      } else {
        if (hoursAgo < 24) {
          return `${hoursAgo} hours ago`;
        } else {
          const daysAgo = Math.floor(hoursAgo / 24);
          return `${gregorian} - ${hijri}${daysAgo === 1 ? ' (Yesterday)' : daysAgo < 7 ? ` (${daysAgo} days ago)` : ''}`;
        }
      }
    };

    return basePosts.map((post, index) => ({
      ...post,
      title: language === 'ar' ? post.titleAr : post.titleEn,
      price: `${post.basePrice} ${currency}`,
      location: locations[index % locations.length],
      time: t('posted') + ' ' + formatDualDate(index < 2 ? 3 : 6),
      seller: language === 'ar' ? post.sellerAr : post.sellerEn
    }));
  };

  const [recentPosts, setRecentPosts] = useState(getRecentPosts('OM'));

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';
    setIsLoggedIn(loggedIn);

    const savedCountry = localStorage.getItem('selectedCountry') || 'OM';
    setSelectedCountry(savedCountry);
    setRecentPosts(getRecentPosts(savedCountry));
  }, []);

  useEffect(() => {
    setRecentPosts(getRecentPosts(selectedCountry));
  }, [selectedCountry, language]);

  const handleCountryChange = (countryCode) => {
    setSelectedCountry(countryCode);
    localStorage.setItem('selectedCountry', countryCode);
    setShowCountryModal(false);
    setRecentPosts(getRecentPosts(countryCode));
  };

  return (
    <div className={`min-h-screen relative overflow-hidden transition-colors duration-300 ${theme === 'dark' ? 'bg-gray-900 text-white' : 'bg-gradient-to-br from-blue-50 to-indigo-100 text-gray-900'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Navigation Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 p-4">
        <div className="flex items-center justify-between">
          {/* Left Side - Theme Toggle */}
          <div className="flex items-center">
            <ThemeSwitcher />
          </div>

          {/* Right Side - Language and Country */}
          <div className="flex items-center space-x-3 space-x-reverse">
            {/* Language Toggle */}
            <LanguageSwitcher />

            {/* Country Flag */}
            <button
              onClick={() => setShowCountryModal(true)}
              className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-white/80 hover:bg-white shadow-sm'}`}
            >
              <span className="text-lg">{countriesData[selectedCountry]?.flag}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Country Selection Modal */}
      {showCountryModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className={`rounded-lg w-full max-w-sm transition-colors ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
            <div className={`p-4 border-b transition-colors ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
              <div className="flex items-center justify-between">
                <h3 className={`text-lg font-bold transition-colors ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  {t('selectCountry')}
                </h3>
                <button
                  onClick={() => setShowCountryModal(false)}
                  className={`w-8 h-8 flex items-center justify-center rounded-full !rounded-button transition-colors ${theme === 'dark' ? 'text-gray-400 hover:bg-gray-700' : 'text-gray-500 hover:bg-gray-100'}`}
                >
                  <i className="ri-close-line"></i>
                </button>
              </div>
            </div>
            <div className="p-4 max-h-80 overflow-y-auto">
              {countries.map((country) => (
                <button
                  key={country.code}
                  onClick={() => handleCountryChange(country.code)}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg mb-2 transition-colors !rounded-button ${selectedCountry === country.code ? 'bg-red-50 dark:bg-red-900/30 border-2 border-red-500' : theme === 'dark' ? 'hover:bg-gray-700 border-2 border-transparent' : 'hover:bg-gray-50 border-2 border-transparent'} ${isRTL ? 'text-right' : 'text-left'}`}
                >
                  <span className="text-xl">{country.flag}</span>
                  <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                    <div className={`font-medium transition-colors ${selectedCountry === country.code ? 'text-red-800 dark:text-red-200' : theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
                      {country.name}
                    </div>
                    <div className={`text-sm transition-colors ${selectedCountry === country.code ? 'text-red-600 dark:text-red-300' : theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                      {country.currency}
                    </div>
                  </div>
                  {selectedCountry === country.code && (
                    <i className="ri-check-line text-red-500 text-xl"></i>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="pt-16 px-6 text-center">
        {/* Title */}
        <h1 className="text-red-500 text-lg font-medium mb-3">{t('appName')}</h1>

        {/* Main Heading */}
        <h2 className={`text-2xl font-bold mb-2 transition-colors ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
          {t('appDescription')}
        </h2>
        <p className={`text-xl mb-4 transition-colors ${theme === 'dark' ? 'text-gray-200' : 'text-gray-800'}`}>
          {t('welcome')}
        </p>

        {/* Subtitle */}
        <p className={`mb-8 max-w-xs mx-auto transition-colors ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
          {t('welcomeMessage')}
        </p>

        {/* Main Image */}
        <div className="mb-8">
          <div className="relative rounded-2xl overflow-hidden mx-auto max-w-sm">
            <img
              src="https://readdy.ai/api/search-image?query=Car%20parts%20warehouse%20interior%20with%20automotive%20spare%20parts%20on%20shelves%2C%20tires%2C%20engine%20components%2C%20professional%20automotive%20parts%20storage%2C%20realistic%20industrial%20warehouse%2C%20organized%20car%20parts%20inventory%2C%20automotive%20spare%20parts%20shop%20interior%2C%20mechanical%20workshop%20warehouse&width=400&height=300&seq=warehouse_main_v3&orientation=landscape"
              alt={t('appDescription')}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
            <div className="absolute bottom-4 left-4 right-4 text-center">
              <h3 className="text-white font-bold text-lg mb-1">
                {language === 'ar' ? 'أفضل منصة لقطع غيار السيارات' : 'Best Auto Parts Platform'}
              </h3>
              <p className="text-white/80 text-sm">
                {language === 'ar' ? 'اشتري وبع قطع الغيار بثقة وأمان' : 'Buy and sell auto parts with confidence'}
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto mb-8">
          {/* Sell Button */}
          <Link
            href="/sell"
            className="bg-green-600 hover:bg-green-700 transition-colors rounded-2xl p-6 text-center"
          >
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mx-auto mb-3">
              <i className="ri-money-dollar-circle-line text-white text-xl"></i>
            </div>
            <h3 className="text-white font-bold text-lg mb-1">{t('sell')}</h3>
            <p className="text-white/80 text-sm">{t('sellSubtitle')}</p>
          </Link>

          {/* Buy Button */}
          <Link
            href="/buy"
            className="bg-red-600 hover:bg-red-700 transition-colors rounded-2xl p-6 text-center"
          >
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mx-auto mb-3">
              <i className="ri-shopping-cart-line text-white text-xl"></i>
            </div>
            <h3 className="text-white font-bold text-lg mb-1">{t('buy')}</h3>
            <p className="text-white/80 text-sm">{t('buySubtitle')}</p>
          </Link>
        </div>

        {/* Categories Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <Link
              href="/search"
              className={`text-sm transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-gray-700'}`}
            >
              {t('viewAll')}
            </Link>
            <h4 className={`font-medium transition-colors ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
              {t('browseCategories')}
            </h4>
          </div>

          <div className="grid grid-cols-3 gap-4">
            {categories.map((category) => (
              <Link
                key={category.id}
                href={`/search?category=${category.id}`}
                className={`rounded-xl p-4 text-center transition-all border ${theme === 'dark' ? 'bg-gray-800/50 hover:bg-gray-800 backdrop-blur-sm border-gray-700/50' : 'bg-white/60 hover:bg-white/80 backdrop-blur-sm border-white/50 shadow-sm hover:shadow-md'}`}
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-3 ${theme === 'dark' ? 'bg-gray-700/50' : 'bg-gray-100/80'}`}>
                  <i className={`${category.icon} text-xl ${category.color}`}></i>
                </div>
                <span className={`text-sm font-medium transition-colors ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {category.name}
                </span>
              </Link>
            ))}
          </div>
        </div>

        {/* Recent Posts Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <Link
              href="/search"
              className={`text-sm transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-gray-700'}`}
            >
              {t('viewAll')}
            </Link>
            <h4 className={`font-medium transition-colors ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
              {t('latestAds')}
            </h4>
          </div>

          <div className="space-y-3">
            {recentPosts.map((post) => (
              <div
                key={post.id}
                className={`rounded-xl p-4 border transition-all cursor-pointer ${theme === 'dark' ? 'bg-gray-800/50 hover:bg-gray-800 backdrop-blur-sm border-gray-700/50' : 'bg-white/60 hover:bg-white/80 backdrop-blur-sm border-white/50 shadow-sm hover:shadow-md'}`}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-16 h-12 rounded-lg overflow-hidden flex-shrink-0 ${theme === 'dark' ? 'bg-gray-700' : 'bg-gray-200'}`}>
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-2">
                      <h5 className={`text-sm font-medium truncate max-w-[180px] transition-colors ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
                        {post.title}
                      </h5>
                      <span className="text-red-400 text-sm font-bold flex-shrink-0">
                        {post.price}
                      </span>
                    </div>

                    <div className={`flex items-center justify-between text-xs transition-colors ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                      <div className="flex items-center gap-2">
                        <span className="flex items-center gap-1">
                          <i className="ri-map-pin-line"></i>
                          {post.location}
                        </span>
                        <span className={`w-1 h-1 rounded-full ${theme === 'dark' ? 'bg-gray-500' : 'bg-gray-400'}`}></span>
                        <span>{post.time}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full">
                          {post.condition}
                        </span>
                      </div>
                    </div>

                    <div className={`mt-2 text-xs transition-colors ${theme === 'dark' ? 'text-gray-500' : 'text-gray-500'}`}>
                      {t('seller')}: {post.seller}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer with Copyright */}
        <div className={`text-center pb-24 border-t pt-6 transition-colors ${theme === 'dark' ? 'border-gray-700/50' : 'border-gray-200/50'}`}>
          <div className="flex items-center justify-center gap-2 mb-3">
            <div className="w-8 h-8 flex-shrink-0">
              <img
                src="https://static.readdy.ai/image/5aa11a9b42a4af1edfb3496074645b1b/66797699dd7260be309c579860fd62bc.png"
                alt="Logo"
                className="w-full h-full object-contain"
              />
            </div>
            <span className={`text-sm font-medium transition-colors ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
              {language === 'ar' ? 'مطور بواسطة' : 'Powered by'}
            </span>
          </div>
          <p className={`text-xs transition-colors ${theme === 'dark' ? 'text-gray-500' : 'text-gray-500'}`}>
            {language === 'ar' ? ' 2024 جميع الحقوق محفوظة' : ' 2024 All Rights Reserved'}
          </p>
        </div>

      </div>

      {/* Background Decorative Elements */}
      <div className="absolute top-1/4 left-4 w-32 h-32 bg-blue-600/10 rounded-full blur-2xl"></div>
      <div className="absolute bottom-1/4 right-4 w-40 h-40 bg-red-600/10 rounded-full blur-2xl"></div>

      {/* Bottom Navigation */}
      <div className={`fixed bottom-0 left-0 right-0 border-t z-50 transition-colors ${theme === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-white/95 backdrop-blur-md border-gray-200'}`}>
        <div className="grid grid-cols-5 py-2">
          <Link href="/" className="flex flex-col items-center py-2 text-red-500">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-home-fill text-lg"></i>
            </div>
            <span className="text-xs mt-1 font-medium">{t('home')}</span>
          </Link>
          <Link href="/search" className={`flex flex-col items-center py-2 transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700'}`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-search-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('search')}</span>
          </Link>
          <Link href="/chat" className={`flex flex-col items-center py-2 transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700'}`}>
            <div className="w-6 h-6 flex items-center justify-center relative">
              <i className="ri-chat-3-line text-lg"></i>
              {isLoggedIn && (
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                  <span className="text-xs text-white font-bold">3</span>
                </div>
              )}
            </div>
            <span className="text-xs mt-1">{t('chat')}</span>
          </Link>
          <Link href="/favorites" className={`flex flex-col items-center py-2 transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700'}`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-heart-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('favorites')}</span>
          </Link>
          <Link href="/profile" className={`flex flex-col items-center py-2 transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700'}`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-user-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('profile')}</span>
          </Link>
        </div>
      </div>
    </div>
  );
}


'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function AdminDashboard() {
  const router = useRouter();
  const [isAdmin, setIsAdmin] = useState(false);
  const [stats, setStats] = useState({
    totalUsers: 1245,
    totalProducts: 356,
    activeChats: 89,
    pendingReports: 12,
    totalSales: 45600,
    newUsersToday: 23,
    newProductsToday: 15,
    activeUsersNow: 178
  });

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';

    // فحص صلاحيات المدير
    if (!isLoggedIn || user.phone !== '96895977544') {
      router.push('/login');
      return;
    }

    setIsAdmin(true);
  }, [router]);

  const adminCards = [
    {
      title: 'إدارة المستخدمين',
      subtitle: 'عرض وإدارة جميع المستخدمين',
      icon: 'ri-user-settings-line',
      color: 'blue',
      href: '/admin/users',
      count: stats.totalUsers
    },
    {
      title: 'إدارة المنتجات',
      subtitle: 'مراجعة وإدارة الإعلانات',
      icon: 'ri-product-hunt-line',
      color: 'green',
      href: '/admin/products',
      count: stats.totalProducts
    },
    {
      title: 'المحادثات',
      subtitle: 'مراقبة المحادثات والدعم',
      icon: 'ri-chat-3-line',
      color: 'purple',
      href: '/admin/chats',
      count: stats.activeChats
    },
    {
      title: 'التقارير والشكاوي',
      subtitle: 'مراجعة التقارير المرسلة',
      icon: 'ri-flag-line',
      color: 'red',
      href: '/admin/reports',
      count: stats.pendingReports
    },
    {
      title: 'إدارة الفئات',
      subtitle: 'إضافة وتعديل فئات المنتجات',
      icon: 'ri-folder-settings-line',
      color: 'orange',
      href: '/admin/categories',
      count: 0
    },
    {
      title: 'الإعدادات العامة',
      subtitle: 'إعدادات التطبيق والنظام',
      icon: 'ri-settings-3-line',
      color: 'gray',
      href: '/admin/settings',
      count: 0
    }
  ];

  const quickStats = [
    {
      title: 'إجمالي المبيعات',
      value: `${stats.totalSales.toLocaleString()} ر.س`,
      icon: 'ri-money-dollar-circle-line',
      color: 'green',
      trend: '+12%'
    },
    {
      title: 'مستخدمون جدد اليوم',
      value: stats.newUsersToday.toString(),
      icon: 'ri-user-add-line',
      color: 'blue',
      trend: '+8%'
    },
    {
      title: 'منتجات جديدة اليوم',
      value: stats.newProductsToday.toString(),
      icon: 'ri-add-circle-line',
      color: 'purple',
      trend: '+15%'
    },
    {
      title: 'متصلون الآن',
      value: stats.activeUsersNow.toString(),
      icon: 'ri-user-line',
      color: 'orange',
      trend: 'متصل'
    }
  ];

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">جاري التحقق من الصلاحيات...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-20">
      {/* Navigation Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 shadow-sm">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center ml-3">
              <i className="ri-admin-line text-white text-lg"></i>
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-800 dark:text-white">لوحة التحكم الإدارية</h1>
              <p className="text-xs text-gray-600 dark:text-gray-400">مرحباً بك أيها المدير</p>
            </div>
          </div>
          <div className="flex items-center space-x-2 space-x-reverse">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="text-xs text-green-600 dark:text-green-400 font-medium">متصل</span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 px-4">
        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          {quickStats.map((stat, index) => (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
              <div className="flex items-center justify-between mb-2">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  stat.color === 'green' ? 'bg-green-100 dark:bg-green-900/30' :
                  stat.color === 'blue' ? 'bg-blue-100 dark:bg-blue-900/30' :
                  stat.color === 'purple' ? 'bg-purple-100 dark:bg-purple-900/30' :
                  'bg-orange-100 dark:bg-orange-900/30'
                }`}>
                  <i className={`${stat.icon} text-lg ${
                    stat.color === 'green' ? 'text-green-600 dark:text-green-400' :
                    stat.color === 'blue' ? 'text-blue-600 dark:text-blue-400' :
                    stat.color === 'purple' ? 'text-purple-600 dark:text-purple-400' :
                    'text-orange-600 dark:text-orange-400'
                  }`}></i>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  stat.trend.includes('+') ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400' :
                  'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400'
                }`}>
                  {stat.trend}
                </span>
              </div>
              <div className="text-xl font-bold text-gray-800 dark:text-white mb-1">{stat.value}</div>
              <div className="text-xs text-gray-600 dark:text-gray-400">{stat.title}</div>
            </div>
          ))}
        </div>

        {/* Admin Cards */}
        <div className="space-y-4 mb-6">
          {adminCards.map((card, index) => (
            <Link 
              key={index}
              href={card.href}
              className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl p-4 flex items-center space-x-4 space-x-reverse shadow-sm hover:shadow-md transition-all hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                card.color === 'blue' ? 'bg-blue-100 dark:bg-blue-900/30' :
                card.color === 'green' ? 'bg-green-100 dark:bg-green-900/30' :
                card.color === 'purple' ? 'bg-purple-100 dark:bg-purple-900/30' :
                card.color === 'red' ? 'bg-red-100 dark:bg-red-900/30' :
                card.color === 'orange' ? 'bg-orange-100 dark:bg-orange-900/30' :
                'bg-gray-100 dark:bg-gray-700'
              }`}>
                <i className={`${card.icon} text-xl ${
                  card.color === 'blue' ? 'text-blue-600 dark:text-blue-400' :
                  card.color === 'green' ? 'text-green-600 dark:text-green-400' :
                  card.color === 'purple' ? 'text-purple-600 dark:text-purple-400' :
                  card.color === 'red' ? 'text-red-600 dark:text-red-400' :
                  card.color === 'orange' ? 'text-orange-600 dark:text-orange-400' :
                  'text-gray-600 dark:text-gray-400'
                }`}></i>
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="font-semibold text-gray-800 dark:text-white text-sm">{card.title}</h4>
                  {card.count > 0 && (
                    <span className="bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs px-2 py-1 rounded-full font-medium">
                      {card.count}
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-600 dark:text-gray-400">{card.subtitle}</p>
              </div>
              <i className="ri-arrow-left-s-line text-gray-400 dark:text-gray-500"></i>
            </Link>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 border border-gray-100 dark:border-gray-700 shadow-sm mb-6">
          <h3 className="font-bold text-gray-800 dark:text-white mb-4">إجراءات سريعة</h3>
          <div className="grid grid-cols-2 gap-3">
            <button className="bg-red-600 text-white p-3 rounded-xl text-center text-sm font-medium !rounded-button hover:bg-red-700 transition-colors">
              <i className="ri-notification-3-line text-lg mb-1 block"></i>
              إرسال إشعار عام
            </button>
            <button className="bg-blue-600 text-white p-3 rounded-xl text-center text-sm font-medium !rounded-button hover:bg-blue-700 transition-colors">
              <i className="ri-file-download-line text-lg mb-1 block"></i>
              تصدير البيانات
            </button>
            <button className="bg-green-600 text-white p-3 rounded-xl text-center text-sm font-medium !rounded-button hover:bg-green-700 transition-colors">
              <i className="ri-refresh-line text-lg mb-1 block"></i>
              تحديث النظام
            </button>
            <button className="bg-purple-600 text-white p-3 rounded-xl text-center text-sm font-medium !rounded-button hover:bg-purple-700 transition-colors">
              <i className="ri-bar-chart-line text-lg mb-1 block"></i>
              تقرير شامل
            </button>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 border border-gray-100 dark:border-gray-700 shadow-sm">
          <h3 className="font-bold text-gray-800 dark:text-white mb-4">النشاطات الأخيرة</h3>
          <div className="space-y-3">
            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="w-8 h-8 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center">
                <i className="ri-user-add-line text-green-600 dark:text-green-400 text-sm"></i>
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-800 dark:text-white">انضم مستخدم جديد: أحمد محمد</p>
                <p className="text-xs text-gray-600 dark:text-gray-400">منذ 5 دقائق</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center">
                <i className="ri-add-circle-line text-blue-600 dark:text-blue-400 text-sm"></i>
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-800 dark:text-white">منتج جديد: محرك كامري 2020</p>
                <p className="text-xs text-gray-600 dark:text-gray-400">منذ 15 دقيقة</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="w-8 h-8 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center">
                <i className="ri-flag-line text-red-600 dark:text-red-400 text-sm"></i>
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-800 dark:text-white">تقرير नय على منتج رقم #1234</p>
                <p className="text-xs text-gray-600 dark:text-gray-400">منذ 30 دقيقة</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Admin Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 z-50">
        <div className="grid grid-cols-4 py-2">
          <Link href="/admin" className="flex flex-col items-center py-2 text-red-600 dark:text-red-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-dashboard-fill text-lg"></i>
            </div>
            <span className="text-xs mt-1 font-medium">الرئيسية</span>
          </Link>
          <Link href="/admin/users" className="flex flex-col items-center py-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-user-settings-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">المستخدمون</span>
          </Link>
          <Link href="/admin/products" className="flex flex-col items-center py-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-product-hunt-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">المنتجات</span>
          </Link>
          <Link href="/" className="flex flex-col items-center py-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-logout-box-r-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">خروج</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

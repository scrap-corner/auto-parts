'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface Category {
  id: string;
  name: string;
  nameEn: string;
  icon: string;
  color: string;
  description: string;
  isActive: boolean;
  productsCount: number;
}

export default function CategoriesManagement() {
  const router = useRouter();
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const [categories, setCategories] = useState<Category[]>([
    {
      id: '1',
      name: 'قطع المحرك',
      nameEn: 'Engine Parts',
      icon: 'ri-settings-2-line',
      color: 'blue',
      description: 'جميع قطع المحرك والأجزاء المتعلقة به',
      isActive: true,
      productsCount: 156
    },
    {
      id: '2',
      name: 'نظام الفرامل',
      nameEn: 'Brake System',
      icon: 'ri-brake-line',
      color: 'red',
      description: 'قطع الفرامل والأقراص والأحذية',
      isActive: true,
      productsCount: 89
    },
    {
      id: '3',
      name: 'الإطارات والجنوط',
      nameEn: 'Tires & Rims',
      icon: 'ri-tire-line',
      color: 'green',
      description: 'الإطارات والجنوط بجميع الأحجام',
      isActive: true,
      productsCount: 234
    },
    {
      id: '4',
      name: 'نظام الإضاءة',
      nameEn: 'Lighting System',
      icon: 'ri-lightbulb-line',
      color: 'yellow',
      description: 'المصابيح والأنوار الأمامية والخلفية',
      isActive: true,
      productsCount: 67
    },
    {
      id: '5',
      name: 'قطع الهيكل',
      nameEn: 'Body Parts',
      icon: 'ri-car-line',
      color: 'purple',
      description: 'قطع هيكل السيارة والصدام والأبواب',
      isActive: false,
      productsCount: 45
    }
  ]);

  const [newCategory, setNewCategory] = useState({
    name: '',
    nameEn: '',
    icon: 'ri-folder-line',
    color: 'blue',
    description: '',
    isActive: true
  });

  const colors = [
    { name: 'أزرق', value: 'blue', class: 'bg-blue-500' },
    { name: 'أحمر', value: 'red', class: 'bg-red-500' },
    { name: 'أخضر', value: 'green', class: 'bg-green-500' },
    { name: 'أصفر', value: 'yellow', class: 'bg-yellow-500' },
    { name: 'بنفسجي', value: 'purple', class: 'bg-purple-500' },
    { name: 'برتقالي', value: 'orange', class: 'bg-orange-500' },
    { name: 'وردي', value: 'pink', class: 'bg-pink-500' },
    { name: 'رمادي', value: 'gray', class: 'bg-gray-500' }
  ];

  const icons = [
    'ri-settings-2-line', 'ri-brake-line', 'ri-tire-line', 'ri-lightbulb-line',
    'ri-car-line', 'ri-oil-line', 'ri-battery-line', 'ri-air-conditioner-line',
    'ri-steering-wheel-line', 'ri-dashboard-line', 'ri-tools-line', 'ri-wrench-line',
    'ri-folder-line', 'ri-stack-line', 'ri-grid-line', 'ri-apps-line'
  ];

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';

    if (!isLoggedIn || user.phone !== '96895977544') {
      router.push('/login');
      return;
    }

    setIsAdmin(true);
  }, [router]);

  const filteredCategories = categories.filter(category =>
    category.name.includes(searchQuery) ||
    category.nameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
    category.description.includes(searchQuery)
  );

  const handleAddCategory = () => {
    if (!newCategory.name.trim() || !newCategory.nameEn.trim()) return;

    const category: Category = {
      id: Date.now().toString(),
      ...newCategory,
      productsCount: 0
    };

    setCategories([...categories, category]);
    setNewCategory({
      name: '',
      nameEn: '',
      icon: 'ri-folder-line',
      color: 'blue',
      description: '',
      isActive: true
    });
    setShowAddModal(false);
  };

  const handleEditCategory = (category: Category) => {
    setEditingCategory(category);
    setShowEditModal(true);
  };

  const handleUpdateCategory = () => {
    if (!editingCategory) return;

    setCategories(categories.map(cat =>
      cat.id === editingCategory.id ? editingCategory : cat
    ));
    setEditingCategory(null);
    setShowEditModal(false);
  };

  const handleDeleteCategory = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا القسم؟')) {
      setCategories(categories.filter(cat => cat.id !== id));
    }
  };

  const toggleCategoryStatus = (id: string) => {
    setCategories(categories.map(cat =>
      cat.id === id ? { ...cat, isActive: !cat.isActive } : cat
    ));
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">جاري التحقق من الصلاحيات...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-20">
      {/* Navigation Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 shadow-sm">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <Link href="/admin" className="ml-3">
              <i className="ri-arrow-right-line text-xl text-gray-600 dark:text-gray-400"></i>
            </Link>
            <div>
              <h1 className="text-lg font-bold text-gray-800 dark:text-white">إدارة الأقسام</h1>
              <p className="text-xs text-gray-600 dark:text-gray-400">{categories.length} قسم إجمالي</p>
            </div>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="bg-blue-600 text-white p-2 rounded-xl !rounded-button hover:bg-blue-700 transition-colors"
          >
            <i className="ri-add-line text-lg"></i>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 px-4">
        {/* Search Bar */}
        <div className="mb-6">
          <div className="relative">
            <input
              type="text"
              placeholder="البحث في الأقسام..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-4 pr-12 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 text-sm"
            />
            <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
              <i className="ri-search-line text-gray-400 text-lg"></i>
            </div>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-3 text-center border border-gray-100 dark:border-gray-700">
            <div className="text-lg font-bold text-blue-600 dark:text-blue-400">{categories.length}</div>
            <div className="text-xs text-gray-600 dark:text-gray-400">إجمالي الأقسام</div>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-xl p-3 text-center border border-gray-100 dark:border-gray-700">
            <div className="text-lg font-bold text-green-600 dark:text-green-400">
              {categories.filter(cat => cat.isActive).length}
            </div>
            <div className="text-xs text-gray-600 dark:text-gray-400">أقسام نشطة</div>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-xl p-3 text-center border border-gray-100 dark:border-gray-700">
            <div className="text-lg font-bold text-purple-600 dark:text-purple-400">
              {categories.reduce((sum, cat) => sum + cat.productsCount, 0)}
            </div>
            <div className="text-xs text-gray-600 dark:text-gray-400">إجمالي المنتجات</div>
          </div>
        </div>

        {/* Categories List */}
        <div className="space-y-3">
          {filteredCategories.map((category) => (
            <div key={category.id} className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    category.color === 'blue' ? 'bg-blue-100 dark:bg-blue-900/30' :
                    category.color === 'red' ? 'bg-red-100 dark:bg-red-900/30' :
                    category.color === 'green' ? 'bg-green-100 dark:bg-green-900/30' :
                    category.color === 'yellow' ? 'bg-yellow-100 dark:bg-yellow-900/30' :
                    category.color === 'purple' ? 'bg-purple-100 dark:bg-purple-900/30' :
                    category.color === 'orange' ? 'bg-orange-100 dark:bg-orange-900/30' :
                    category.color === 'pink' ? 'bg-pink-100 dark:bg-pink-900/30' :
                    'bg-gray-100 dark:bg-gray-700'
                  }`}>
                    <i className={`${category.icon} text-lg ${
                      category.color === 'blue' ? 'text-blue-600 dark:text-blue-400' :
                      category.color === 'red' ? 'text-red-600 dark:text-red-400' :
                      category.color === 'green' ? 'text-green-600 dark:text-green-400' :
                      category.color === 'yellow' ? 'text-yellow-600 dark:text-yellow-400' :
                      category.color === 'purple' ? 'text-purple-600 dark:text-purple-400' :
                      category.color === 'orange' ? 'text-orange-600 dark:text-orange-400' :
                      category.color === 'pink' ? 'text-pink-600 dark:text-pink-400' :
                      'text-gray-600 dark:text-gray-400'
                    }`}></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800 dark:text-white text-sm">{category.name}</h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{category.nameEn}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    category.isActive 
                      ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400'
                      : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400'
                  }`}>
                    {category.isActive ? 'نشط' : 'معطل'}
                  </span>
                  <span className="bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs px-2 py-1 rounded-full font-medium">
                    {category.productsCount}
                  </span>
                </div>
              </div>

              <p className="text-xs text-gray-600 dark:text-gray-400 mb-3">{category.description}</p>

              <div className="flex items-center justify-between">
                <div className="flex space-x-2 space-x-reverse">
                  <button
                    onClick={() => handleEditCategory(category)}
                    className="bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 px-3 py-1 rounded-lg text-xs font-medium hover:bg-blue-200 dark:hover:bg-blue-900/50 transition-colors"
                  >
                    <i className="ri-edit-line ml-1"></i>
                    تعديل
                  </button>
                  <button
                    onClick={() => toggleCategoryStatus(category.id)}
                    className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                      category.isActive
                        ? 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                        : 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 hover:bg-green-200 dark:hover:bg-green-900/50'
                    }`}
                  >
                    <i className={`${category.isActive ? 'ri-pause-line' : 'ri-play-line'} ml-1`}></i>
                    {category.isActive ? 'إيقاف' : 'تفعيل'}
                  </button>
                </div>
                <button
                  onClick={() => handleDeleteCategory(category.id)}
                  className="bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 px-3 py-1 rounded-lg text-xs font-medium hover:bg-red-200 dark:hover:bg-red-900/50 transition-colors"
                >
                  <i className="ri-delete-bin-line ml-1"></i>
                  حذف
                </button>
              </div>
            </div>
          ))}

          {filteredCategories.length === 0 && (
            <div className="text-center py-12">
              <i className="ri-folder-open-line text-4xl text-gray-300 dark:text-gray-600 mb-4 block"></i>
              <p className="text-gray-500 dark:text-gray-400">لا توجد أقسام مطابقة للبحث</p>
            </div>
          )}
        </div>
      </div>

      {/* Add Category Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end justify-center">
          <div className="bg-white dark:bg-gray-800 w-full max-w-md rounded-t-2xl p-6 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-bold text-gray-800 dark:text-white">إضافة قسم جديد</h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  اسم القسم (العربية)
                </label>
                <input
                  type="text"
                  value={newCategory.name}
                  onChange={(e) => setNewCategory({...newCategory, name: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white text-sm"
                  placeholder="مثال: قطع المحرك"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  اسم القسم (الإنجليزية)
                </label>
                <input
                  type="text"
                  value={newCategory.nameEn}
                  onChange={(e) => setNewCategory({...newCategory, nameEn: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white text-sm"
                  placeholder="Example: Engine Parts"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  الوصف
                </label>
                <textarea
                  value={newCategory.description}
                  onChange={(e) => setNewCategory({...newCategory, description: e.target.value})}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white text-sm resize-none"
                  placeholder="وصف مختصر للقسم..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  الأيقونة
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {icons.map((icon) => (
                    <button
                      key={icon}
                      onClick={() => setNewCategory({...newCategory, icon})}
                      className={`p-2 rounded-lg border-2 transition-colors ${
                        newCategory.icon === icon
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30'
                          : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                      }`}
                    >
                      <i className={`${icon} text-lg text-gray-600 dark:text-gray-400`}></i>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  اللون
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {colors.map((color) => (
                    <button
                      key={color.value}
                      onClick={() => setNewCategory({...newCategory, color: color.value})}
                      className={`p-2 rounded-lg border-2 transition-colors ${
                        newCategory.color === color.value
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30'
                          : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                      }`}
                    >
                      <div className={`w-6 h-6 rounded-full ${color.class} mx-auto`}></div>
                      <span className="text-xs text-gray-600 dark:text-gray-400 mt-1 block">{color.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700 dark:text-gray-300">حالة القسم</span>
                <button
                  onClick={() => setNewCategory({...newCategory, isActive: !newCategory.isActive})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    newCategory.isActive ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-600'
                  }`}
                >
                  <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    newCategory.isActive ? 'translate-x-6' : 'translate-x-1'
                  }`} />
                </button>
              </div>
            </div>

            <div className="flex space-x-3 space-x-reverse mt-6">
              <button
                onClick={() => setShowAddModal(false)}
                className="flex-1 py-2 border border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-xl font-medium !rounded-button hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={handleAddCategory}
                className="flex-1 py-2 bg-blue-600 text-white rounded-xl font-medium !rounded-button hover:bg-blue-700 transition-colors"
              >
                إضافة القسم
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Category Modal */}
      {showEditModal && editingCategory && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end justify-center">
          <div className="bg-white dark:bg-gray-800 w-full max-w-md rounded-t-2xl p-6 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-bold text-gray-800 dark:text-white">تعديل القسم</h2>
              <button
                onClick={() => setShowEditModal(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  اسم القسم (العربية)
                </label>
                <input
                  type="text"
                  value={editingCategory.name}
                  onChange={(e) => setEditingCategory({...editingCategory, name: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white text-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  اسم القسم (الإنجليزية)
                </label>
                <input
                  type="text"
                  value={editingCategory.nameEn}
                  onChange={(e) => setEditingCategory({...editingCategory, nameEn: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white text-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  الوصف
                </label>
                <textarea
                  value={editingCategory.description}
                  onChange={(e) => setEditingCategory({...editingCategory, description: e.target.value})}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white text-sm resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  الأيقونة
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {icons.map((icon) => (
                    <button
                      key={icon}
                      onClick={() => setEditingCategory({...editingCategory, icon})}
                      className={`p-2 rounded-lg border-2 transition-colors ${
                        editingCategory.icon === icon
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30'
                          : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                      }`}
                    >
                      <i className={`${icon} text-lg text-gray-600 dark:text-gray-400`}></i>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  اللون
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {colors.map((color) => (
                    <button
                      key={color.value}
                      onClick={() => setEditingCategory({...editingCategory, color: color.value})}
                      className={`p-2 rounded-lg border-2 transition-colors ${
                        editingCategory.color === color.value
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30'
                          : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                      }`}
                    >
                      <div className={`w-6 h-6 rounded-full ${color.class} mx-auto`}></div>
                      <span className="text-xs text-gray-600 dark:text-gray-400 mt-1 block">{color.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700 dark:text-gray-300">حالة القسم</span>
                <button
                  onClick={() => setEditingCategory({...editingCategory, isActive: !editingCategory.isActive})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    editingCategory.isActive ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-600'
                  }`}
                >
                  <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    editingCategory.isActive ? 'translate-x-6' : 'translate-x-1'
                  }`} />
                </button>
              </div>
            </div>

            <div className="flex space-x-3 space-x-reverse mt-6">
              <button
                onClick={() => setShowEditModal(false)}
                className="flex-1 py-2 border border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-xl font-medium !rounded-button hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={handleUpdateCategory}
                className="flex-1 py-2 bg-blue-600 text-white rounded-xl font-medium !rounded-button hover:bg-blue-700 transition-colors"
              >
                حفظ التعديلات
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 z-50">
        <div className="grid grid-cols-4 py-2">
          <Link href="/admin" className="flex flex-col items-center py-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-dashboard-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">الرئيسية</span>
          </Link>
          <Link href="/admin/users" className="flex flex-col items-center py-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-user-settings-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">المستخدمون</span>
          </Link>
          <Link href="/admin/products" className="flex flex-col items-center py-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-product-hunt-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">المنتجات</span>
          </Link>
          <Link href="/admin/categories" className="flex flex-col items-center py-2 text-blue-600 dark:text-blue-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-folder-settings-fill text-lg"></i>
            </div>
            <span className="text-xs mt-1 font-medium">الأقسام</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
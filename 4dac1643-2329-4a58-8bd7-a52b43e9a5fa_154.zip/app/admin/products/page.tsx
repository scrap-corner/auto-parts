
'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface Product {
  id: number;
  title: string;
  price: number;
  category: string;
  seller: string;
  image: string;
  status: 'active' | 'pending' | 'rejected' | 'sold';
  dateAdded: string;
  views: number;
  reports: number;
}

export default function AdminProducts() {
  const router = useRouter();
  const [isAdmin, setIsAdmin] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [editForm, setEditForm] = useState({
    title: '',
    price: 0,
    category: '',
    status: 'active' as 'active' | 'pending' | 'rejected' | 'sold'
  });
  const [products, setProducts] = useState<Product[]>([
    {
      id: 1,
      title: 'محرك تويوتا كامري 2020',
      price: 8500,
      category: 'أجزاء المحرك',
      seller: 'أحمد محمد',
      image: 'https://readdy.ai/api/search-image?query=Toyota%20Camry%20engine%202020%2C%20car%20engine%20parts%2C%20automotive%20engine&width=120&height=80&seq=engine1&orientation=landscape',
      status: 'active',
      dateAdded: '2024-02-01',
      views: 156,
      reports: 0
    },
    {
      id: 2,
      title: 'باب أمامي يمين هونداي النترا',
      price: 1200,
      category: 'أبواب',
      seller: 'فاطمة عبدالله',
      image: 'https://readdy.ai/api/search-image?query=Car%20door%20parts%2C%20Hyundai%20Elantra%20front%20door%2C%20automotive%20parts&width=120&height=80&seq=door1&orientation=landscape',
      status: 'pending',
      dateAdded: '2024-02-02',
      views: 45,
      reports: 0
    },
    {
      id: 3,
      title: 'إطار أمامي 225/60 R16',
      price: 350,
      category: 'إطارات',
      seller: 'خالد الأحمد',
      image: 'https://readdy.ai/api/search-image?query=Car%20tire%20225%2F60%20R16%2C%20automotive%20tire%2C%20wheel%20tire&width=120&height=80&seq=tire1&orientation=landscape',
      status: 'rejected',
      dateAdded: '2024-01-30',
      views: 23,
      reports: 2
    },
    {
      id: 4,
      title: 'جنط ألمنيوم مقاس 17',
      price: 800,
      category: 'جنوط',
      seller: 'نورا السالم',
      image: 'https://readdy.ai/api/search-image?query=Aluminum%20wheel%20rim%2017%20inch%2C%20car%20wheel%2C%20automotive%20wheel&width=120&height=80&seq=rim1&orientation=landscape',
      status: 'sold',
      dateAdded: '2024-01-28',
      views: 89,
      reports: 0
    }
  ]);

  const categories = ['الكل', 'أجزاء المحرك', 'أبواب', 'إطارات', 'جنوط', 'أنوار', 'مرايا', 'مقاعد'];

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';

    if (!isLoggedIn || user.phone !== '96895977544') {
      router.push('/login');
      return;
    }

    setIsAdmin(true);
  }, [router]);

  const handleStatusChange = (productId: number, newStatus: 'active' | 'pending' | 'rejected') => {
    setProducts(products.map(product =>
      product.id === productId ? { ...product, status: newStatus } : product
    ));
  };

  const handleDeleteProduct = (product: Product) => {
    setSelectedProduct(product);
    setShowDeleteModal(true);
  };

  const confirmDelete = () => {
    if (selectedProduct) {
      setProducts(products.filter(product => product.id !== selectedProduct.id));
      setShowDeleteModal(false);
      setSelectedProduct(null);
    }
  };

  const handleEditProduct = (product: Product) => {
    setSelectedProduct(product);
    setEditForm({
      title: product.title,
      price: product.price,
      category: product.category,
      status: product.status
    });
    setShowEditModal(true);
  };

  const saveEdit = () => {
    if (selectedProduct) {
      setProducts(products.map(product =>
        product.id === selectedProduct.id
          ? { ...product, ...editForm }
          : product
      ));
      setShowEditModal(false);
      setSelectedProduct(null);
    }
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.seller.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || product.status === filterStatus;
    const matchesCategory = filterCategory === 'all' || filterCategory === 'الكل' || product.category === filterCategory;
    return matchesSearch && matchesStatus && matchesCategory;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400';
      case 'pending': return 'bg-yellow-100 text-yellow-600 dark:bg-yellow-900/30 dark:text-yellow-400';
      case 'rejected': return 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400';
      case 'sold': return 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400';
      default: return 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'نشط';
      case 'pending': return 'معلق';
      case 'rejected': return 'مرفوض';
      case 'sold': return 'مُباع';
      default: return 'غير محدد';
    }
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">جاري التحقق من الصلاحيات...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-20">
      {/* Navigation Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 shadow-sm">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <Link href="/admin" className="ml-3">
              <i className="ri-arrow-right-line text-xl text-gray-700 dark:text-gray-300"></i>
            </Link>
            <h1 className="text-lg font-bold text-gray-800 dark:text-white">إدارة المنتجات</h1>
          </div>
          <span className="bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs px-3 py-1 rounded-full font-medium">
            {filteredProducts.length} منتج
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 px-4">
        {/* Search and Filters */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 mb-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="space-y-4">
            <div className="relative">
              <i className="ri-search-line absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
              <input
                type="text"
                placeholder="البحث بعنوان المنتج أو البائع"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pr-10 pl-4 py-3 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
              />
            </div>

            {/* Status Filter */}
            <div className="flex space-x-2 space-x-reverse overflow-x-auto pb-2">
              {['all', 'active', 'pending', 'rejected', 'sold'].map((status) => (
                <button
                  key={status}
                  onClick={() => setFilterStatus(status)}
                  className={`px-4 py-2 rounded-full text-xs font-medium transition-colors whitespace-nowrap ${
                    filterStatus === status
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  {status === 'all' ? 'الكل' :
                   status === 'active' ? 'نشط' :
                   status === 'pending' ? 'معلق' :
                   status === 'rejected' ? 'مرفوض' : 'مُباع'}
                </button>
              ))}
            </div>

            {/* Category Filter */}
            <div className="flex space-x-2 space-x-reverse overflow-x-auto pb-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setFilterCategory(category)}
                  className={`px-4 py-2 rounded-full text-xs font-medium transition-colors whitespace-nowrap ${
                    filterCategory === category || (filterCategory === 'all' && category === 'الكل')
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Products List */}
        <div className="space-y-3">
          {filteredProducts.map((product) => (
            <div key={product.id} className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
              <div className="flex space-x-3 space-x-reverse">
                <div className="w-20 h-16 rounded-xl overflow-hidden flex-shrink-0">
                  <img 
                    src={product.image}
                    alt={product.title}
                    className="w-full h-full object-cover object-top"
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-800 dark:text-white text-sm truncate">{product.title}</h3>
                      <p className="text-blue-600 dark:text-blue-400 font-bold text-base">{product.price.toLocaleString()} ر.س</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full font-medium whitespace-nowrap mr-2 ${getStatusColor(product.status)}`}>
                      {getStatusText(product.status)}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs text-gray-600 dark:text-gray-400">
                      <span className="flex items-center">
                        <i className="ri-user-line ml-1"></i>
                        {product.seller}
                      </span>
                      <span className="bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded-full">{product.category}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-600 dark:text-gray-400">
                      <span>تاريخ الإضافة: {new Date(product.dateAdded).toLocaleDateString('ar-SA')}</span>
                      <div className="flex items-center space-x-3 space-x-reverse">
                        <span className="flex items-center">
                          <i className="ri-eye-line ml-1"></i>
                          {product.views}
                        </span>
                        {product.reports > 0 && (
                          <span className="flex items-center text-red-600 dark:text-red-400">
                            <i className="ri-flag-line ml-1"></i>
                            {product.reports}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-100 dark:border-gray-700">
                <div className="flex space-x-2 space-x-reverse">
                  <Link 
                    href={`/admin/products/${product.id}`}
                    className="text-xs text-blue-600 dark:text-blue-400 font-medium hover:underline"
                  >
                    عرض التفاصيل
                  </Link>
                  <Link 
                    href={`/admin/users/${product.seller}`}
                    className="text-xs text-purple-600 dark:text-purple-400 font-medium hover:underline"
                  >
                    البائع
                  </Link>
                </div>

                <div className="flex space-x-2 space-x-reverse">
                  <button
                    onClick={() => handleEditProduct(product)}
                    className="bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 px-3 py-1 rounded-full text-xs font-medium hover:bg-blue-200 dark:hover:bg-blue-900/50 transition-colors !rounded-button"
                  >
                    <i className="ri-edit-line ml-1"></i>
                    تعديل
                  </button>
                  
                  {product.status === 'pending' && (
                    <>
                      <button
                        onClick={() => handleStatusChange(product.id, 'active')}
                        className="bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 px-3 py-1 rounded-full text-xs font-medium hover:bg-green-200 dark:hover:bg-green-900/50 transition-colors !rounded-button"
                      >
                        موافقة
                      </button>
                      <button
                        onClick={() => handleStatusChange(product.id, 'rejected')}
                        className="bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 px-3 py-1 rounded-full text-xs font-medium hover:bg-red-200 dark:hover:bg-red-900/50 transition-colors !rounded-button"
                      >
                        رفض
                      </button>
                    </>
                  )}
                  {product.status === 'active' && (
                    <button
                      onClick={() => handleStatusChange(product.id, 'rejected')}
                      className="bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 px-3 py-1 rounded-full text-xs font-medium hover:bg-red-200 dark:hover:bg-red-900/50 transition-colors !rounded-button"
                    >
                      إخفاء
                    </button>
                  )}
                  {product.status === 'rejected' && (
                    <button
                      onClick={() => handleStatusChange(product.id, 'active')}
                      className="bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 px-3 py-1 rounded-full text-xs font-medium hover:bg-green-200 dark:hover:bg-green-900/50 transition-colors !rounded-button"
                    >
                      إعادة تفعيل
                    </button>
                  )}
                  
                  <button
                    onClick={() => handleDeleteProduct(product)}
                    className="bg-red-500 text-white px-3 py-1 rounded-full text-xs font-medium hover:bg-red-600 transition-colors !rounded-button"
                  >
                    <i className="ri-delete-bin-line ml-1"></i>
                    حذف
                  </button>
                </div>
              </div>
            </div>
          ))}

          {filteredProducts.length === 0 && (
            <div className="text-center py-8">
              <i className="ri-product-hunt-line text-4xl text-gray-400 dark:text-gray-600 mb-2"></i>
              <p className="text-gray-600 dark:text-gray-400">لا توجد منتجات مطابقة للبحث</p>
            </div>
          )}
        </div>
      </div>

      {/* Delete Modal */}
      {showDeleteModal && selectedProduct && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 max-w-sm w-full">
            <div className="text-center">
              <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-delete-bin-line text-red-600 dark:text-red-400 text-xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-2">حذف المنتج</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm mb-6">
                هل أنت متأكد من حذف منتج "{selectedProduct.title}"؟ لا يمكن التراجع عن هذا الإجراء.
              </p>
              <div className="flex space-x-3 space-x-reverse">
                <button
                  onClick={() => setShowDeleteModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors !rounded-button"
                >
                  إلغاء
                </button>
                <button
                  onClick={confirmDelete}
                  className="flex-1 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors !rounded-button"
                >
                  حذف
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && selectedProduct && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 max-w-sm w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-800 dark:text-white">تعديل المنتج</h3>
              <button
                onClick={() => setShowEditModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              >
                <i className="ri-close-line text-gray-400"></i>
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  عنوان المنتج
                </label>
                <input
                  type="text"
                  value={editForm.title}
                  onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  السعر (ريال سعودي)
                </label>
                <input
                  type="number"
                  value={editForm.price}
                  onChange={(e) => setEditForm({ ...editForm, price: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  الفئة
                </label>
                <select
                  value={editForm.category}
                  onChange={(e) => setEditForm({ ...editForm, category: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
                >
                  {categories.filter(cat => cat !== 'الكل').map((category) => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  الحالة
                </label>
                <select
                  value={editForm.status}
                  onChange={(e) => setEditForm({ ...editForm, status: e.target.value as 'active' | 'pending' | 'rejected' | 'sold' })}
                  className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
                >
                  <option value="active">نشط</option>
                  <option value="pending">معلق</option>
                  <option value="rejected">مرفوض</option>
                  <option value="sold">مُباع</option>
                </select>
              </div>
            </div>
            
            <div className="flex space-x-3 space-x-reverse mt-6">
              <button
                onClick={() => setShowEditModal(false)}
                className="flex-1 px-4 py-2 border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors !rounded-button"
              >
                إلغاء
              </button>
              <button
                onClick={saveEdit}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors !rounded-button"
              >
                حفظ التعديل
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 z-50">
        <div className="grid grid-cols-4 py-2">
          <Link href="/admin" className="flex flex-col items-center py-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-dashboard-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">الرئيسية</span>
          </Link>
          <Link href="/admin/users" className="flex flex-col items-center py-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-user-settings-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">المستخدمون</span>
          </Link>
          <Link href="/admin/products" className="flex flex-col items-center py-2 text-blue-600 dark:text-blue-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-product-hunt-fill text-lg"></i>
            </div>
            <span className="text-xs mt-1 font-medium">المنتجات</span>
          </Link>
          <Link href="/" className="flex flex-col items-center py-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-logout-box-r-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">خروج</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

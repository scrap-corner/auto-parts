
'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
  avatar: string;
  joinDate: string;
  status: 'active' | 'blocked' | 'pending';
  productsCount: number;
  rating: number;
}

export default function AdminUsers() {
  const router = useRouter();
  const [isAdmin, setIsAdmin] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [editForm, setEditForm] = useState({
    name: '',
    email: '',
    phone: '',
    status: 'active' as 'active' | 'blocked' | 'pending'
  });
  const [users, setUsers] = useState<User[]>([
    {
      id: 1,
      name: 'أحمد محمد السعد',
      email: 'ahmed@example.com',
      phone: '0501234567',
      avatar: 'https://readdy.ai/api/search-image?query=Professional%20male%20portrait%2C%20Saudi%20businessman%2C%20realistic%20photography&width=80&height=80&seq=user1&orientation=squarish',
      joinDate: '2024-01-15',
      status: 'active',
      productsCount: 12,
      rating: 4.8
    },
    {
      id: 2,
      name: 'فاطمة عبدالله',
      email: 'fatima@example.com',
      phone: '0509876543',
      avatar: 'https://readdy.ai/api/search-image?query=Professional%20female%20portrait%2C%20businesswoman%2C%20realistic%20photography&width=80&height=80&seq=user2&orientation=squarish',
      joinDate: '2024-01-20',
      status: 'active',
      productsCount: 8,
      rating: 4.9
    },
    {
      id: 3,
      name: 'خالد الأحمد',
      email: 'khalid@example.com',
      phone: '0555555555',
      avatar: 'https://readdy.ai/api/search-image?query=Professional%20male%20portrait%2C%20young%20businessman%2C%20realistic%20photography&width=80&height=80&seq=user3&orientation=squarish',
      joinDate: '2024-01-25',
      status: 'blocked',
      productsCount: 3,
      rating: 3.2
    },
    {
      id: 4,
      name: 'نورا السالم',
      email: 'nora@example.com',
      phone: '0502222222',
      avatar: 'https://readdy.ai/api/search-image?query=Professional%20female%20portrait%2C%20young%20businesswoman%2C%20realistic%20photography&width=80&height=80&seq=user4&orientation=squarish',
      joinDate: '2024-02-01',
      status: 'pending',
      productsCount: 0,
      rating: 0
    }
  ]);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';

    if (!isLoggedIn || user.phone !== '96895977544') {
      router.push('/login');
      return;
    }

    setIsAdmin(true);
  }, [router]);

  const handleStatusChange = (userId: number, newStatus: 'active' | 'blocked') => {
    setUsers(users.map(user =>
      user.id === userId ? { ...user, status: newStatus } : user
    ));
  };

  const handleDeleteUser = (user: User) => {
    setSelectedUser(user);
    setShowDeleteModal(true);
  };

  const confirmDelete = () => {
    if (selectedUser) {
      setUsers(users.filter(user => user.id !== selectedUser.id));
      setShowDeleteModal(false);
      setSelectedUser(null);
    }
  };

  const handleEditUser = (user: User) => {
    setSelectedUser(user);
    setEditForm({
      name: user.name,
      email: user.email,
      phone: user.phone,
      status: user.status
    });
    setShowEditModal(true);
  };

  const saveEdit = () => {
    if (selectedUser) {
      setUsers(users.map(user =>
        user.id === selectedUser.id 
          ? { ...user, ...editForm }
          : user
      ));
      setShowEditModal(false);
      setSelectedUser(null);
    }
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.phone.includes(searchTerm);
    const matchesFilter = filterStatus === 'all' || user.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400';
      case 'blocked': return 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400';
      case 'pending': return 'bg-yellow-100 text-yellow-600 dark:bg-yellow-900/30 dark:text-yellow-400';
      default: return 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'نشط';
      case 'blocked': return 'محظور';
      case 'pending': return 'معلق';
      default: return 'غير محدد';
    }
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">جاري التحقق من الصلاحيات...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-20">
      {/* Navigation Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 shadow-sm">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <Link href="/admin" className="ml-3">
              <i className="ri-arrow-right-line text-xl text-gray-700 dark:text-gray-300"></i>
            </Link>
            <h1 className="text-lg font-bold text-gray-800 dark:text-white">إدارة المستخدمين</h1>
          </div>
          <span className="bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs px-3 py-1 rounded-full font-medium">
            {filteredUsers.length} مستخدم
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 px-4">
        {/* Search and Filter */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 mb-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="space-y-4">
            <div className="relative">
              <i className="ri-search-line absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
              <input
                type="text"
                placeholder="البحث بالاسم، الإيميل أو رقم الهاتف"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pr-10 pl-4 py-3 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
              />
            </div>

            <div className="flex space-x-2 space-x-reverse">
              {['all', 'active', 'blocked', 'pending'].map((status) => (
                <button
                  key={status}
                  onClick={() => setFilterStatus(status)}
                  className={`px-4 py-2 rounded-full text-xs font-medium transition-colors ${
                    filterStatus === status
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  {status === 'all' ? 'الكل' :
                   status === 'active' ? 'نشط' :
                   status === 'blocked' ? 'محظور' : 'معلق'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Users List */}
        <div className="space-y-3">
          {filteredUsers.map((user) => (
            <div key={user.id} className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0">
                  <img 
                    src={user.avatar}
                    alt={user.name}
                    className="w-full h-full object-cover object-top"
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-semibold text-gray-800 dark:text-white text-sm truncate">{user.name}</h3>
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${getStatusColor(user.status)}`}>
                      {getStatusText(user.status)}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <p className="text-xs text-gray-600 dark:text-gray-400 flex items-center">
                      <i className="ri-mail-line ml-1"></i>
                      {user.email}
                    </p>
                    <p className="text-xs text-gray-600 dark:text-gray-400 flex items-center">
                      <i className="ri-phone-line ml-1"></i>
                      {user.phone}
                    </p>
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-gray-600 dark:text-gray-400">
                        انضم في: {new Date(user.joinDate).toLocaleDateString('ar-SA')}
                      </p>
                      <div className="flex items-center space-x-2 space-x-reverse text-xs text-gray-600 dark:text-gray-400">
                        <span>{user.productsCount} منتج</span>
                        {user.rating > 0 && (
                          <>
                            <span>•</span>
                            <div className="flex items-center">
                              <i className="ri-star-fill text-yellow-400 text-xs ml-1"></i>
                              <span>{user.rating}</span>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-100 dark:border-gray-700">
                <div className="flex space-x-2 space-x-reverse">
                  <Link 
                    href={`/admin/users/${user.id}`}
                    className="text-xs text-blue-600 dark:text-blue-400 font-medium hover:underline"
                  >
                    عرض التفاصيل
                  </Link>
                  <Link 
                    href={`/admin/users/${user.id}/products`}
                    className="text-xs text-green-600 dark:text-green-400 font-medium hover:underline"
                  >
                    المنتجات ({user.productsCount})
                  </Link>
                </div>

                <div className="flex space-x-2 space-x-reverse">
                  <button
                    onClick={() => handleEditUser(user)}
                    className="bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 px-3 py-1 rounded-full text-xs font-medium hover:bg-blue-200 dark:hover:bg-blue-900/50 transition-colors !rounded-button"
                  >
                    <i className="ri-edit-line ml-1"></i>
                    تعديل
                  </button>
                  
                  {user.status === 'active' ? (
                    <button
                      onClick={() => handleStatusChange(user.id, 'blocked')}
                      className="bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 px-3 py-1 rounded-full text-xs font-medium hover:bg-red-200 dark:hover:bg-red-900/50 transition-colors !rounded-button"
                    >
                      حظر
                    </button>
                  ) : user.status === 'blocked' ? (
                    <button
                      onClick={() => handleStatusChange(user.id, 'active')}
                      className="bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 px-3 py-1 rounded-full text-xs font-medium hover:bg-green-200 dark:hover:bg-green-900/50 transition-colors !rounded-button"
                    >
                      إلغاء الحظر
                    </button>
                  ) : (
                    <button
                      onClick={() => handleStatusChange(user.id, 'active')}
                      className="bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 px-3 py-1 rounded-full text-xs font-medium hover:bg-blue-200 dark:hover:bg-blue-900/50 transition-colors !rounded-button"
                    >
                      تفعيل
                    </button>
                  )}
                  
                  <button
                    onClick={() => handleDeleteUser(user)}
                    className="bg-red-500 text-white px-3 py-1 rounded-full text-xs font-medium hover:bg-red-600 transition-colors !rounded-button"
                  >
                    <i className="ri-delete-bin-line ml-1"></i>
                    حذف
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredUsers.length === 0 && (
          <div className="text-center py-8">
            <i className="ri-user-search-line text-4xl text-gray-400 dark:text-gray-600 mb-2"></i>
            <p className="text-gray-600 dark:text-gray-400">لا توجد نتائج مطابقة للبحث</p>
          </div>
        )}
      </div>

      {/* Delete Modal */}
      {showDeleteModal && selectedUser && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 max-w-sm w-full">
            <div className="text-center">
              <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-delete-bin-line text-red-600 dark:text-red-400 text-xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-2">حذف المستخدم</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm mb-6">
                هل أنت متأكد من حذف المستخدم "{selectedUser.name}"؟ سيتم حذف جميع منتجاته أيضاً. لا يمكن التراجع عن هذا الإجراء.
              </p>
              <div className="flex space-x-3 space-x-reverse">
                <button
                  onClick={() => setShowDeleteModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors !rounded-button"
                >
                  إلغاء
                </button>
                <button
                  onClick={confirmDelete}
                  className="flex-1 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors !rounded-button"
                >
                  حذف
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && selectedUser && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 max-w-sm w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-800 dark:text-white">تعديل المستخدم</h3>
              <button
                onClick={() => setShowEditModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              >
                <i className="ri-close-line text-gray-400"></i>
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  الاسم الكامل
                </label>
                <input
                  type="text"
                  value={editForm.name}
                  onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  البريد الإلكتروني
                </label>
                <input
                  type="email"
                  value={editForm.email}
                  onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  رقم الهاتف
                </label>
                <input
                  type="tel"
                  value={editForm.phone}
                  onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  حالة الحساب
                </label>
                <select
                  value={editForm.status}
                  onChange={(e) => setEditForm({ ...editForm, status: e.target.value as 'active' | 'blocked' | 'pending' })}
                  className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
                >
                  <option value="active">نشط</option>
                  <option value="blocked">محظور</option>
                  <option value="pending">معلق</option>
                </select>
              </div>
            </div>
            
            <div className="flex space-x-3 space-x-reverse mt-6">
              <button
                onClick={() => setShowEditModal(false)}
                className="flex-1 px-4 py-2 border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors !rounded-button"
              >
                إلغاء
              </button>
              <button
                onClick={saveEdit}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors !rounded-button"
              >
                حفظ التعديل
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 z-50">
        <div className="grid grid-cols-4 py-2">
          <Link href="/admin" className="flex flex-col items-center py-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-dashboard-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">الرئيسية</span>
          </Link>
          <Link href="/admin/users" className="flex flex-col items-center py-2 text-blue-600 dark:text-blue-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-user-settings-fill text-lg"></i>
            </div>
            <span className="text-xs mt-1 font-medium">المستخدمون</span>
          </Link>
          <Link href="/admin/products" className="flex flex-col items-center py-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-product-hunt-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">المنتجات</span>
          </Link>
          <Link href="/" className="flex flex-col items-center py-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-logout-box-r-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">خروج</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

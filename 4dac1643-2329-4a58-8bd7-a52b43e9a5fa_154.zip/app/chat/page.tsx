
'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useLanguage } from '../../components/LanguageProvider';

export default function Chat() {
  const router = useRouter();
  const { language, t, isRTL, theme } = useLanguage();
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';
    if (!loggedIn) {
      sessionStorage.setItem('returnUrl', '/chat');
      router.push('/login');
      return;
    }
    setIsLoggedIn(true);
  }, [router]);

  // دالة تحويل التاريخ للهجري
  const toHijri = (gregorianDate) => {
    const options = { 
      calendar: 'islamic-umalqura',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      locale: 'ar-SA'
    };
    return new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', options).format(gregorianDate);
  };

  const formatDualDate = (timeString) => {
    const date = new Date(); 

    if (timeString.includes('دقائق') || timeString.includes('minutes')) {
      return timeString; // إذا كان دقائق، اتركه كما هو
    }

    let daysAgo = 0;
    if (timeString.includes('ساعة') || timeString.includes('hour')) {
      daysAgo = 0; // في نفس اليوم
    } else if (timeString.includes('أمس') || timeString.includes('Yesterday')) {
      daysAgo = 1;
    } else if (timeString.includes('3 ساعات') || timeString.includes('3 hours')) {
      daysAgo = 0;
    } else {
      daysAgo = 1; // افتراضي
    }

    if (daysAgo === 0) {
      return timeString; // إذا كان في نفس اليوم
    }

    date.setDate(date.getDate() - daysAgo);

    // التاريخ الميلادي
    const gregorian = date.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', {
      day: 'numeric',
      month: 'short'
    });

    // التاريخ الهجري
    const hijri = toHijri(date);
    const hijriShort = hijri.replace(/\d+\s*هـ/, '').trim();

    if (language === 'ar') {
      return `${timeString} - ${gregorian} م / ${hijriShort} هـ`;
    } else {
      return `${timeString} - ${gregorian} / ${hijriShort} AH`;
    }
  };

  const conversations = [
    {
      id: 1,
      name: language === 'ar' ? 'أحمد محمد' : 'Ahmed Mohammed',
      lastMessage: language === 'ar' ? 'هل القطعة متوفرة?' : 'Is the part available?',
      time: language === 'ar' ? 'منذ 5 دقائق' : '5 minutes ago',
      unread: 2,
      avatar: 'Professional male portrait, Saudi man, clean background, realistic photography style, friendly appearance',
      productName: language === 'ar' ? 'فلتر هواء تويوتا كامري' : 'Toyota Camry Air Filter',
      productPrice: language === 'ar' ? '45 ريال' : '45 SAR',
      online: true
    },
    {
      id: 2,
      name: language === 'ar' ? 'سعد العتيبي' : 'Saad Al-Otaibi',
      lastMessage: language === 'ar' ? 'شكراً لك، تم الاستلام' : 'Thank you, received',
      time: language === 'ar' ? 'منذ ساعة' : '1 hour ago',
      unread: 0,
      avatar: 'Professional male portrait, middle-aged Saudi man, clean background, realistic photography style',
      productName: language === 'ar' ? 'إطار ميشلان' : 'Michelin Tire',
      productPrice: language === 'ar' ? '280 ريال' : '280 SAR',
      online: false
    },
    {
      id: 3,
      name: language === 'ar' ? 'محمد الأحمد' : 'Mohammed Al-Ahmad',
      lastMessage: language === 'ar' ? 'متى يمكنني الاستلام?' : 'When can I pick up?',
      time: language === 'ar' ? 'منذ 3 ساعات' : '3 hours ago',
      unread: 1,
      avatar: 'Professional male portrait, young Saudi man, clean background, realistic photography style',
      productName: language === 'ar' ? 'بطارية سيارة 12 فولت' : 'Car Battery 12V',
      productPrice: language === 'ar' ? '320 ريال' : '320 SAR',
      online: true
    },
    {
      id: 4,
      name: language === 'ar' ? 'علي حسن' : 'Ali Hassan',
      lastMessage: language === 'ar' ? 'هل يمكن التفاوض على السعر?' : 'Can we negotiate the price?',
      time: language === 'ar' ? 'أمس' : 'Yesterday',
      unread: 0,
      avatar: 'Professional male portrait, elderly Saudi man, clean background, realistic photography style',
      productName: language === 'ar' ? 'فرامل أمامية نيسان' : 'Nissan Front Brakes',
      productPrice: language === 'ar' ? '180 ريال' : '180 SAR',
      online: false
    },
    {
      id: 5,
      name: language === 'ar' ? 'خالد السالم' : 'Khalid Al-Salem',
      lastMessage: language === 'ar' ? 'ممتاز، سأتواصل معك لاحقاً' : 'Great, will contact you later',
      time: language === 'ar' ? 'أمس' : 'Yesterday',
      unread: 0,
      avatar: 'Professional male portrait, Saudi businessman, clean background, realistic photography style',
      productName: language === 'ar' ? 'زيت محرك موبيل 1' : 'Mobil 1 Engine Oil',
      productPrice: language === 'ar' ? '95 ريال' : '95 SAR',
      online: false
    }
  ];

  if (!isLoggedIn) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'}`}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className={`${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
            {language === 'ar' ? 'جاري التحقق من تسجيل الدخول...' : 'Checking login...'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen pb-20 ${theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Navigation Bar */}
      <div className={`fixed top-0 left-0 right-0 z-50 text-white p-4 ${theme === 'dark' ? 'bg-gray-800' : 'bg-blue-600'}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className={`${isRTL ? 'ml-3' : 'mr-3'}`}>
              <i className={`ri-arrow-${isRTL ? 'right' : 'left'}-line text-xl`}></i>
            </Link>
            <h1 className="text-lg font-bold">{t('chat')}</h1>
          </div>
          <button className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-white/20 hover:bg-white/30'}`}>
            <i className="ri-add-line text-xl"></i>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20">
        {/* Search */}
        <div className="px-4 py-3">
          <div className="relative">
            <input
              type="text"
              placeholder={language === 'ar' ? 'ابحث في المحادثات...' : 'Search conversations...'}
              className={`w-full py-3 border rounded-lg text-sm focus:outline-none focus:border-blue-500 ${isRTL ? 'pl-12 pr-4' : 'pr-12 pl-4'} ${theme === 'dark' ? 'bg-gray-800 border-gray-600 text-white placeholder-gray-400' : 'bg-white border-gray-300 text-gray-900'}`}
            />
            <div className={`absolute top-1/2 transform -translate-y-1/2 w-6 h-6 flex items-center justify-center ${isRTL ? 'right-3' : 'left-3'}`}>
              <i className={`ri-search-line ${theme === 'dark' ? 'text-gray-400' : 'text-gray-400'}`}></i>
            </div>
          </div>
        </div>

        {/* Conversations List */}
        <div className="px-4">
          {conversations.map((conversation) => (
            <Link 
              key={conversation.id} 
              href={`/chat/${conversation.id}`}
              className={`block rounded-lg p-4 mb-3 shadow-sm border transition-colors ${theme === 'dark' ? 'bg-gray-800 border-gray-700 hover:bg-gray-700' : 'bg-white border-gray-100 hover:bg-gray-50'}`}
            >
              <div className={`flex items-start ${isRTL ? 'space-x-reverse space-x-4' : 'space-x-4'}`}>
                {/* Avatar */}
                <div className="relative flex-shrink-0">
                  <div className="w-14 h-14 rounded-full overflow-hidden">
                    <img 
                      src={`https://readdy.ai/api/search-image?query=$%7Bconversation.avatar%7D&width=80&height=80&seq=chat_avatar_${conversation.id}&orientation=squarish`}
                      alt={conversation.name}
                      className="w-full h-full object-cover object-top"
                    />
                  </div>
                  {conversation.online && (
                    <div className={`absolute bottom-0 w-4 h-4 bg-green-500 rounded-full border-2 border-white ${isRTL ? 'right-0' : 'left-0'}`}></div>
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className={`font-semibold text-sm truncate ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
                      {conversation.name}
                    </h4>
                    <span className={`text-xs flex-shrink-0 ${isRTL ? 'ml-2' : 'mr-2'} ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                      {formatDualDate(conversation.time)}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between mb-2">
                    <p className={`text-sm truncate ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                      {conversation.lastMessage}
                    </p>
                    {conversation.unread > 0 && (
                      <div className={`bg-blue-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center flex-shrink-0 ${isRTL ? 'ml-2' : 'mr-2'}`}>
                        {conversation.unread}
                      </div>
                    )}
                  </div>

                  {/* Product Info */}
                  <div className={`flex items-center text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                    <i className={`ri-product-hunt-line ${isRTL ? 'ml-1' : 'mr-1'}`}></i>
                    <span className="truncate">{conversation.productName}</span>
                    <span className="mx-2">•</span>
                    <span className={`font-medium ${theme === 'dark' ? 'text-green-400' : 'text-green-600'}`}>
                      {conversation.productPrice}
                    </span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Empty State */}
        {conversations.length === 0 && (
          <div className="text-center py-16 px-4">
            <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 ${theme === 'dark' ? 'bg-gray-800' : 'bg-gray-100'}`}>
              <i className={`ri-chat-3-line text-3xl ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}></i>
            </div>
            <h3 className={`text-lg font-semibold mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
              {language === 'ar' ? 'لا توجد محادثات' : 'No conversations'}
            </h3>
            <p className={`text-sm mb-6 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
              {language === 'ar' ? 'ابدأ محادثة جديدة مع البائعين والمشترين' : 'Start a new conversation with buyers and sellers'}
            </p>
            <Link 
              href="/search"
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-medium !rounded-button inline-block hover:bg-blue-700 transition-colors"
            >
              {language === 'ar' ? 'تصفح المنتجات' : 'Browse Products'}
            </Link>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className={`fixed bottom-0 left-0 right-0 border-t z-50 ${theme === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
        <div className="grid grid-cols-5 py-2">
          <Link href="/" className={`flex flex-col items-center py-2 transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'}`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-home-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('home')}</span>
          </Link>
          <Link href="/search" className={`flex flex-col items-center py-2 transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'}`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-search-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('search')}</span>
          </Link>
          <Link href="/chat" className={`flex flex-col items-center py-2 ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`}>
            <div className="w-6 h-6 flex items-center justify-center relative">
              <i className="ri-chat-3-fill text-lg"></i>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                <span className="text-xs text-white font-bold">3</span>
              </div>
            </div>
            <span className="text-xs mt-1 font-medium">{t('chat')}</span>
          </Link>
          <Link href="/favorites" className={`flex flex-col items-center py-2 transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'}`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-heart-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('favorites')}</span>
          </Link>
          <Link href="/profile" className={`flex flex-col items-center py-2 transition-colors ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'}`}>
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-user-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">{t('profile')}</span>
          </Link>
        </div>
      </div>
    </div>
  );
}


'use client';

import Link from 'next/link';
import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useNotifications } from '../../../components/PushNotifications';

interface Message {
  id: number;
  text: string;
  time: string;
  isOwn: boolean;
  type: 'text' | 'image' | 'product' | 'location';
  imageUrl?: string;
  productInfo?: {
    name: string;
    price: string;
    image: string;
  };
}

export default function ChatConversation({ chatId }: { chatId: string }) {
  const router = useRouter();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [message, setMessage] = useState('');
  const [showOptions, setShowOptions] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // استخدام نظام الإشعارات
  const { simulateNewMessage } = useNotifications();

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';
    if (!loggedIn) {
      sessionStorage.setItem('returnUrl', `/chat/${chatId}`);
      router.push('/login');
      return;
    }
    setIsLoggedIn(true);
  }, [router, chatId]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, []);

  // محاكاة استقبال رسائل جديدة
  useEffect(() => {
    if (isLoggedIn) {
      // محاكاة وصول رسالة جديدة بعد 10 ثوانِ من دخول المحادثة
      const timer = setTimeout(() => {
        simulateNewMessage('أحمد محمد', 'شكراً لك، أريد معرفة المزيد من التفاصيل حول هذه القطعة.', chatId);

        // إضافة الرسالة للمحادثة
        const newMessage: Message = {
          id: messages.length + 1,
          text: 'شكراً لك، أريد معرفة المزيد من التفاصيل حول هذه القطعة.',
          time: new Date().toLocaleTimeString('ar-SA', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true,
          }),
          isOwn: false,
          type: 'text'
        };

        setMessages(prev => [...prev, newMessage]);
        setTimeout(scrollToBottom, 100);
      }, 10000);

      return () => clearTimeout(timer);
    }
  }, [isLoggedIn, chatId]);

  const chatData = {
    id: parseInt(chatId),
    name: 'أحمد محمد',
    avatar: `https://readdy.ai/api/search-image?query=Professional%20male%20portrait%2C%20Saudi%20man%2C%20clean%20background%2C%20realistic%20photography%20style%2C%20friendly%20appearance%2C%20business%20casual&width=60&height=60&seq=chat_header_${chatId}_v2&orientation=squarish`,
    online: true,
    lastSeen: 'متصل الآن',
    productInfo: {
      name: 'فلتر هواء تويوتا كامري 2020',
      price: '45 ريال',
      image: `https://readdy.ai/api/search-image?query=Toyota%20Camry%20air%20filter%20automotive%20part%2C%20clean%20white%20background%2C%20professional%20product%20photography%2C%20high%20detail%2C%20car%20filter&width=50&height=50&seq=chat_product_${chatId}_v2&orientation=squarish`,
    },
  };

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: 'السلام عليكم، هل هذه القطعة متوفرة؟',
      time: '10:30 ص',
      isOwn: false,
      type: 'text',
    },
    {
      id: 2,
      text: 'وعليكم السلام، نعم متوفرة',
      time: '10:32 ص',
      isOwn: true,
      type: 'text',
    },
    {
      id: 3,
      text: '',
      time: '10:33 ص',
      isOwn: true,
      type: 'product',
      productInfo: {
        name: 'فلتر هواء تويوتا كامري 2020',
        price: '45 ريال',
        image: `https://readdy.ai/api/search-image?query=Toyota%20Camry%20air%20filter%20automotive%20part%2C%20clean%20white%20background%2C%20professional%20product%20photography%2C%20high%20detail%2C%20car%20maintenance&width=100&height=100&seq=chat_product_msg_3_v2&orientation=squarish`,
      },
    },
    {
      id: 4,
      text: 'ممتاز، هل يمكنني رؤية صورة أخرى؟',
      time: '10:35 ص',
      isOwn: false,
      type: 'text',
    },
    {
      id: 5,
      text: '',
      time: '10:36 ص',
      isOwn: true,
      type: 'image',
      imageUrl: `https://readdy.ai/api/search-image?query=Toyota%20Camry%20air%20filter%20detailed%20view%2C%20automotive%20spare%20part%20close-up%2C%20professional%20product%20photography%2C%20high%20quality%20automotive%20component%2C%20car%20parts&width=300&height=200&seq=chat_image_5_v2&orientation=landscape`,
    },
    {
      id: 6,
      text: 'ممتاز جداً، أريد شراءها',
      time: '10:40 ص',
      isOwn: false,
      type: 'text',
    },
    {
      id: 7,
      text: 'أهلاً وسهلاً، هل تريد الاستلام أم التوصيل؟',
      time: '10:42 ص',
      isOwn: true,
      type: 'text',
    },
  ]);

  const handleSendMessage = () => {
    if (message.trim()) {
      const newMessage: Message = {
        id: messages.length + 1,
        text: message.trim(),
        time: new Date().toLocaleTimeString('ar-SA', {
          hour: '2-digit',
          minute: '2-digit',
          hour12: true,
        }),
        isOwn: true,
        type: 'text',
      };

      setMessages([...messages, newMessage]);
      setMessage('');

      setTimeout(scrollToBottom, 100);

      // محاكاة رد تلقائي بعد 3 ثوانِ
      setTimeout(() => {
        const autoReply: Message = {
          id: messages.length + 2,
          text: 'شكراً لك، سأجهز القطعة وأتواصل معك قريباً.',
          time: new Date().toLocaleTimeString('ar-SA', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true,
          }),
          isOwn: false,
          type: 'text'
        };

        setMessages(prev => [...prev, autoReply]);

        // إرسال إشعار للرد الجديد
        simulateNewMessage('أحمد محمد', autoReply.text, chatId);

        setTimeout(scrollToBottom, 100);
      }, 3000);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement>) => {
    e.currentTarget.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiByeD0iNCIgZmlsbD0iI0Y5RkFGQiIvPgo8cGF0aCBkPSJNMjAgMTBDMTYuNjg2MyAxMCAxNCAxMi42ODYzIDE0IDE2VjI0QzE0IDI3LjMxMzcgMTYuNjg2MyAzMCAyMCAzMEMyMy4zMTM3IDMwIDI2IDI3LjMxMzcgMjYgMjRWMTZDMjYgMTIuNjg2MyAyMy4zMTM3IDEwIDIwIDEwWiIgZmlsbD0iI0Q1RDhEQyIvPgo8cGF0aCBkPSJNMTggMTVIMjJWMTlIMThWMTVaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMTggMjFIMjJWMjVIMThWMjFaIiBmaWxsPSJ3aGl0ZSIvPgo8L3N2Zz4K';
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحقق من تسجيل الدخول...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <Link href="/chat" className="ml-3">
              <i className="ri-arrow-right-line text-xl text-gray-700"></i>
            </Link>
            <div className="relative flex-shrink-0 ml-3">
              <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-200 flex items-center justify-center">
                <img
                  src={chatData.avatar}
                  alt={chatData.name}
                  className="w-full h-full object-cover object-top"
                  onError={handleImageError}
                />
              </div>
              {chatData.online && (
                <div className="absolute bottom-0 left-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
              )}
            </div>
            <div>
              <h1 className="text-base font-bold text-gray-800">{chatData.name}</h1>
              <p className="text-xs text-green-600">{chatData.lastSeen}</p>
            </div>
          </div>

          <div className="flex items-center space-x-2 space-x-reverse">
            <button className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
              <i className="ri-phone-line text-lg text-gray-600"></i>
            </button>
            <button className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
              <i className="ri-more-line text-lg text-gray-600"></i>
            </button>
          </div>
        </div>

        {/* Product Info Bar */}
        <div className="bg-blue-50 border-t border-blue-100 px-4 py-2">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-8 h-8 rounded overflow-hidden flex-shrink-0 bg-gray-200 flex items-center justify-center">
              <img
                src={chatData.productInfo.image}
                alt={chatData.productInfo.name}
                className="w-full h-full object-cover object-top"
                onError={handleImageError}
              />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-800 truncate">{chatData.productInfo.name}</p>
              <p className="text-xs text-green-600 font-bold">{chatData.productInfo.price}</p>
            </div>
            <Link href={`/product/${chatData.id}`} className="text-blue-600 text-xs font-medium">
              عرض
            </Link>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto pt-32 pb-20 px-4">
        <div className="space-y-4">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.isOwn ? 'justify-end' : 'justify-start'}`}>
              {msg.type === 'text' && (
                <div
                  className={`max-w-xs px-4 py-2 rounded-2xl ${
                    msg.isOwn
                      ? 'bg-blue-600 text-white rounded-br-md'
                      : 'bg-white border border-gray-200 text-gray-800 rounded-bl-md shadow-sm'
                  }`}
                >
                  <p className="text-sm leading-relaxed">{msg.text}</p>
                  <p
                    className={`text-xs mt-1 ${
                      msg.isOwn ? 'text-blue-200' : 'text-gray-500'
                    }`}
                  >
                    {msg.time}
                  </p>
                </div>
              )}

              {msg.type === 'image' && (
                <div className={`max-w-xs ${msg.isOwn ? 'ml-auto' : 'mr-auto'}`}>
                  <div className="rounded-2xl overflow-hidden bg-white border border-gray-200 shadow-sm">
                    <div className="w-full h-40 bg-gray-200 flex items-center justify-center">
                      <img
                        src={msg.imageUrl}
                        alt="صورة مرسلة"
                        className="w-full h-full object-cover object-top"
                        onError={handleImageError}
                      />
                    </div>
                    <div className="p-2">
                      <p className="text-xs text-gray-500">{msg.time}</p>
                    </div>
                  </div>
                </div>
              )}

              {msg.type === 'product' && msg.productInfo && (
                <div className={`max-w-xs ${msg.isOwn ? 'ml-auto' : 'mr-auto'}`}>
                  <div className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
                    <div className="flex items-center p-3 space-x-3 space-x-reverse">
                      <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 bg-gray-200 flex items-center justify-center">
                        <img
                          src={msg.productInfo.image}
                          alt={msg.productInfo.name}
                          className="w-full h-full object-cover object-top"
                          onError={handleImageError}
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-medium text-gray-800 leading-tight">{msg.productInfo.name}</h4>
                        <p className="text-sm font-bold text-green-600">{msg.productInfo.price}</p>
                      </div>
                    </div>
                    <div className="px-3 pb-2">
                      <p className="text-xs text-gray-500">{msg.time}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Message Input */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4">
        <div className="flex items-end space-x-3 space-x-reverse">
          {/* Attachment Button */}
          <button
            onClick={() => setShowOptions(!showOptions)}
            className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0"
          >
            <i className="ri-add-line text-xl text-gray-600"></i>
          </button>

          {/* Message Input */}
          <div className="flex-1">
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="اكتب رسالتك..."
              className="w-full px-4 py-3 bg-gray-100 rounded-2xl resize-none focus:outline-none focus:bg-white focus:ring-2 focus:ring-blue-500 text-sm"
              rows={1}
              style={{ maxHeight: '100px', overflowY: 'auto' }}
            />
          </div>

          {/* Send Button */}
          <button
            onClick={handleSendMessage}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
              message.trim()
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-400'
            }`}
            disabled={!message.trim()}
          >
            <i className="ri-send-plane-fill text-lg"></i>
          </button>
        </div>

        {/* Quick Options */}
        {showOptions && (
          <div className="mt-3 flex space-x-3 space-x-reverse">
            <button className="flex items-center space-x-2 space-x-reverse bg-gray-100 px-4 py-2 rounded-lg">
              <i className="ri-camera-line text-blue-600"></i>
              <span className="text-sm text-gray-700">صورة</span>
            </button>
            <button className="flex items-center space-x-2 space-x-reverse bg-gray-100 px-4 py-2 rounded-lg">
              <i className="ri-map-pin-line text-green-600"></i>
              <span className="text-sm text-gray-700">موقع</span>
            </button>
            <button className="flex items-center space-x-2 space-x-reverse bg-gray-100 px-4 py-2 rounded-lg">
              <i className="ri-product-hunt-line text-orange-600"></i>
              <span className="text-sm text-gray-700">منتج</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

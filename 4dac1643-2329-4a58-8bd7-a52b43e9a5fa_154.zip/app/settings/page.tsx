'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function Settings() {
  const router = useRouter();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [notifications, setNotifications] = useState({
    push: true,
    email: false,
    messages: true,
    offers: true
  });

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';
    if (!loggedIn) {
      sessionStorage.setItem('returnUrl', '/settings');
      router.push('/login');
      return;
    }
    setIsLoggedIn(true);
  }, [router]);

  const handleNotificationChange = (key: string) => {
    setNotifications(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const settingsSections = [
    {
      title: 'الحساب',
      items: [
        {
          icon: 'ri-user-line',
          title: 'تعديل الملف الشخصي',
          subtitle: 'تحديث معلوماتك الشخصية',
          href: '/profile/edit',
          color: 'blue'
        },
        {
          icon: 'ri-lock-line',
          title: 'تغيير كلمة المرور',
          subtitle: 'تحديث كلمة المرور',
          href: '/change-password',
          color: 'green'
        },
        {
          icon: 'ri-map-pin-line',
          title: 'العناوين المحفوظة',
          subtitle: 'إدارة عناوين التوصيل',
          href: '/addresses',
          color: 'red'
        }
      ]
    },
    {
      title: 'الإعدادات العامة',
      items: [
        {
          icon: 'ri-global-line',
          title: 'اللغة',
          subtitle: 'العربية',
          href: '/language',
          color: 'purple'
        },
        {
          icon: 'ri-moon-line',
          title: 'المظهر',
          subtitle: 'فاتح',
          href: '/appearance',
          color: 'gray'
        },
        {
          icon: 'ri-shield-check-line',
          title: 'الخصوصية والأمان',
          subtitle: 'إعدادات الحماية',
          href: '/privacy',
          color: 'emerald'
        }
      ]
    },
    {
      title: 'الدعم',
      items: [
        {
          icon: 'ri-question-line',
          title: 'الأسئلة الشائعة',
          subtitle: 'إجابات للأسئلة المتكررة',
          href: '/faq',
          color: 'orange'
        },
        {
          icon: 'ri-customer-service-2-line',
          title: 'تواصل معنا',
          subtitle: 'احصل على المساعدة',
          href: '/contact',
          color: 'blue'
        },
        {
          icon: 'ri-feedback-line',
          title: 'تقييم التطبيق',
          subtitle: 'شاركنا رأيك',
          href: '/rate-app',
          color: 'yellow'
        }
      ]
    }
  ];

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحقق من تسجيل الدخول...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Navigation Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="flex items-center p-4">
          <Link href="/profile" className="ml-3">
            <i className="ri-arrow-right-line text-xl text-gray-700"></i>
          </Link>
          <h1 className="text-lg font-bold text-gray-800">الإعدادات</h1>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 px-4">
        {/* Notifications Section */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 mb-6">
          <h2 className="text-lg font-bold text-gray-800 mb-4">الإشعارات</h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <i className="ri-notification-3-line text-blue-600"></i>
                </div>
                <div>
                  <p className="font-medium text-gray-800 text-sm">الإشعارات المدفوعة</p>
                  <p className="text-xs text-gray-600">إشعارات على الشاشة</p>
                </div>
              </div>
              <button
                onClick={() => handleNotificationChange('push')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  notifications.push ? 'bg-blue-600' : 'bg-gray-200'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    notifications.push ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <i className="ri-mail-line text-green-600"></i>
                </div>
                <div>
                  <p className="font-medium text-gray-800 text-sm">البريد الإلكتروني</p>
                  <p className="text-xs text-gray-600">تحديثات عبر الإيميل</p>
                </div>
              </div>
              <button
                onClick={() => handleNotificationChange('email')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  notifications.email ? 'bg-blue-600' : 'bg-gray-200'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    notifications.email ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                  <i className="ri-chat-3-line text-purple-600"></i>
                </div>
                <div>
                  <p className="font-medium text-gray-800 text-sm">الرسائل الجديدة</p>
                  <p className="text-xs text-gray-600">تنبيهات المحادثات</p>
                </div>
              </div>
              <button
                onClick={() => handleNotificationChange('messages')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  notifications.messages ? 'bg-blue-600' : 'bg-gray-200'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    notifications.messages ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                  <i className="ri-price-tag-3-line text-orange-600"></i>
                </div>
                <div>
                  <p className="font-medium text-gray-800 text-sm">العروض الخاصة</p>
                  <p className="text-xs text-gray-600">خصومات وتخفيضات</p>
                </div>
              </div>
              <button
                onClick={() => handleNotificationChange('offers')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  notifications.offers ? 'bg-blue-600' : 'bg-gray-200'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    notifications.offers ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Settings Sections */}
        {settingsSections.map((section, sectionIndex) => (
          <div key={sectionIndex} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 mb-6">
            <h2 className="text-lg font-bold text-gray-800 mb-4">{section.title}</h2>
            <div className="space-y-3">
              {section.items.map((item, index) => (
                <Link 
                  key={index}
                  href={item.href}
                  className="flex items-center space-x-4 space-x-reverse p-3 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    item.color === 'blue' ? 'bg-blue-100' :
                    item.color === 'green' ? 'bg-green-100' :
                    item.color === 'red' ? 'bg-red-100' :
                    item.color === 'purple' ? 'bg-purple-100' :
                    item.color === 'gray' ? 'bg-gray-100' :
                    item.color === 'emerald' ? 'bg-emerald-100' :
                    item.color === 'orange' ? 'bg-orange-100' :
                    'bg-yellow-100'
                  }`}>
                    <i className={`${item.icon} text-lg ${
                      item.color === 'blue' ? 'text-blue-600' :
                      item.color === 'green' ? 'text-green-600' :
                      item.color === 'red' ? 'text-red-600' :
                      item.color === 'purple' ? 'text-purple-600' :
                      item.color === 'gray' ? 'text-gray-600' :
                      item.color === 'emerald' ? 'text-emerald-600' :
                      item.color === 'orange' ? 'text-orange-600' :
                      'text-yellow-600'
                    }`}></i>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-800 text-sm">{item.title}</h4>
                    <p className="text-xs text-gray-600 mt-0.5">{item.subtitle}</p>
                  </div>
                  <i className="ri-arrow-left-s-line text-gray-400"></i>
                </Link>
              ))}
            </div>
          </div>
        ))}

        {/* Logout Button */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 mb-6">
          <button 
            onClick={() => {
              localStorage.removeItem('isLoggedIn');
              localStorage.removeItem('user');
              router.push('/login');
            }}
            className="w-full flex items-center justify-center space-x-3 space-x-reverse p-3 rounded-xl text-red-600 hover:bg-red-50 transition-colors"
          >
            <i className="ri-logout-box-r-line text-lg"></i>
            <span className="font-medium">تسجيل الخروج</span>
          </button>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
        <div className="grid grid-cols-5 py-2">
          <Link href="/" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-home-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">الرئيسية</span>
          </Link>
          <Link href="/search" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-search-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">البحث</span>
          </Link>
          <Link href="/chat" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center relative">
              <i className="ri-chat-3-line text-lg"></i>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                <span className="text-xs text-white font-bold">3</span>
              </div>
            </div>
            <span className="text-xs mt-1">المحادثات</span>
          </Link>
          <Link href="/favorites" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-heart-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">المفضلة</span>
          </Link>
          <Link href="/profile" className="flex flex-col items-center py-2 text-blue-600">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-user-fill text-lg"></i>
            </div>
            <span className="text-xs mt-1 font-medium">الحساب</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useLanguage } from '../../components/LanguageProvider';
import Link from 'next/link';

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showCountryList, setShowCountryList] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState({
    name: 'عُمان',
    code: '+968',
    flag: '🇴🇲'
  });

  const { t, currentLanguage, isRTL, theme } = useLanguage();
  const router = useRouter();

  const countries = [
    { name: 'عُمان', code: '+968', flag: '🇴🇲' },
    { name: 'السعودية', code: '+966', flag: '🇸🇦' },
    { name: 'الإمارات', code: '+971', flag: '🇦🇪' },
    { name: 'الكويت', code: '+965', flag: '🇰🇼' },
    { name: 'قطر', code: '+974', flag: '🇶🇦' },
    { name: 'البحرين', code: '+973', flag: '🇧🇭' }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Admin login check
      if (phone === '96800000000' && password === 'admin123') {
        localStorage.setItem('isAdminLoggedIn', 'true');
        router.push('/admin');
        return;
      }

      // Validate form data
      if (isLogin) {
        if (!phone || !password) {
          alert('يرجى ملء جميع الحقول المطلوبة');
          setIsLoading(false);
          return;
        }
      } else {
        if (!phone || !password || !confirmPassword || !name) {
          alert('يرجى ملء جميع الحقول المطلوبة');
          setIsLoading(false);
          return;
        }
        if (password !== confirmPassword) {
          alert('كلمات المرور غير متطابقة');
          setIsLoading(false);
          return;
        }
      }

      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Save user login state
      if (rememberMe) {
        localStorage.setItem('rememberMe', 'true');
        localStorage.setItem('savedPhone', selectedCountry.code + phone);
      } else {
        localStorage.removeItem('rememberMe');
        localStorage.removeItem('savedPhone');
      }

      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('userPhone', selectedCountry.code + phone);
      localStorage.setItem('userName', name || 'مستخدم');

      // Check for return URL
      const returnUrl = sessionStorage.getItem('returnUrl');
      if (returnUrl) {
        sessionStorage.removeItem('returnUrl');
        router.push(returnUrl);
      } else {
        router.push('/');
      }

    } catch (error) {
      console.error('خطأ في تسجيل الدخول:', error);
      alert('حدث خطأ. يرجى المحاولة مرة أخرى');
    } finally {
      setIsLoading(false);
    }
  };

  // Load saved data on component mount
  useEffect(() => {
    const savedRememberMe = localStorage.getItem('rememberMe') === 'true';
    const savedPhone = localStorage.getItem('savedPhone');
    
    if (savedRememberMe && savedPhone) {
      setRememberMe(true);
      // Extract country code and phone number
      const country = countries.find(c => savedPhone.startsWith(c.code));
      if (country) {
        setSelectedCountry(country);
        setPhone(savedPhone.replace(country.code, ''));
      }
    }
  }, []);

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Back to Home Button */}
      <div className="absolute top-4 left-4 z-10">
        <Link
          href="/"
          className={`flex items-center gap-2 px-4 py-2 rounded-full transition-colors ${
            theme === 'dark' 
              ? 'bg-gray-800 text-gray-300 hover:text-white border border-gray-700 hover:border-gray-600' 
              : 'bg-white text-gray-700 hover:text-gray-900 border border-gray-200 hover:border-gray-300 shadow-sm'
          }`}
        >
          <i className="ri-arrow-right-line text-lg"></i>
          <span className="text-sm font-medium">العودة للرئيسية</span>
        </Link>
      </div>

      <div className="flex items-center justify-center min-h-screen px-4 py-8">
        <div className={`w-full max-w-md ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-xl p-8`}>
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-user-line text-2xl text-white"></i>
            </div>
            <h1 className={`text-2xl font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              {isLogin ? 'تسجيل الدخول' : 'إنشاء حساب جديد'}
            </h1>
            <p className={`text-sm mt-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
              {isLogin ? 'أهلاً بعودتك! سجل دخولك للمتابعة' : 'انضم إلينا وابدأ رحلتك'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {!isLogin && (
              <div>
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  الاسم الكامل
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                      theme === 'dark'
                        ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                        : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
                    } ${isRTL ? 'pr-12 text-right' : 'pl-12'}`}
                    placeholder="أدخل اسمك الكامل"
                    required
                  />
                  <i className={`ri-user-line absolute top-1/2 transform -translate-y-1/2 ${
                    isRTL ? 'right-4' : 'left-4'
                  } ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}></i>
                </div>
              </div>
            )}

            <div>
              <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                رقم الهاتف
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowCountryList(!showCountryList)}
                  className={`relative px-4 py-3 border rounded-xl flex items-center gap-2 min-w-[100px] ${
                    theme === 'dark'
                      ? 'bg-gray-700 border-gray-600 text-white hover:bg-gray-600'
                      : 'bg-white border-gray-300 text-gray-900 hover:bg-gray-50'
                  }`}
                >
                  <span>{selectedCountry.flag}</span>
                  <span className="text-sm">{selectedCountry.code}</span>
                  <i className="ri-arrow-down-s-line text-sm"></i>

                  {showCountryList && (
                    <div
                      className={`absolute top-full ${isRTL ? 'right-0' : 'left-0'} mt-1 w-48 ${
                        theme === 'dark' ? 'bg-gray-800 border-gray-600' : 'bg-white border-gray-200'
                      } border rounded-xl shadow-lg z-20 max-h-60 overflow-y-auto`}
                    >
                      {countries.map((country, index) => (
                        <button
                          key={index}
                          type="button"
                          onClick={() => {
                            setSelectedCountry(country);
                            setShowCountryList(false);
                          }}
                          className={`w-full px-4 py-3 text-${isRTL ? 'right' : 'left'} hover:${
                            theme === 'dark' ? 'bg-gray-700' : 'bg-gray-50'
                          } flex items-center gap-3 ${
                            theme === 'dark' ? 'text-white hover:bg-gray-700' : 'text-gray-900 hover:bg-gray-50'
                          }`}
                        >
                          <span>{country.flag}</span>
                          <div>
                            <div className="text-sm font-medium">{country.name}</div>
                            <div className="text-xs text-gray-500">{country.code}</div>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </button>
                <div className="flex-1 relative">
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                      theme === 'dark'
                        ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                        : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
                    } ${isRTL ? 'pr-12 text-right' : 'pl-12'}`}
                    placeholder="12345678"
                    required
                  />
                  <i
                    className={`ri-phone-line absolute top-1/2 transform -translate-y-1/2 ${
                      isRTL ? 'right-4' : 'left-4'
                    } ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}
                  ></i>
                </div>
              </div>
            </div>

            <div>
              <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                كلمة المرور
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    theme === 'dark'
                      ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                      : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
                  } ${isRTL ? 'pr-12 pl-12' : 'pl-12 pr-12'}`}
                  placeholder="أدخل كلمة المرور"
                  required
                />
                <i
                  className={`ri-lock-line absolute top-1/2 transform -translate-y-1/2 ${
                    isRTL ? 'right-4' : 'left-4'
                  } ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}
                ></i>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className={`absolute top-1/2 transform -translate-y-1/2 ${
                    isRTL ? 'left-4' : 'right-4'
                  } ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  <i className={showPassword ? 'ri-eye-off-line' : 'ri-eye-line'}></i>
                </button>
              </div>
            </div>

            {!isLogin && (
              <div>
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  تأكيد كلمة المرور
                </label>
                <div className="relative">
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                      theme === 'dark'
                        ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                        : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
                    } ${isRTL ? 'pr-12 pl-12' : 'pl-12 pr-12'}`}
                    placeholder="أعد إدخال كلمة المرور"
                    required
                  />
                  <i
                    className={`ri-lock-line absolute top-1/2 transform -translate-y-1/2 ${
                      isRTL ? 'right-4' : 'left-4'
                    } ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}
                  ></i>
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className={`absolute top-1/2 transform -translate-y-1/2 ${
                      isRTL ? 'left-4' : 'right-4'
                    } ${theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700'}`}
                  >
                    <i className={showConfirmPassword ? 'ri-eye-off-line' : 'ri-eye-line'}></i>
                  </button>
                </div>
              </div>
            )}

            {/* Remember Me Checkbox - Only show for login */}
            {isLogin && (
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <button
                    type="button"
                    onClick={() => setRememberMe(!rememberMe)}
                    className={`relative w-5 h-5 rounded border-2 transition-colors ${
                      rememberMe 
                        ? 'bg-blue-600 border-blue-600' 
                        : theme === 'dark' 
                          ? 'border-gray-500 hover:border-gray-400' 
                          : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    {rememberMe && (
                      <i className="ri-check-line text-white text-sm absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></i>
                    )}
                  </button>
                  <label 
                    onClick={() => setRememberMe(!rememberMe)}
                    className={`mr-3 text-sm cursor-pointer ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}
                  >
                    تذكرني
                  </label>
                </div>
                <button
                  type="button"
                  className={`text-sm hover:underline ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`}
                >
                  نسيت كلمة المرور؟
                </button>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className={`w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-6 rounded-xl font-medium hover:from-blue-600 hover:to-purple-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 !rounded-button flex items-center justify-center gap-2 ${
                isLoading ? 'opacity-70 cursor-not-allowed' : ''
              }`}
            >
              {isLoading && (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              )}
              {isLoading ? 'جاري تسجيل الدخول...' : (isLogin ? 'تسجيل الدخول' : 'إنشاء الحساب')}
            </button>

            <div className="text-center mt-6">
              <p className={`text-sm ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                {isLogin ? 'ليس لديك حساب?' : 'لديك حساب بالفعل?'}
                <button
                  type="button"
                  onClick={() => setIsLogin(!isLogin)}
                  className={`font-medium hover:underline ${isRTL ? 'mr-1' : 'ml-1'} ${
                    theme === 'dark' ? 'text-blue-400' : 'text-blue-600'
                  }`}
                >
                  {isLogin ? 'إنشاء حساب جديد' : 'تسجيل الدخول'}
                </button>
              </p>
            </div>

            {!isLogin && (
              <div
                className={`mt-6 border rounded-lg p-4 ${theme === 'dark' ? 'bg-green-900/30 border-green-600' : 'bg-green-50 border-green-200'}`}
              >
                <div className="flex items-start">
                  <i
                    className={`ri-shield-check-line text-lg mt-0.5 ${isRTL ? 'mr-3' : 'ml-3'} ${
                      theme === 'dark' ? 'text-green-400' : 'text-green-600'
                    }`}
                  ></i>
                  <div>
                    <p className={`text-sm font-medium mb-1 ${theme === 'dark' ? 'text-green-200' : 'text-green-800'}`}>
                      التحقق الأمني:
                    </p>
                    <p className={`text-xs ${theme === 'dark' ? 'text-green-300' : 'text-green-700'}`}>
                      بعد ملء البيانات، ستحتاج لحل معادلة بسيطة للتأكد من أنك لست روبوت
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div
              className={`mt-6 border rounded-lg p-4 ${theme === 'dark' ? 'bg-yellow-900/30 border-yellow-600' : 'bg-yellow-50 border-yellow-200'}`}
            >
              <div className="flex items-start">
                <i
                  className={`ri-phone-line text-lg mt-0.5 ${isRTL ? 'mr-3' : 'ml-3'} ${
                    theme === 'dark' ? 'text-yellow-400' : 'text-yellow-600'
                  }`}
                ></i>
                <div>
                  <p className={`text-sm font-medium mb-2 ${theme === 'dark' ? 'text-yellow-200' : 'text-yellow-800'}`}>
                    أرقام دول مجلس التعاون المدعومة:
                  </p>
                  <div
                    className={`text-xs space-y-1 ${theme === 'dark' ? 'text-yellow-300' : 'text-yellow-700'}`}
                  >
                    <div className="flex items-center justify-between">
                      <span>🇴🇲 عُمان:</span>
                      <span className="font-medium">968xxxxxxxx</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>🇸🇦 السعودية:</span>
                      <span className="font-medium">96605xxxxxxxx</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>🇦🇪 الإمارات:</span>
                      <span className="font-medium">971xxxxxxxxx</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>🇰🇼 الكويت:</span>
                      <span className="font-medium">965xxxxxxxx</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>🇶🇦 قطر:</span>
                      <span className="font-medium">974xxxxxxxx</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>🇧🇭 البحرين:</span>
                      <span className="font-medium">973xxxxxxxx</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>

        {showCountryList && (
          <div className="fixed inset-0 bg-transparent z-10" onClick={() => setShowCountryList(false)}></div>
        )}
      </div>
    </div>
  );
}
'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';

export default function OfflinePage() {
  const [isOnline, setIsOnline] = useState(true);

  useEffect(() => {
    setIsOnline(navigator.onLine);

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const offlineFeatures = [
    {
      title: 'عرض المحفوظات',
      description: 'يمكنك تصفح المنتجات المحفوظة مسبقاً',
      icon: 'ri-save-line'
    },
    {
      title: 'كتابة الرسائل',
      description: 'اكتب رسائلك وسترسل عند الاتصال',
      icon: 'ri-edit-line'
    },
    {
      title: 'إعداد الإعلانات',
      description: 'حضر إعلانك وسينشر عند الاتصال',
      icon: 'ri-draft-line'
    }
  ];

  if (isOnline) {
    return null; // إذا كان متصل، لا نعرض هذه الصفحة
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Navigation Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-orange-500 text-white p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-orange-400 rounded-full flex items-center justify-center ml-3">
              <i className="ri-wifi-off-line text-white text-lg"></i>
            </div>
            <div>
              <h1 className="text-lg font-bold">وضع عدم الاتصال</h1>
              <p className="text-xs text-orange-100">لا يوجد اتصال بالإنترنت</p>
            </div>
          </div>
          <button
            onClick={() => window.location.reload()}
            className="bg-orange-400 px-3 py-1 rounded-lg text-sm font-medium hover:bg-orange-300 transition-colors !rounded-button"
          >
            إعادة المحاولة
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 px-4">
        {/* Offline Illustration */}
        <div className="text-center py-12">
          <div className="w-32 h-32 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="ri-wifi-off-line text-6xl text-orange-500"></i>
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-4">أنت غير متصل</h2>
          <p className="text-gray-600 mb-8">تحقق من اتصالك بالإنترنت وحاول مرة أخرى</p>
        </div>

        {/* Offline Features */}
        <div className="mb-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4">ما يمكنك فعله الآن</h3>
          <div className="space-y-4">
            {offlineFeatures.map((feature, index) => (
              <div key={index} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
                <div className="flex items-center space-x-4 space-x-reverse">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <i className={`${feature.icon} text-blue-600 text-xl`}></i>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-800 text-sm">{feature.title}</h4>
                    <p className="text-xs text-gray-600 mt-1">{feature.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Cached Content */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-gray-800">المحتوى المحفوظ</h3>
            <span className="bg-green-100 text-green-600 text-xs px-2 py-1 rounded-full font-medium">
              متوفر
            </span>
          </div>
          <div className="space-y-3">
            <Link 
              href="/favorites"
              className="flex items-center p-3 rounded-xl hover:bg-gray-50 transition-colors"
            >
              <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center ml-3">
                <i className="ri-heart-fill text-red-500"></i>
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-gray-800 text-sm">المنتجات المفضلة</h4>
                <p className="text-xs text-gray-600">5 منتجات محفوظة</p>
              </div>
              <i className="ri-arrow-left-s-line text-gray-400"></i>
            </Link>
            
            <Link 
              href="/profile"
              className="flex items-center p-3 rounded-xl hover:bg-gray-50 transition-colors"
            >
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center ml-3">
                <i className="ri-user-fill text-blue-500"></i>
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-gray-800 text-sm">ملف المستخدم</h4>
                <p className="text-xs text-gray-600">معلوماتك الشخصية</p>
              </div>
              <i className="ri-arrow-left-s-line text-gray-400"></i>
            </Link>
          </div>
        </div>

        {/* Connection Tips */}
        <div className="bg-blue-50 rounded-2xl p-4 border border-blue-200">
          <div className="flex items-start space-x-3 space-x-reverse">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
              <i className="ri-lightbulb-line text-blue-600"></i>
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-blue-800 text-sm mb-2">نصائح للاتصال</h4>
              <ul className="text-xs text-blue-700 space-y-1">
                <li>• تأكد من تشغيل الواي فاي أو البيانات</li>
                <li>• جرب الانتقال لمكان آخر</li>
                <li>• أعد تشغيل التطبيق</li>
                <li>• تحقق من إعدادات الشبكة</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
        <div className="grid grid-cols-5 py-2">
          <Link href="/" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-home-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">الرئيسية</span>
          </Link>
          <button className="flex flex-col items-center py-2 text-gray-300 cursor-not-allowed">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-search-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">البحث</span>
          </button>
          <button className="flex flex-col items-center py-2 text-gray-300 cursor-not-allowed">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-chat-3-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">المحادثات</span>
          </button>
          <Link href="/favorites" className="flex flex-col items-center py-2 text-blue-600">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-heart-fill text-lg"></i>
            </div>
            <span className="text-xs mt-1 font-medium">المفضلة</span>
          </Link>
          <Link href="/profile" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-user-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">الحساب</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

'use client';

import Link from 'next/link';
import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useLanguage } from '../../components/LanguageProvider';

export default function Sell() {
  const router = useRouter();
  const { language, t, isRTL, theme } = useLanguage();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';
    if (!loggedIn) {
      sessionStorage.setItem('returnUrl', '/sell');
      router.push('/login');
      return;
    }
    setIsLoggedIn(true);
  }, [router]);

  const [formData, setFormData] = useState({
    title: '',
    category: '',
    brand: '',
    model: '',
    year: '',
    condition: '',
    price: '',
    description: '',
    country: '',
    city: ''
  });

  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [showImageOptions, setShowImageOptions] = useState(false);

  const categories = language === 'ar' ? [
    'قطع المحرك والإشعال',
    'نظام الفرامل',
    'الإطارات والعجلات',
    'الإضاءة والكهرباء',
    'نظام التكييف',
    'ناقل الحركة والقابض',
    'نظام التعليق والتوجيه',
    'نظام العادم',
    'نظام الوقود',
    'نظام التبريد',
    'القطع الداخلية',
    'القطع الخارجية والبودي',
    'الزيوت والسوائل',
    'أدوات الصيانة',
    'الإكسسوارات'
  ] : [
    'Engine & Ignition Parts',
    'Brake System',
    'Tires & Wheels',
    'Lighting & Electrical',
    'AC & Climate System',
    'Transmission & Clutch',
    'Suspension & Steering',
    'Exhaust System',
    'Fuel System',
    'Cooling System',
    'Interior Parts',
    'Exterior & Body Parts',
    'Oils & Fluids',
    'Maintenance Tools',
    'Accessories'
  ];

  const carBrands = language === 'ar' ? [
    'تويوتا', 'لكزس', 'نيسان', 'انفينيتي', 'هيونداي', 'كيا', 'هوندا', 'أكورا',
    'فورد', 'لنكولن', 'شيفروليه', 'كاديلاك', 'جي إم سي', 'دودج', 'كرايسلر', 'جيب',
    'بي إم دبليو', 'ميني', 'مرسيدس بنز', 'أودي', 'فولكس واجن', 'بورش',
    'فولفو', 'ساب', 'جاكوار', 'لاند روفر', 'بنتلي', 'رولز رويس',
    'فيراري', 'لامبورغيني', 'مازيراتي', 'ألفا روميو', 'فيات',
    'ميتسوبيشي', 'سوزوكي', 'سوبارو', 'إيسوزو', 'مازدا',
    'بيجو', 'سيتروين', 'رينو', 'أوبل', 'سيات',
    'شانجان', 'جيلي', 'بي واي دي', 'جريت وول', 'هافال', 'إم جي'
  ] : [
    'Toyota', 'Lexus', 'Nissan', 'Infiniti', 'Hyundai', 'KIA', 'Honda', 'Acura',
    'Ford', 'Lincoln', 'Chevrolet', 'Cadillac', 'GMC', 'Dodge', 'Chrysler', 'Jeep',
    'BMW', 'MINI', 'Mercedes-Benz', 'Audi', 'Volkswagen', 'Porsche',
    'Volvo', 'Saab', 'Jaguar', 'Land Rover', 'Bentley', 'Rolls-Royce',
    'Ferrari', 'Lamborghini', 'Maserati', 'Alfa Romeo', 'Fiat',
    'Mitsubishi', 'Suzuki', 'Subaru', 'Isuzu', 'Mazda',
    'Peugeot', 'Citroën', 'Renault', 'Opel', 'SEAT',
    'Changan', 'Geely', 'BYD', 'Great Wall', 'Haval', 'MG'
  ];

  const conditions = language === 'ar' ? [
    'جديد - لم يُستخدم',
    'مستعمل - حالة ممتازة (كالجديد)',
    'مستعمل - حالة جيدة جداً',
    'مستعمل - حالة جيدة',
    'مستعمل - حالة مقبولة',
    'يحتاج إصلاح - قطع غيار'
  ] : [
    'New - Never Used',
    'Used - Excellent Condition (Like New)',
    'Used - Very Good Condition',
    'Used - Good Condition',
    'Used - Fair Condition',
    'Needs Repair - Spare Parts'
  ];

  const currentYear = new Date().getFullYear();
  const years = [];
  for (let year = currentYear + 1; year >= 1990; year--) {
    years.push(year.toString());
  }

  const countries = language === 'ar' ? [
    { code: 'SA', name: 'السعودية', flag: '🇸🇦' },
    { code: 'AE', name: 'الإمارات', flag: '🇦🇪' },
    { code: 'KW', name: 'الكويت', flag: '🇰🇼' },
    { code: 'QA', name: 'قطر', flag: '🇶🇦' },
    { code: 'BH', name: 'البحرين', flag: '🇧🇭' },
    { code: 'OM', name: 'عُمان', flag: '🇴🇲' }
  ] : [
    { code: 'SA', name: 'Saudi Arabia', flag: '🇸🇦' },
    { code: 'AE', name: 'UAE', flag: '🇦🇪' },
    { code: 'KW', name: 'Kuwait', flag: '🇰🇼' },
    { code: 'QA', name: 'Qatar', flag: '🇶🇦' },
    { code: 'BH', name: 'Bahrain', flag: '🇧🇭' },
    { code: 'OM', name: 'Oman', flag: '🇴🇲' }
  ];

  const cities = {
    SA: language === 'ar' ? [
      'الرياض', 'جدة', 'الدمام', 'مكة المكرمة', 'المدينة المنورة', 'الطائف', 'تبوك', 'القطيف', 'خميس مشيط', 'بريدة', 'الجبيل', 'حائل', 'الخفجي', 'الأحساء', 'نجران', 'جازان', 'ينبع', 'القريات', 'عرعر'
    ] : [
      'Riyadh', 'Jeddah', 'Dammam', 'Mecca', 'Medina', 'Taif', 'Tabuk', 'Qatif', 'Khamis Mushait', 'Buraidah', 'Jubail', 'Hail', 'Khafji', 'Al-Ahsa', 'Najran', 'Jazan', 'Yanbu', 'Qurayyat', 'Arar'
    ],
    AE: language === 'ar' ? [
      'دبي', 'أبو ظبي', 'الشارقة', 'العين', 'عجمان', 'رأس الخيمة', 'الفجيرة', 'أم القيوين'
    ] : [
      'Dubai', 'Abu Dhabi', 'Sharjah', 'Al Ain', 'Ajman', 'Ras Al Khaimah', 'Fujairah', 'Umm Al Quwain'
    ],
    KW: language === 'ar' ? [
      'مدينة الكويت', 'الأحمدي', 'حولي', 'الفروانية', 'مبارك الكبير', 'الجهراء'
    ] : [
      'Kuwait City', 'Al Ahmadi', 'Hawalli', 'Al Farwaniyah', 'Mubarak Al-Kabeer', 'Al Jahra'
    ],
    QA: language === 'ar' ? [
      'الدوحة', 'الريان', 'أم صلال', 'الوكرة', 'الخور', 'دخان', 'مسيعيد'
    ] : [
      'Doha', 'Al Rayyan', 'Umm Salal', 'Al Wakrah', 'Al Khor', 'Dukhan', 'Mesaieed'
    ],
    BH: language === 'ar' ? [
      'المنامة', 'المحرق', 'الرفاع', 'مدينة حمد', 'مدينة عيسى', 'سترة', 'الزلاق'
    ] : [
      'Manama', 'Muharraq', 'Riffa', 'Hamad Town', 'Isa Town', 'Sitra', 'Zallaq'
    ],
    OM: language === 'ar' ? [
      'مسقط', 'صلالة', 'السيب', 'بوشر', 'صحار', 'نزوى', 'الرستاق', 'صور', 'الباطنة', 'ظفار'
    ] : [
      'Muscat', 'Salalah', 'As Seeb', 'Bousher', 'Sohar', 'Nizwa', 'Rustaq', 'Sur', 'Al Batinah', 'Dhofar'
    ]
  };

  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [contactMethod, setContactMethod] = useState('both');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const currentDate = new Date();
    const expiryDate = new Date(currentDate);
    expiryDate.setMonth(currentDate.getMonth() + 2);

    const contactData = {
      ...formData,
      whatsapp: whatsappNumber,
      phone: phoneNumber,
      preferredContact: contactMethod,
      createdAt: currentDate.toISOString(),
      expiresAt: expiryDate.toISOString(),
      isExpired: false
    };

    const existingAds = JSON.parse(localStorage.getItem('userAds') || '[]');
    const newAd = {
      id: Date.now().toString(),
      ...contactData,
      userId: localStorage.getItem('currentUser') || 'user1'
    };

    existingAds.push(newAd);
    localStorage.setItem('userAds', JSON.stringify(existingAds));

    const expiryDateFormatted = expiryDate.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const successMessage = language === 'ar'
      ? `تم إضافة المنتج بنجاح!\\nسينتهي الإعلان تلقائياً في: ${expiryDateFormatted}`
      : `Product added successfully!\\nAd will expire automatically on: ${expiryDateFormatted}`;

    alert(successMessage);
    router.push('/');
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;

    if (name === 'country') {
      setFormData({
        ...formData,
        [name]: value,
        city: '' 
      });
    } else {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    if (uploadedImages.length + files.length > 5) {
      alert(language === 'ar' 
        ? 'يمكنك رفع حد أقصى 5 صور فقط' 
        : 'Maximum 5 images allowed');
      return;
    }

    Array.from(files).forEach((file) => {
      if (file.size > 5 * 1024 * 1024) {
        alert(language === 'ar' 
          ? 'حجم الصورة يجب أن يكون أقل من 5 ميجا' 
          : 'Image size must be less than 5MB');
        return;
      }

      if (!file.type.startsWith('image/')) {
        alert(language === 'ar' 
          ? 'يرجى اختيار ملف صورة صحيح' 
          : 'Please select a valid image file');
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        if (result) {
          setUploadedImages(prev => [...prev, result]);
        }
      };
      reader.readAsDataURL(file);
    });

    if (event.target) {
      event.target.value = '';
    }
    setShowImageOptions(false);
  };

  const handleCameraCapture = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    if (uploadedImages.length >= 5) {
      alert(language === 'ar' 
        ? 'يمكنك رفع حد أقصى 5 صور فقط' 
        : 'Maximum 5 images allowed');
      return;
    }

    const file = files[0];

    if (file.size > 5 * 1024 * 1024) {
      alert(language === 'ar' 
        ? 'حجم الصورة يجب أن يكون أقل من 5 ميجا' 
        : 'Image size must be less than 5MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        setUploadedImages(prev => [...prev, result]);
      }
    };
    reader.readAsDataURL(file);

    if (event.target) {
      event.target.value = '';
    }
    setShowImageOptions(false);
  };

  const openFileSelector = () => {
    fileInputRef.current?.click();
  };

  const openCamera = () => {
    cameraInputRef.current?.click();
  };

  const removeImage = (index: number) => {
    setUploadedImages(prev => prev.filter((_, i) => i !== index));
  };

  const generateSampleImages = () => {
    const sampleImages = [
      `https://readdy.ai/api/search-image?query=Toyota%20Camry%20engine%20air%20filter%2C%20automotive%20spare%20part%2C%20professional%20product%20photography%2C%20clean%20white%20background%2C%20high%20detail%20automotive%20component%2C%20car%20maintenance%20part&width=300&height=300&seq=sample_image_1&orientation=squarish`,
      `https://readdy.ai/api/search-image?query=Nissan%20brake%20pads%20automotive%20parts%2C%20car%20brake%20system%20components%2C%20professional%20product%20photography%2C%20automotive%20spare%20parts%2C%20high%20quality%20brake%20parts&width=300&height=300&seq=sample_image_2&orientation=squarish`,
      `https://readdy.ai/api/search-image?query=Michelin%20tire%20automotive%20wheel%2C%20car%20tire%20product%20photography%2C%20professional%20automotive%20photography%2C%20tire%20details%2C%20high%20quality%20automotive%20tire&width=300&height=300&seq=sample_image_3&orientation=squarish`
    ];
    setUploadedImages(sampleImages);
    setShowImageOptions(false);
  };

  if (!isLoggedIn) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'}`}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className={`${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
            {language === 'ar' ? 'جاري التحقق من تسجيل الدخول...' : 'Checking login...'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`min-h-screen pb-6 ${theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}`}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Navigation Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-green-600 text-white p-4">
        <div className="flex items-center">
          <Link href="/" className={`${isRTL ? 'ml-3' : 'mr-3'}`}>
            <i className={`ri-arrow-${isRTL ? 'right' : 'left'}-line text-xl`}></i>
          </Link>
          <h1 className="text-lg font-bold">
            {language === 'ar' ? 'بيع قطعة غيار' : 'Sell Auto Part'}
          </h1>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 px-4 py-6">
        {/* إشعار مدة الصلاحية */}
        <div className="bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mb-6">
          <div className="flex items-start">
            <div className={`w-6 h-6 flex items-center justify-center mt-0.5 ${isRTL ? 'ml-3' : 'mr-3'}`}>
              <i className="ri-information-line text-blue-500 text-lg"></i>
            </div>
            <div>
              <h3 className={`text-sm font-medium mb-1 ${theme === 'dark' ? 'text-blue-200' : 'text-blue-800'}`}>
                {language === 'ar' ? 'معلومات مهمة' : 'Important Information'}
              </h3>
              <p className={`text-sm ${theme === 'dark' ? 'text-blue-300' : 'text-blue-700'}`}>
                {language === 'ar'
                  ? <>سيبقى إعلانك نشطاً لمدة <span className="font-bold">شهرين</span> من تاريخ النشر، وبعدها سينتهي تلقائياً. يمكنك تجديد الإعلان في أي وقت من صفحة إعلاناتي.</>
                  : <>Your ad will remain active for <span className="font-bold">two months</span> from publication date, then expire automatically. You can renew the ad anytime from My Ads page.</>
                }
              </p>
            </div>
          </div>
        </div>

        <div className={`rounded-lg p-6 shadow-sm ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Title with improved placeholder */}
            <div>
              <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                {language === 'ar' ? 'عنوان الإعلان *' : 'Ad Title *'}
              </label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                required
                className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:border-green-500 text-sm ${
                  theme === 'dark'
                    ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                    : 'bg-white border-gray-300 text-gray-900'
                }`}
                placeholder={language === 'ar'
                  ? 'مثال: فلتر هواء محرك تويوتا كامري 2020 - أصلي جديد'
                  : 'Example: Toyota Camry 2020 Original New Air Filter'
                }
                maxLength={100}
              />
              <div className={`text-xs mt-1 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                {formData.title.length}/100 {language === 'ar' ? 'حرف' : 'characters'}
              </div>
            </div>

            {/* Category */}
            <div>
              <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                {language === 'ar' ? 'نوع قطعة الغيار *' : 'Auto Part Category *'}
              </label>
              <select
                name="category"
                value={formData.category}
                onChange={handleInputChange}
                required
                className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:border-green-500 text-sm ${
                  theme === 'dark'
                    ? 'bg-gray-700 border-gray-600 text-white'
                    : 'bg-white border-gray-300 text-gray-900'
                }`}
              >
                <option value="">
                  {language === 'ar' ? '-- اختر نوع القطعة --' : '-- Select Part Type --'}
                </option>
                {categories.map((category, index) => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
              <div className={`text-xs mt-1 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                {language === 'ar' ? 'اختر النوع الأنسب لقطعة الغيار' : 'Choose the most appropriate part type'}
              </div>
            </div>

            {/* Brand and Model */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {language === 'ar' ? 'ماركة السيارة *' : 'Car Brand *'}
                </label>
                <select
                  name="brand"
                  value={formData.brand}
                  onChange={handleInputChange}
                  required
                  className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:border-green-500 text-sm ${
                    theme === 'dark'
                      ? 'bg-gray-700 border-gray-600 text-white'
                      : 'bg-white border-gray-300 text-gray-900'
                  }`}
                >
                  <option value="">
                    {language === 'ar' ? '-- اختر الماركة --' : '-- Select Brand --'}
                  </option>
                  {carBrands.map((brand) => (
                    <option key={brand} value={brand}>{brand}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {language === 'ar' ? 'موديل السيارة *' : 'Car Model *'}
                </label>
                <input
                  type="text"
                  name="model"
                  value={formData.model}
                  onChange={handleInputChange}
                  required
                  className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:border-green-500 text-sm ${
                    theme === 'dark'
                      ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                      : 'bg-white border-gray-300 text-gray-900'
                  }`}
                  placeholder={language === 'ar' ? 'مثال: كامري، أكورد، أكسنت' : 'Example: Camry, Accord, Accent'}
                />
              </div>
            </div>

            {/* Year and Condition */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {language === 'ar' ? 'سنة صنع السيارة *' : 'Car Manufacturing Year *'}
                </label>
                <select
                  name="year"
                  value={formData.year}
                  onChange={handleInputChange}
                  required
                  className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:border-green-500 text-sm ${
                    theme === 'dark'
                      ? 'bg-gray-700 border-gray-600 text-white'
                      : 'bg-white border-gray-300 text-gray-900'
                  }`}
                >
                  <option value="">
                    {language === 'ar' ? '-- اختر السنة --' : '-- Select Year --'}
                  </option>
                  {years.map((year) => (
                    <option key={year} value={year}>{year}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {language === 'ar' ? 'حالة قطعة الغيار *' : 'Part Condition *'}
                </label>
                <select
                  name="condition"
                  value={formData.condition}
                  onChange={handleInputChange}
                  required
                  className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:border-green-500 text-sm ${
                    theme === 'dark'
                      ? 'bg-gray-700 border-gray-600 text-white'
                      : 'bg-white border-gray-300 text-gray-900'
                  }`}
                >
                  <option value="">
                    {language === 'ar' ? '-- اختر الحالة --' : '-- Select Condition --'}
                  </option>
                  {conditions.map((condition) => (
                    <option key={condition} value={condition}>{condition}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Price */}
            <div>
              <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                {language === 'ar' ? 'السعر المطلوب *' : 'Asking Price *'}
              </label>
              <div className="relative">
                <input
                  type="number"
                  name="price"
                  value={formData.price}
                  onChange={handleInputChange}
                  required
                  min="1"
                  className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:border-green-500 text-sm ${
                    isRTL ? 'pl-20' : 'pr-20'
                  } ${
                    theme === 'dark'
                      ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                      : 'bg-white border-gray-300 text-gray-900'
                  }`}
                  placeholder={language === 'ar' ? 'أدخل السعر' : 'Enter price'}
                />
                <div className={`absolute top-1/2 transform -translate-y-1/2 ${isRTL ? 'left-3' : 'right-3'} ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'} text-sm`}>
                  {language === 'ar' ? 'ريال' : 'SAR'}
                </div>
              </div>
              <div className={`text-xs mt-1 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                {language === 'ar' ? 'ضع سعراً مناسباً وقابلاً للتفاوض' : 'Set a reasonable and negotiable price'}
              </div>
            </div>

            {/* Country and City */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {language === 'ar' ? 'الدولة *' : 'Country *'}
                </label>
                <select
                  name="country"
                  value={formData.country}
                  onChange={handleInputChange}
                  required
                  className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:border-green-500 text-sm ${
                    theme === 'dark'
                      ? 'bg-gray-700 border-gray-600 text-white'
                      : 'bg-white border-gray-300 text-gray-900'
                  }`}
                >
                  <option value="">
                    {language === 'ar' ? '-- اختر الدولة --' : '-- Select Country --'}
                  </option>
                  {countries.map((country) => (
                    <option key={country.code} value={country.code}>
                      {country.flag} {country.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {language === 'ar' ? 'المدينة *' : 'City *'}
                </label>
                <input
                  type="text"
                  name="city"
                  value={formData.city}
                  onChange={handleInputChange}
                  required
                  className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:border-green-500 text-sm ${
                    theme === 'dark'
                      ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                      : 'bg-white border-gray-300 text-gray-900'
                  }`}
                  placeholder={language === 'ar' ? 'اكتب اسم المدينة أو المنطقة' : 'Enter city or area name'}
                />
              </div>
            </div>

            {/* Description */}
            <div>
              <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                {language === 'ar' ? 'وصف تفصيلي للقطعة' : 'Detailed Part Description'}
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                rows={4}
                maxLength={500}
                className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:border-green-500 text-sm resize-none ${
                  theme === 'dark'
                    ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                    : 'bg-white border-gray-300 text-gray-900'
                }`}
                placeholder={language === 'ar'
                  ? 'اكتب وصف شامل: حالة القطعة، سبب البيع، رقم القطعة إن وُجد، أي عيوب، تاريخ الشراء...'
                  : 'Write comprehensive description: part condition, reason for selling, part number if available, any defects, purchase date...'}
              />
              <div className={`text-xs mt-1 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                {formData.description.length}/500 {language === 'ar' ? 'حرف' : 'characters'}
              </div>
            </div>

            {/* Contact Information */}
            <div className={`border-t pt-6 ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
              <h3 className={`text-lg font-bold mb-4 ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
                {language === 'ar' ? 'معلومات التواصل' : 'Contact Information'}
              </h3>

              <div className="space-y-4">
                <div>
                  <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                    {language === 'ar' ? 'رقم الواتساب' : 'WhatsApp Number'}
                  </label>
                  <div className="relative">
                    <input
                      type="tel"
                      value={whatsappNumber}
                      onChange={(e) => setWhatsappNumber(e.target.value)}
                      required
                      placeholder="966501234567"
                      className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:border-green-500 text-sm ${
                        isRTL ? 'pr-12' : 'pl-12'
                      } ${
                        theme === 'dark'
                          ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                          : 'bg-white border-gray-300 text-gray-900'
                      }`}
                    />
                    <div className={`absolute top-1/2 transform -translate-y-1/2 w-6 h-6 flex items-center justify-center ${isRTL ? 'right-3' : 'left-3'}`}>
                      <i className="ri-whatsapp-line text-green-500"></i>
                    </div>
                  </div>
                </div>

                <div>
                  <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                    {language === 'ar' ? 'رقم الهاتف للاتصال' : 'Phone Number for Calls'}
                  </label>
                  <div className="relative">
                    <input
                      type="tel"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      required
                      placeholder="966501234567"
                      className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:border-green-500 text-sm ${
                        isRTL ? 'pr-12' : 'pl-12'
                      } ${
                        theme === 'dark'
                          ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                          : 'bg-white border-gray-300 text-gray-900'
                      }`}
                    />
                    <div className={`absolute top-1/2 transform -translate-y-1/2 w-6 h-6 flex items-center justify-center ${isRTL ? 'right-3' : 'left-3'}`}>
                      <i className="ri-phone-line text-blue-500"></i>
                    </div>
                  </div>
                </div>

                <div>
                  <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                    {language === 'ar' ? 'الطريقة المفضلة للتواصل' : 'Preferred Contact Method'}
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setContactMethod('whatsapp')}
                      className={`py-2 px-3 rounded-lg text-sm font-medium transition-all !rounded-button ${
                        contactMethod === 'whatsapp'
                          ? 'bg-green-500 text-white'
                          : theme === 'dark'
                            ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {language === 'ar' ? 'واتساب فقط' : 'WhatsApp Only'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setContactMethod('phone')}
                      className={`py-2 px-3 rounded-lg text-sm font-medium transition-all !rounded-button ${
                        contactMethod === 'phone'
                          ? 'bg-blue-500 text-white'
                          : theme === 'dark'
                            ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {language === 'ar' ? 'اتصال فقط' : 'Calls Only'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setContactMethod('both')}
                      className={`py-2 px-3 rounded-lg text-sm font-medium transition-all !rounded-button ${
                        contactMethod === 'both'
                          ? 'bg-gray-700 text-white'
                          : theme === 'dark'
                            ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {language === 'ar' ? 'الاثنان' : 'Both'}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Images Upload Section */}
            <div>
              <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                {language === 'ar' ? 'الصور' : 'Images'}
              </label>

              {/* Uploaded Images Preview */}
              {uploadedImages.length > 0 && (
                <div className="mb-4">
                  <div className="grid grid-cols-2 gap-4">
                    {uploadedImages.map((image, index) => (
                      <div key={index} className="relative rounded-lg overflow-hidden">
                        <img
                          src={image}
                          alt={`صورة ${index + 1}`}
                          className="w-full h-32 object-cover"
                        />
                        {/* العلامة المائية */}
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                          <div className="bg-black/20 text-white px-3 py-1 rounded text-xs font-medium">
                            <div className="text-center">
                              <div className="mb-1">سكراب كورنر</div>
                              <div>Scrap Corner</div>
                            </div>
                          </div>
                        </div>
                        {/* زر الحذف */}
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute top-2 right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center text-xs hover:bg-red-600 transition-colors"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Image Upload Options */}
              <div className={`border-2 border-dashed rounded-lg p-8 text-center ${
                theme === 'dark' ? 'border-gray-600' : 'border-gray-300'
              }`}>
                <div className={`w-12 h-12 flex items-center justify-center mx-auto mb-4 ${
                  theme === 'dark' ? 'text-gray-500' : 'text-gray-400'
                }`}>
                  <i className="ri-image-add-line text-3xl"></i>
                </div>
                <p className={`text-sm mb-4 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                  {language === 'ar' ? 'أضف صور القطعة' : 'Add part images'}
                </p>

                {/* Image Options Buttons */}
                <div className="flex flex-col space-y-3 max-w-xs mx-auto">
                  <button
                    type="button"
                    onClick={openFileSelector}
                    className="flex items-center justify-center space-x-3 space-x-reverse bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 transition-colors !rounded-button"
                  >
                    <i className="ri-folder-image-line text-lg"></i>
                    <span>{language === 'ar' ? 'اختر من الألبوم' : 'Choose from Album'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={openCamera}
                    className="flex items-center justify-center space-x-3 space-x-reverse bg-green-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-green-700 transition-colors !rounded-button"
                  >
                    <i className="ri-camera-line text-lg"></i>
                    <span>{language === 'ar' ? 'التصوير بالكاميرا' : 'Take Photo'}</span>
                  </button>

                  {/* زر الصور التجريبية - للاختبار */}
                  <button
                    type="button"
                    onClick={generateSampleImages}
                    className={`flex items-center justify-center space-x-3 space-x-reverse py-3 px-4 rounded-lg font-medium transition-colors !rounded-button ${
                      theme === 'dark'
                        ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    <i className="ri-magic-line text-lg"></i>
                    <span>{language === 'ar' ? 'استخدام صور تجريبية' : 'Use Sample Images'}</span>
                  </button>
                </div>

                <p className={`text-xs mt-4 ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
                  {language === 'ar'
                    ? 'الحد الأقصى 5 صور، كل صورة أقل من 5 ميجا'
                    : 'Maximum 5 images, each under 5MB'}
                </p>
                <p className={`text-xs mt-1 ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
                  {language === 'ar'
                    ? 'سيتم إضافة علامة "سكراب كورنر" المائية لجميع الصور'
                    : 'Scrap Corner watermark will be added to all images'}
                </p>
              </div>

              {/* Hidden File Inputs */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handleImageUpload}
                className="hidden"
              />
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleCameraCapture}
                className="hidden"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-green-600 text-white py-4 rounded-lg font-medium !rounded-button hover:bg-green-700 transition-colors"
            >
              {language === 'ar' ? 'نشر الإعلان لمدة شهرين' : 'Publish Ad for Two Months'}
            </button>
          </form>
        </div>

        {/* Terms Agreement */}
        <div className={`mt-6 rounded-lg p-6 shadow-sm ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
          <div className="text-center mb-4">
            <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3 ${
              theme === 'dark' ? 'bg-blue-900/30' : 'bg-blue-50'
            }`}>
              <i className="ri-shield-check-line text-2xl text-blue-600"></i>
            </div>
            <h3 className={`text-lg font-bold mb-2 ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
              {language === 'ar' ? 'شروط وأحكام الاستخدام' : 'Terms and Conditions'}
            </h3>
          </div>

          <div className={`space-y-3 text-sm ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
            <div className="flex items-start">
              <div className={`w-5 h-5 flex items-center justify-center mt-0.5 ${isRTL ? 'ml-2' : 'mr-2'} flex-shrink-0`}>
                <i className="ri-check-line text-green-600"></i>
              </div>
              <p>
                {language === 'ar'
                  ? 'أوافق على عدم نشر محتوى مسيء أو مخالف للآداب العامة'
                  : 'I agree not to post offensive or inappropriate content'}
              </p>
            </div>

            <div className="flex items-start">
              <div className={`w-5 h-5 flex items-center justify-center mt-0.5 ${isRTL ? 'ml-2' : 'mr-2'} flex-shrink-0`}>
                <i className="ri-check-line text-green-600"></i>
              </div>
              <p>
                {language === 'ar'
                  ? 'أوافق على عدم التدخل في الأمور الدينية والمعتقدات الشخصية'
                  : 'I agree not to interfere in religious matters and personal beliefs'}
              </p>
            </div>

            <div className="flex items-start">
              <div className={`w-5 h-5 flex items-center justify-center mt-0.5 ${isRTL ? 'ml-2' : 'mr-2'} flex-shrink-0`}>
                <i className="ri-check-line text-green-600"></i>
              </div>
              <p>
                {language === 'ar'
                  ? 'أوافق على عدم استخدام ألفاظ نابية أو شتائم في التعاملات'
                  : 'I agree not to use profanity or insults in dealings'}
              </p>
            </div>

            <div className="flex items-start">
              <div className={`w-5 h-5 flex items-center justify-center mt-0.5 ${isRTL ? 'ml-2' : 'mr-2'} flex-shrink-0`}>
                <i className="ri-check-line text-green-600"></i>
              </div>
              <p>
                {language === 'ar'
                  ? 'أوافق على نشر إعلانات حقيقية وعدم خداع المشترين'
                  : 'I agree to post genuine ads and not deceive buyers'}
              </p>
            </div>

            <div className="flex items-start">
              <div className={`w-5 h-5 flex items-center justify-center mt-0.5 ${isRTL ? 'ml-2' : 'mr-2'} flex-shrink-0`}>
                <i className="ri-check-line text-green-600"></i>
              </div>
              <p>
                {language === 'ar'
                  ? 'أوافق على احترام جميع المستخدمين والتعامل بأدب'
                  : 'I agree to respect all users and deal politely'}
              </p>
            </div>

            <div className="flex items-start">
              <div className={`w-5 h-5 flex items-center justify-center mt-0.5 ${isRTL ? 'ml-2' : 'mr-2'} flex-shrink-0`}>
                <i className="ri-check-line text-green-600"></i>
              </div>
              <p>
                {language === 'ar'
                  ? 'أوافق على عدم نشر محتوى مخالف للقانون أو حقوق الملكية'
                  : 'I agree not to post content that violates law or property rights'}
              </p>
            </div>
          </div>

          <div className={`mt-6 p-4 rounded-lg ${theme === 'dark' ? 'bg-yellow-900/30 border-yellow-800' : 'bg-yellow-50 border-yellow-200'} border`}>
            <div className="flex items-start">
              <div className={`w-6 h-6 flex items-center justify-center mt-0.5 ${isRTL ? 'ml-3' : 'mr-3'}`}>
                <i className="ri-alert-line text-yellow-600"></i>
              </div>
              <div>
                <h4 className={`font-medium mb-1 ${theme === 'dark' ? 'text-yellow-200' : 'text-yellow-800'}`}>
                  {language === 'ar' ? 'تحذير مهم' : 'Important Warning'}
                </h4>
                <p className={`text-sm ${theme === 'dark' ? 'text-yellow-300' : 'text-yellow-700'}`}>
                  {language === 'ar'
                    ? 'أي مخالفة لهذه الشروط قد تؤدي إلى حذف الحساب نهائياً. نحتفظ بحق مراجعة جميع المنشورات.'
                    : 'Any violation of these terms may result in permanent account deletion. We reserve the right to review all posts.'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Terms */}
        <div className="mt-4 px-6">
          <p className={`text-xs text-center leading-5 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
            {language === 'ar' ? (
              <>
                <Link href="/terms" className="text-green-600 hover:underline mx-1">شروط الاستخدام</Link>
                و<Link href="/privacy" className="text-green-600 hover:underline mr-1">سياسة الخصوصية</Link>
              </>
            ) : (
              <>
                <Link href="/terms" className="text-green-600 hover:underline mx-1">Terms of Use</Link>
                and<Link href="/privacy" className="text-green-600 hover:underline ml-1">Privacy Policy</Link>
              </>
            )}
          </p>
          <p className={`text-xs text-center mt-2 ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
            {language === 'ar'
              ? 'الإعلانات تنتهي تلقائياً بعد شهرين من تاريخ النشر'
              : 'Ads expire automatically after two months from publication date'}
          </p>
        </div>
      </div>
    </div>
  );
}

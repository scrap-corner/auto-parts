
'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function MyProducts() {
  const router = useRouter();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState('active');

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';
    if (!loggedIn) {
      sessionStorage.setItem('returnUrl', '/my-products');
      router.push('/login');
      return;
    }
    setIsLoggedIn(true);
  }, [router]);

  // دالة تحويل التاريخ للهجري
  const toHijri = (gregorianDate) => {
    const options = { 
      calendar: 'islamic-umalqura',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      locale: 'ar-SA'
    };
    return new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', options).format(gregorianDate);
  };

  const formatDualDate = (dateString) => {
    const date = new Date();
    const daysAgo = dateString === 'منذ 3 أيام' ? 3 : dateString === 'منذ أسبوع' ? 7 : dateString === 'منذ يوم' ? 1 : 5;
    date.setDate(date.getDate() - daysAgo);
    
    // التاريخ الميلادي
    const gregorian = date.toLocaleDateString('ar-SA', {
      day: 'numeric',
      month: 'short'
    });
    
    // التاريخ الهجري
    const hijri = toHijri(date);
    const hijriShort = hijri.replace(/\d+\s*هـ/, '').trim();
    
    if (daysAgo === 1) {
      return `أمس - ${gregorian} م / ${hijriShort} هـ`;
    } else if (daysAgo < 7) {
      return `منذ ${daysAgo} أيام - ${gregorian} م / ${hijriShort} هـ`;
    } else {
      return `منذ أسبوع - ${gregorian} م / ${hijriShort} هـ`;
    }
  };

  const products = [
    {
      id: 1,
      name: 'فلتر هواء تويوتا كامري 2020',
      price: '45 ريال',
      condition: 'جديد',
      status: 'active',
      views: 45,
      favorites: 12,
      messages: 8,
      image: 'Toyota Camry air filter, clean white background, automotive spare part, professional product photography, premium quality part',
      postedDate: 'منذ 3 أيام'
    },
    {
      id: 2,
      name: 'بطارية سيارة 12 فولت',
      price: '320 ريال',
      condition: 'جديد',
      status: 'sold',
      views: 89,
      favorites: 25,
      messages: 15,
      image: 'Car battery 12 volt automotive component, clean background, professional product photography, premium quality battery',
      postedDate: 'منذ أسبوع'
    },
    {
      id: 3,
      name: 'مرآة جانبية هوندا أكورد',
      price: '85 ريال',
      condition: 'مستعمل - جيد',
      status: 'active',
      views: 23,
      favorites: 5,
      messages: 3,
      image: 'Honda Accord side mirror automotive part, clean background, professional product photography, used car part',
      postedDate: 'منذ يوم'
    },
    {
      id: 4,
      name: 'فرامل أمامية نيسان التيما',
      price: '180 ريال',
      condition: 'جديد',
      status: 'paused',
      views: 67,
      favorites: 18,
      messages: 12,
      image: 'Nissan Altima brake pads automotive parts, clean background, professional product photography, premium brake components',
      postedDate: 'منذ 5 أيام'
    }
  ];

  const filteredProducts = products.filter(product => product.status === activeTab);

  const tabs = [
    { id: 'active', label: 'نشط', count: products.filter(p => p.status === 'active').length },
    { id: 'sold', label: 'مباع', count: products.filter(p => p.status === 'sold').length },
    { id: 'paused', label: 'متوقف', count: products.filter(p => p.status === 'paused').length }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-600 bg-green-100';
      case 'sold': return 'text-blue-600 bg-blue-100';
      case 'paused': return 'text-orange-600 bg-orange-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'نشط';
      case 'sold': return 'مباع';
      case 'paused': return 'متوقف';
      default: return 'غير معروف';
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحقق من تسجيل الدخول...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Navigation Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <Link href="/profile" className="ml-3">
              <i className="ri-arrow-right-line text-xl text-gray-700"></i>
            </Link>
            <h1 className="text-lg font-bold text-gray-800">منتجاتي</h1>
          </div>
          <Link 
            href="/sell"
            className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium !rounded-button"
          >
            إضافة منتج
          </Link>
        </div>
      </div>

      {/* Tabs */}
      <div className="pt-20 px-4 py-4">
        <div className="bg-white rounded-2xl p-1 shadow-sm border border-gray-100 mb-6">
          <div className="grid grid-cols-3 gap-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-3 px-4 rounded-xl text-sm font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                {tab.label} ({tab.count})
              </button>
            ))}
          </div>
        </div>

        {/* Products List */}
        <div className="space-y-4">
          {filteredProducts.map((product) => (
            <div key={product.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-4">
                <div className="flex items-start space-x-4 space-x-reverse mb-4">
                  <div className="w-20 h-20 rounded-2xl overflow-hidden flex-shrink-0">
                    <img 
                      src={`https://readdy.ai/api/search-image?query=${product.image}&width=120&height=120&seq=my_product_${product.id}&orientation=squarish`}
                      alt={product.name}
                      className="w-full h-full object-cover object-top"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-gray-800 text-sm leading-tight">{product.name}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(product.status)}`}>
                        {getStatusText(product.status)}
                      </span>
                    </div>
                    <div className="flex items-center space-x-4 space-x-reverse mb-2">
                      <span className="text-lg font-bold text-emerald-600">{product.price}</span>
                      <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded-full">
                        {product.condition}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500">{formatDualDate(product.postedDate)}</p>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-4 mb-4 bg-gray-50 rounded-xl p-3">
                  <div className="text-center">
                    <div className="text-lg font-bold text-blue-600">{product.views}</div>
                    <div className="text-xs text-gray-600">مشاهدة</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-red-600">{product.favorites}</div>
                    <div className="text-xs text-gray-600">مفضلة</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-green-600">{product.messages}</div>
                    <div className="text-xs text-gray-600">رسالة</div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex space-x-3 space-x-reverse">
                  <Link 
                    href={`/product/${product.id}`}
                    className="flex-1 bg-blue-50 text-blue-600 py-2 px-4 rounded-lg text-sm font-medium text-center !rounded-button"
                  >
                    عرض
                  </Link>
                  <Link 
                    href={`/edit-product/${product.id}`}
                    className="flex-1 bg-gray-50 text-gray-700 py-2 px-4 rounded-lg text-sm font-medium text-center !rounded-button"
                  >
                    تعديل
                  </Link>
                  {product.status === 'active' ? (
                    <button className="flex-1 bg-orange-50 text-orange-600 py-2 px-4 rounded-lg text-sm font-medium !rounded-button">
                      إيقاف
                    </button>
                  ) : product.status === 'paused' ? (
                    <button className="flex-1 bg-green-50 text-green-600 py-2 px-4 rounded-lg text-sm font-medium !rounded-button">
                      تفعيل
                    </button>
                  ) : (
                    <button className="flex-1 bg-red-50 text-red-600 py-2 px-4 rounded-lg text-sm font-medium !rounded-button">
                      حذف
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredProducts.length === 0 && (
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-product-hunt-line text-3xl text-gray-400"></i>
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">لا توجد منتجات</h3>
            <p className="text-gray-500 text-sm mb-6">
              {activeTab === 'active' && 'لم تقم بنشر أي منتجات نشطة بعد'}
              {activeTab === 'sold' && 'لم تقم ببيع أي منتجات بعد'}
              {activeTab === 'paused' && 'لا توجد منتجات متوقفة'}
            </p>
            <Link 
              href="/sell"
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-medium !rounded-button inline-block"
            >
              إضافة منتج جديد
            </Link>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
        <div className="grid grid-cols-5 py-2">
          <Link href="/" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-home-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">الرئيسية</span>
          </Link>
          <Link href="/search" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-search-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">البحث</span>
          </Link>
          <Link href="/chat" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center relative">
              <i className="ri-chat-3-line text-lg"></i>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                <span className="text-xs text-white font-bold">3</span>
              </div>
            </div>
            <span className="text-xs mt-1">المحادثات</span>
          </Link>
          <Link href="/favorites" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-heart-line text-lg"></i>
            </div>
            <span className="text-xs mt-1">المفضلة</span>
          </Link>
          <Link href="/profile" className="flex flex-col items-center py-2 text-blue-600">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-user-fill text-lg"></i>
            </div>
            <span className="text-xs mt-1 font-medium">الحساب</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

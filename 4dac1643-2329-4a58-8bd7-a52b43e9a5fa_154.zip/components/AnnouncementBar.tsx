'use client';

import { useState, useEffect } from 'react';
import { useLanguage } from './LanguageProvider';

interface Announcement {
  id: string;
  message: string;
  messageEn: string;
  type: 'info' | 'warning' | 'success' | 'promotion';
  icon?: string;
  isActive: boolean;
  link?: string;
  backgroundColor?: string;
  textColor?: string;
  startDate?: string;
  endDate?: string;
}

export default function AnnouncementBar() {
  const { language, theme, isRTL } = useLanguage();
  const [currentAnnouncement, setCurrentAnnouncement] = useState<Announcement | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isEnabled, setIsEnabled] = useState(false);

  // يمكن تغيير هذا إلى true لتفعيل شريط الإعلانات
  const ANNOUNCEMENT_BAR_ENABLED = false;

  // إعلانات تجريبية - في المستقبل ستأتي من قاعدة البيانات أو API
  const announcements: Announcement[] = [
    {
      id: '1',
      message: '🎉 عروض خاصة على قطع غيار BMW - خصم حتى 30%',
      messageEn: '🎉 Special BMW Parts Offers - Up to 30% Off',
      type: 'promotion',
      icon: 'ri-megaphone-line',
      isActive: true,
      link: '/search?category=BMW',
      backgroundColor: '#dc2626',
      textColor: '#ffffff'
    },
    {
      id: '2', 
      message: '⚠️ تحديث مهم: تأكد من التحقق من هوية البائع قبل الشراء',
      messageEn: '⚠️ Important Update: Verify seller identity before purchase',
      type: 'warning',
      icon: 'ri-error-warning-line',
      isActive: true,
      backgroundColor: '#f59e0b',
      textColor: '#ffffff'
    },
    {
      id: '3',
      message: 'ℹ️ خدمة العملاء متاحة 24/7 لمساعدتك',
      messageEn: 'ℹ️ Customer service available 24/7 to help you',
      type: 'info',
      icon: 'ri-customer-service-2-line',
      isActive: true,
      backgroundColor: '#3b82f6',
      textColor: '#ffffff'
    }
  ];

  useEffect(() => {
    setIsEnabled(ANNOUNCEMENT_BAR_ENABLED);
    
    if (ANNOUNCEMENT_BAR_ENABLED) {
      // فلترة الإعلانات النشطة
      const activeAnnouncements = announcements.filter(ann => ann.isActive);
      
      if (activeAnnouncements.length > 0) {
        let currentIndex = 0;
        setCurrentAnnouncement(activeAnnouncements[currentIndex]);
        setIsVisible(true);

        // تغيير الإعلان كل 5 ثواني إذا كان هناك أكثر من إعلان واحد
        if (activeAnnouncements.length > 1) {
          const interval = setInterval(() => {
            currentIndex = (currentIndex + 1) % activeAnnouncements.length;
            setCurrentAnnouncement(activeAnnouncements[currentIndex]);
          }, 5000);

          return () => clearInterval(interval);
        }
      }
    }
  }, []);

  const handleClose = () => {
    setIsVisible(false);
    // حفظ حالة الإغلاق في localStorage
    if (currentAnnouncement) {
      localStorage.setItem(`announcement_closed_${currentAnnouncement.id}`, 'true');
    }
  };

  const handleClick = () => {
    if (currentAnnouncement?.link) {
      window.location.href = currentAnnouncement.link;
    }
  };

  // عدم إظهار الشريط إذا لم يتم تفعيله
  if (!isEnabled || !currentAnnouncement || !isVisible) {
    return null;
  }

  const message = language === 'ar' ? currentAnnouncement.message : currentAnnouncement.messageEn;
  const hasLink = !!currentAnnouncement.link;

  return (
    <div 
      className={`fixed top-16 left-0 right-0 z-40 transition-all duration-300 ${theme === 'dark' ? 'shadow-lg' : 'shadow-sm'}`}
      style={{
        backgroundColor: currentAnnouncement.backgroundColor || '#dc2626',
        color: currentAnnouncement.textColor || '#ffffff'
      }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <div className="px-4 py-2">
        <div className="flex items-center justify-between">
          <div className={`flex items-center flex-1 ${hasLink ? 'cursor-pointer' : ''}`} onClick={hasLink ? handleClick : undefined}>
            {currentAnnouncement.icon && (
              <i className={`${currentAnnouncement.icon} text-sm ${isRTL ? 'ml-2' : 'mr-2'} flex-shrink-0`}></i>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">
                {message}
              </p>
            </div>
            {hasLink && (
              <i className={`ri-external-link-line text-sm ${isRTL ? 'mr-2' : 'ml-2'} flex-shrink-0`}></i>
            )}
          </div>
          
          <button
            onClick={handleClose}
            className={`w-6 h-6 flex items-center justify-center rounded-full hover:bg-black/10 transition-colors ${isRTL ? 'mr-2' : 'ml-2'} flex-shrink-0`}
            aria-label="إغلاق الإعلان"
          >
            <i className="ri-close-line text-sm"></i>
          </button>
        </div>
      </div>

      {/* شريط التقدم للإعلانات المتعددة */}
      {announcements.filter(ann => ann.isActive).length > 1 && (
        <div className="w-full h-0.5 bg-black/20">
          <div 
            className="h-full bg-white/50 transition-all duration-[5000ms] ease-linear"
            style={{ width: '100%' }}
          ></div>
        </div>
      )}
    </div>
  );
}
'use client';

import React from 'react';
import { useLanguage } from './LanguageProvider';

const ThemeSwitcher: React.FC = () => {
  const { theme, setTheme } = useLanguage();

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  return (
    <button
      onClick={toggleTheme}
      className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
        theme === 'dark' 
          ? 'bg-gray-700 hover:bg-gray-600 text-yellow-400' 
          : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
      }`}
    >
      <i className={`text-lg ${theme === 'dark' ? 'ri-sun-line' : 'ri-moon-line'}`}></i>
    </button>
  );
};

export default ThemeSwitcher;

'use client';

import { useState, useEffect } from 'react';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
  duration?: number;
  isVisible?: boolean;
}

interface PushNotificationService {
  isSupported: boolean;
  permission: NotificationPermission;
  subscription: PushSubscription | null;
}

let notificationId = 0;

export const useNotifications = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [pushService, setPushService] = useState<PushNotificationService>({
    isSupported: false,
    permission: 'default',
    subscription: null
  });

  useEffect(() => {
    // فحص دعم الإشعارات في المتصفح
    if ('Notification' in window && 'serviceWorker' in navigator) {
      setPushService(prev => ({
        ...prev,
        isSupported: true,
        permission: Notification.permission
      }));

      // تسجيل Service Worker
      registerServiceWorker();
    }
  }, []);

  const registerServiceWorker = async () => {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js');
      console.log('✅ تم تسجيل Service Worker بنجاح');

      // الاشتراك في الإشعارات الخارجية
      if (Notification.permission === 'granted') {
        subscribeToNotifications(registration);
      }
    } catch (error) {
      console.error('❌ خطأ في تسجيل Service Worker:', error);
    }
  };

  const requestNotificationPermission = async () => {
    if (!pushService.isSupported) {
      console.log('الإشعارات غير مدعومة في هذا المتصفح');
      return false;
    }

    try {
      const permission = await Notification.requestPermission();
      setPushService(prev => ({ ...prev, permission }));

      if (permission === 'granted') {
        console.log('✅ تم منح إذن الإشعارات');

        // تسجيل الاشتراك في الإشعارات
        const registration = await navigator.serviceWorker.ready;
        await subscribeToNotifications(registration);

        return true;
      } else {
        console.log('❌ تم رفض إذن الإشعارات');
        return false;
      }
    } catch (error) {
      console.error('خطأ في طلب إذن الإشعارات:', error);
      return false;
    }
  };

  const subscribeToNotifications = async (registration: ServiceWorkerRegistration) => {
    try {
      // في الإنتاج الحقيقي، ستحتاج إلى VAPID keys من Firebase أو خدمة إشعارات أخرى
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: 'BMxUk2RJt_5sGFEkIXDjBn7CjkuJ7RNhzwH8LQGZ-LH2Rt_4HmWGr7_7hDj4xNm8' // مفتاح تجريبي
      });

      setPushService(prev => ({ ...prev, subscription }));

      // حفظ الاشتراك في localStorage أو إرسال للخادم
      localStorage.setItem('pushSubscription', JSON.stringify(subscription));

      console.log('✅ تم الاشتراك في الإشعارات الخارجية');

      // إشعار ترحيبي
      showExternalNotification(
        'مرحباً بك!',
        'تم تفعيل الإشعارات بنجاح. ستصلك إشعارات عند وصول رسائل جديدة.',
        '/icon-192x192.png'
      );
    } catch (error) {
      console.error('خطأ في الاشتراك في الإشعارات:', error);
    }
  };

  const showExternalNotification = (title: string, message: string, icon?: string) => {
    if (pushService.permission !== 'granted' || !pushService.isSupported) {
      console.log('لا يمكن عرض الإشعار الخارجي - الإذن غير ممنوح');
      return;
    }

    try {
      const notification = new Notification(title, {
        body: message,
        icon: icon || '/icon-192x192.png',
        badge: '/icon-192x192.png',
        tag: 'message-notification',
        requireInteraction: true,
        actions: [
          {
            action: 'view',
            title: 'عرض المحادثة',
            icon: '/icon-192x192.png'
          },
          {
            action: 'dismiss',
            title: 'تجاهل',
            icon: '/icon-192x192.png'
          }
        ],
        data: {
          url: '/chat',
          timestamp: Date.now()
        }
      });

      // معالج النقر على الإشعار
      notification.onclick = function(event) {
        event.preventDefault();
        window.focus();
        window.location.href = '/chat';
        notification.close();
      };

      // إغلاق الإشعار بعد 10 ثوانِ
      setTimeout(() => {
        notification.close();
      }, 10000);
    } catch (error) {
      console.error('خطأ في عرض الإشعار:', error);
    }
  };

  // محاكاة وصول رسالة جديدة
  const simulateNewMessage = (senderName: string, messageText: string, chatId?: string) => {
    // إشعار داخلي في التطبيق
    addNotification({
      title: `رسالة جديدة من ${senderName}`,
      message: messageText,
      type: 'info',
      duration: 6000,
      isVisible: true
    });

    // إشعار خارجي
    showExternalNotification(
      `رسالة جديدة من ${senderName}`,
      messageText.length > 50 ? messageText.substring(0, 50) + '...' : messageText,
      '/icon-192x192.png'
    );

    // تشغيل صوت الإشعار إذا كان متاحاً
    playNotificationSound();

    // حفظ الإشعار في تاريخ الإشعارات
    saveNotificationHistory({
      sender: senderName,
      message: messageText,
      chatId: chatId || '1',
      timestamp: Date.now(),
      read: false
    });
  };

  const playNotificationSound = () => {
    try {
      // في الإنتاج الحقيقي، يمكن استخدام ملف صوتي محفوظ
      const audio = new Audio();
      audio.src = 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmgfBzuB0fDLeCsEKmq+7Z0Bpep0LEXMqjhGMPDyR';
      audio.volume = 0.3;
      audio.play().catch(() => {
        // تجاهل الأخطاء في حالة عدم إمكانية تشغيل الصوت
      });
    } catch (error) {
      // تجاهل أخطاء تشغيل الصوت
    }
  };

  const saveNotificationHistory = (notification: any) => {
    const history = JSON.parse(localStorage.getItem('notificationHistory') || '[]');
    history.unshift(notification);

    // حفظ آخر 50 إشعار فقط
    if (history.length > 50) {
      history.splice(50);
    }

    localStorage.setItem('notificationHistory', JSON.stringify(history));
  };

  const getNotificationHistory = () => {
    return JSON.parse(localStorage.getItem('notificationHistory') || '[]');
  };

  const addNotification = (notification: Omit<Notification, 'id'>) => {
    const id = String(notificationId++);
    const newNotification = { ...notification, id };

    setNotifications(prev => [...prev, newNotification]);

    // إزالة الإشعار بعد المدة المحددة
    setTimeout(() => {
      removeNotification(id);
    }, notification.duration || 5000);

    return id;
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  return {
    notifications,
    addNotification,
    removeNotification,
    pushService,
    requestNotificationPermission,
    showExternalNotification,
    simulateNewMessage,
    getNotificationHistory
  };
};

export default function PushNotifications() {
  const {
    notifications,
    removeNotification,
    pushService,
    requestNotificationPermission,
    simulateNewMessage
  } = useNotifications();

  const [showPermissionPrompt, setShowPermissionPrompt] = useState(false);
  const hasPermission = pushService.permission === 'granted';

  useEffect(() => {
    // عرض طلب الإذن عند تحميل التطبيق للمرة الأولى
    const hasAskedPermission = localStorage.getItem('hasAskedNotificationPermission');
    if (!hasAskedPermission && pushService.isSupported && pushService.permission === 'default') {
      setTimeout(() => {
        setShowPermissionPrompt(true);
      }, 3000); // انتظار 3 ثوانِ قبل عرض الطلب
    }
  }, [pushService]);

  const handlePermissionRequest = async () => {
    const granted = await requestNotificationPermission();
    setShowPermissionPrompt(false);
    localStorage.setItem('hasAskedNotificationPermission', 'true');

    if (granted) {
      // محاكاة رسالة ترحيبية
      setTimeout(() => {
        simulateNewMessage('النظام', 'مرحباً! تم تفعيل الإشعارات بنجاح.');
      }, 2000);
    }
  };

  const getIcon = (type: Notification['type']) => {
    switch (type) {
      case 'success':
        return 'ri-check-line';
      case 'error':
        return 'ri-error-warning-line';
      case 'warning':
        return 'ri-alert-line';
      case 'info':
        return 'ri-information-line';
      default:
        return 'ri-notification-3-line';
    }
  };

  const getColors = (type: Notification['type']) => {
    switch (type) {
      case 'success':
        return 'bg-green-500 border-green-600';
      case 'error':
        return 'bg-red-500 border-red-600';
      case 'warning':
        return 'bg-orange-500 border-orange-600';
      case 'info':
        return 'bg-blue-500 border-blue-600';
      default:
        return 'bg-gray-500 border-gray-600';
    }
  };

  return (
    <>
      {hasPermission && (
        <div>
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className={`fixed top-4 right-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 border border-gray-200 dark:border-gray-700 z-50 max-w-sm transform transition-all duration-300 ${
                notification.isVisible ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-message-3-line text-white text-sm"></i>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-gray-800 dark:text-white text-sm mb-1">
                    {notification.title}
                  </h4>
                  <p className="text-gray-600 dark:text-gray-300 text-xs">
                    {notification.message}
                  </p>
                </div>
                <button
                  onClick={() =>
                    setNotifications((prev) =>
                      prev.filter((n) => n.id !== notification.id)
                    )
                  }
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 flex-shrink-0"
                >
                  <i className="ri-close-line text-sm"></i>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* طلب إذن الإشعارات */}
      {showPermissionPrompt && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-notification-3-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-800 mb-2">تفعيل الإشعارات</h3>
              <p className="text-sm text-gray-600 mb-6">
                احصل على إشعارات فورية عند وصول رسائل جديدة حتى لو كان التطبيق مغلقاً
              </p>
              <div className="flex space-x-3 space-x-reverse">
                <button
                  onClick={() => setShowPermissionPrompt(false)}
                  className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg font-medium hover:bg-gray-300 transition-colors"
                >
                  لاحقاً
                </button>
                <button
                  onClick={handlePermissionRequest}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors !rounded-button"
                >
                  تفعيل الآن
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* زر تجربة الإشعارات (للمطورين فقط - يمكن إزالته في الإنتاج) */}
      {process.env.NODE_ENV === 'development' && false && (
        <button
          onClick={() => simulateNewMessage('أحمد محمد', 'مرحباً، هل قطعة الغيار متوفرة?')}
          className="fixed bottom-24 left-4 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-lg hover:bg-blue-700 transition-colors !rounded-button z-40"
        >
          تجربة إشعار
        </button>
      )}
    </>
  );
}

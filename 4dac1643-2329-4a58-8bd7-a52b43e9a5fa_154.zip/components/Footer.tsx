
'use client';

import { useLanguage } from './LanguageProvider';

export default function Footer() {
  const { language, theme } = useLanguage();

  return (
    <div className={`text-center py-6 pb-28 border-t transition-colors safe-area-bottom ${theme === 'dark' ? 'bg-gray-900 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
      <div className="flex items-center justify-center gap-2 mb-2">
        <div className="w-8 h-8 flex-shrink-0">
          <img
            src="https://static.readdy.ai/image/5aa11a9b42a4af1edfb3496074645b1b/198326fe48900cb832dbc453834b2264.png"
            alt="Logo"
            className="w-full h-full object-contain"
          />
        </div>
        <span className={`text-xs font-medium ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
          {language === 'ar' ? 'مطور بواسطة' : 'Powered by'}
        </span>
      </div>
      <p className={`text-xs ${theme === 'dark' ? 'text-gray-500' : 'text-gray-500'}`}>
        {language === 'ar' ? '© 2024 جميع الحقوق محفوظة' : '© 2024 All Rights Reserved'}
      </p>
    </div>
  );
}

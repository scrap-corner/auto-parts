
'use client';

import { useLanguage } from './LanguageProvider';

interface AppLogoProps {
  size?: 'small' | 'medium' | 'large';
  variant?: 'full' | 'icon' | 'text';
  className?: string;
}

export default function AppLogo({ size = 'medium', variant = 'full', className = '' }: AppLogoProps) {
  const { language, theme } = useLanguage();

  const sizeClasses = {
    small: 'w-10 h-10',
    medium: 'w-14 h-14',
    large: 'w-20 h-20'
  };

  const textSizes = {
    small: 'text-lg',
    medium: 'text-xl',
    large: 'text-3xl'
  };

  if (variant === 'icon') {
    return (
      <div className={`${sizeClasses[size]} relative ${className}`}>
        {/* خلفية الشعار الجديدة مع تدرج أحمر وفضي */}
        <div className="w-full h-full bg-gradient-to-br from-red-500 via-red-600 to-red-700 rounded-2xl shadow-2xl flex items-center justify-center relative overflow-hidden border border-gray-300">
          {/* تأثير معدني فضي */}
          <div className="absolute inset-0 bg-gradient-to-tr from-gray-300/30 via-white/40 to-gray-200/30"></div>
          
          {/* إطار داخلي فضي */}
          <div className="absolute inset-1 border border-gray-300/50 rounded-xl"></div>
          
          {/* أيقونة السيارة الرئيسية */}
          <div className="relative z-10">
            <i className="ri-car-fill text-white text-2xl drop-shadow-lg"></i>
          </div>
          
          {/* أيقونة القطع في الزاوية */}
          <div className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-br from-gray-400 to-gray-600 rounded-full flex items-center justify-center shadow-xl border border-white/30">
            <i className="ri-settings-4-fill text-white text-xs"></i>
          </div>
          
          {/* تفاصيل معدنية */}
          <div className="absolute bottom-2 left-2 w-3 h-3 bg-gray-300/40 rounded-full blur-sm"></div>
          <div className="absolute top-3 left-3 w-1.5 h-1.5 bg-white/60 rounded-full"></div>
          <div className="absolute bottom-1 right-3 w-1 h-1 bg-gray-200/50 rounded-full"></div>
        </div>
      </div>
    );
  }

  if (variant === 'text') {
    return (
      <div className={`font-['Pacifico'] ${textSizes[size]} font-bold bg-gradient-to-r from-red-600 via-red-500 to-red-700 bg-clip-text text-transparent drop-shadow-sm ${className}`}>
        {language === 'ar' ? 'سكراب كورنر' : 'Scrap Corner'}
      </div>
    );
  }

  return (
    <div className={`flex items-center ${className}`}>
      {/* الأيقونة */}
      <div className={`${sizeClasses[size]} relative ${language === 'ar' ? 'ml-3' : 'mr-3'}`}>
        {/* خلفية الشعار الجديدة مع تدرج أحمر وفضي */}
        <div className="w-full h-full bg-gradient-to-br from-red-500 via-red-600 to-red-700 rounded-2xl shadow-2xl flex items-center justify-center relative overflow-hidden border border-gray-300">
          {/* تأثير معدني فضي */}
          <div className="absolute inset-0 bg-gradient-to-tr from-gray-300/30 via-white/40 to-gray-200/30"></div>
          
          {/* إطار داخلي فضي */}
          <div className="absolute inset-1 border border-gray-300/50 rounded-xl"></div>
          
          {/* أيقونة السيارة الرئيسية */}
          <div className="relative z-10">
            <i className={`ri-car-fill text-white drop-shadow-lg ${size === 'large' ? 'text-3xl' : size === 'medium' ? 'text-2xl' : 'text-xl'}`}></i>
          </div>
          
          {/* أيقونة القطع في الزاوية */}
          <div className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-br from-gray-400 to-gray-600 rounded-full flex items-center justify-center shadow-xl border border-white/30">
            <i className="ri-settings-4-fill text-white text-xs"></i>
          </div>
          
          {/* تفاصيل معدنية */}
          <div className="absolute bottom-2 left-2 w-3 h-3 bg-gray-300/40 rounded-full blur-sm"></div>
          <div className="absolute top-3 left-3 w-1.5 h-1.5 bg-white/60 rounded-full"></div>
          <div className="absolute bottom-1 right-3 w-1 h-1 bg-gray-200/50 rounded-full"></div>
        </div>
      </div>
      
      {/* النص */}
      <div className="flex flex-col">
        <div className={`font-['Pacifico'] ${textSizes[size]} font-bold bg-gradient-to-r from-red-600 via-red-500 to-red-700 bg-clip-text text-transparent leading-tight drop-shadow-sm`}>
          {language === 'ar' ? 'سكراب كورنر' : 'Scrap Corner'}
        </div>
        <div className={`text-xs font-semibold mt-0.5 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
          {language === 'ar' ? 'قطع غيار السيارات' : 'Auto Parts Hub'}
        </div>
      </div>
    </div>
  );
}

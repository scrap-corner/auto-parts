'use client';

import { Component, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export default class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: any) {
    console.error('خطأ في التطبيق:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
          <div className="text-center max-w-md">
            <div className="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-error-warning-line text-4xl text-red-500"></i>
            </div>
            
            <h1 className="text-2xl font-bold text-gray-800 mb-4">حدث خطأ غير متوقع</h1>
            <p className="text-gray-600 mb-6">
              نعتذر عن هذا الخطأ. يرجى إعادة تحميل الصفحة أو المحاولة لاحقاً.
            </p>
            
            <div className="space-y-3">
              <button
                onClick={() => window.location.reload()}
                className="w-full bg-blue-600 text-white py-3 px-6 rounded-xl font-medium hover:bg-blue-700 transition-colors !rounded-button"
              >
                إعادة تحميل الصفحة
              </button>
              
              <button
                onClick={() => {
                  this.setState({ hasError: false });
                  window.history.back();
                }}
                className="w-full bg-gray-200 text-gray-700 py-3 px-6 rounded-xl font-medium hover:bg-gray-300 transition-colors !rounded-button"
              >
                العودة للصفحة السابقة
              </button>
            </div>

            <div className="mt-6 p-4 bg-gray-100 rounded-xl text-left">
              <p className="text-xs text-gray-500 mb-2">تفاصيل الخطأ:</p>
              <p className="text-xs font-mono text-gray-700 break-all">
                {this.state.error?.message || 'خطأ غير معروف'}
              </p>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
'use client';

import { useLanguage } from './LanguageProvider';

export default function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();

  return (
    <button
      onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
      className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors"
      title={language === 'ar' ? 'Switch to English' : 'التبديل للعربية'}
    >
      <span className="text-sm font-bold text-gray-700">
        {language === 'ar' ? 'EN' : 'ع'}
      </span>
    </button>
  );
}
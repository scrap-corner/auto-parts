// مكتبة API للتعامل مع قاعدة البيانات في GitHub
'use client';

import { User, Product, Category, CarBrand, CarModel, Chat, Message, Favorite, Report, Notification, Review } from './database';
import { initializeLocalDatabase } from './initDatabase';

// تهيئة قاعدة البيانات عند التحميل
if (typeof window !== 'undefined') {
  initializeLocalDatabase();
}

// دالات مساعدة
const generateId = (): string => {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
};

const getCurrentTimestamp = (): string => {
  return new Date().toISOString();
};

// API للمستخدمين
export const UsersAPI = {
  // الحصول على جميع المستخدمين
  getAll: (): User[] => {
    try {
      return JSON.parse(localStorage.getItem('users') || '[]');
    } catch {
      return [];
    }
  },

  // الحصول على مستخدم بالمعرف
  getById: (id: string): User | null => {
    const users = UsersAPI.getAll();
    return users.find(user => user.id === id) || null;
  },

  // إضافة مستخدم جديد
  create: (userData: Omit<User, 'id' | 'joinDate' | 'lastSeen'>): User => {
    const users = UsersAPI.getAll();
    const newUser: User = {
      ...userData,
      id: generateId(),
      joinDate: getCurrentTimestamp(),
      lastSeen: getCurrentTimestamp()
    };
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    return newUser;
  },

  // تحديث مستخدم
  update: (id: string, updates: Partial<User>): User | null => {
    const users = UsersAPI.getAll();
    const index = users.findIndex(user => user.id === id);
    if (index !== -1) {
      users[index] = { ...users[index], ...updates };
      localStorage.setItem('users', JSON.stringify(users));
      return users[index];
    }
    return null;
  },

  // حذف مستخدم
  delete: (id: string): boolean => {
    const users = UsersAPI.getAll();
    const filteredUsers = users.filter(user => user.id !== id);
    if (filteredUsers.length !== users.length) {
      localStorage.setItem('users', JSON.stringify(filteredUsers));
      return true;
    }
    return false;
  },

  // البحث في المستخدمين
  search: (query: string): User[] => {
    const users = UsersAPI.getAll();
    return users.filter(user => 
      user.name.toLowerCase().includes(query.toLowerCase()) ||
      user.email.toLowerCase().includes(query.toLowerCase()) ||
      user.phone.includes(query)
    );
  },

  // تسجيل الدخول
  login: (phone: string): User | null => {
    const users = UsersAPI.getAll();
    const user = users.find(u => u.phone === phone);
    if (user) {
      // تحديث آخر ظهور وحالة الاتصال
      UsersAPI.update(user.id, {
        lastSeen: getCurrentTimestamp(),
        isOnline: true
      });
      return user;
    }
    return null;
  }
};

// API للمنتجات
export const ProductsAPI = {
  // الحصول على جميع المنتجات
  getAll: (): Product[] => {
    try {
      return JSON.parse(localStorage.getItem('products') || '[]');
    } catch {
      return [];
    }
  },

  // الحصول على منتج بالمعرف
  getById: (id: string): Product | null => {
    const products = ProductsAPI.getAll();
    return products.find(product => product.id === id) || null;
  },

  // إضافة منتج جديد
  create: (productData: Omit<Product, 'id' | 'dateAdded' | 'dateUpdated' | 'views' | 'favorites' | 'reports'>): Product => {
    const products = ProductsAPI.getAll();
    const newProduct: Product = {
      ...productData,
      id: generateId(),
      dateAdded: getCurrentTimestamp(),
      dateUpdated: getCurrentTimestamp(),
      views: 0,
      favorites: 0,
      reports: 0
    };
    products.push(newProduct);
    localStorage.setItem('products', JSON.stringify(products));

    // تحديث عدد المنتجات في الفئة
    CategoriesAPI.updateProductsCount(productData.category, 1);
    
    return newProduct;
  },

  // تحديث منتج
  update: (id: string, updates: Partial<Product>): Product | null => {
    const products = ProductsAPI.getAll();
    const index = products.findIndex(product => product.id === id);
    if (index !== -1) {
      products[index] = { 
        ...products[index], 
        ...updates,
        dateUpdated: getCurrentTimestamp()
      };
      localStorage.setItem('products', JSON.stringify(products));
      return products[index];
    }
    return null;
  },

  // حذف منتج
  delete: (id: string): boolean => {
    const products = ProductsAPI.getAll();
    const product = products.find(p => p.id === id);
    if (product) {
      const filteredProducts = products.filter(p => p.id !== id);
      localStorage.setItem('products', JSON.stringify(filteredProducts));
      
      // تحديث عدد المنتجات في الفئة
      CategoriesAPI.updateProductsCount(product.category, -1);
      return true;
    }
    return false;
  },

  // البحث في المنتجات
  search: (filters: {
    query?: string;
    category?: string;
    brand?: string;
    model?: string;
    year?: string;
    country?: string;
    minPrice?: number;
    maxPrice?: number;
    condition?: string;
    status?: string;
  }): Product[] => {
    let products = ProductsAPI.getAll();

    if (filters.query) {
      products = products.filter(product => 
        product.title.toLowerCase().includes(filters.query!.toLowerCase()) ||
        product.description.toLowerCase().includes(filters.query!.toLowerCase()) ||
        product.tags.some(tag => tag.toLowerCase().includes(filters.query!.toLowerCase()))
      );
    }

    if (filters.category) {
      products = products.filter(product => product.category === filters.category);
    }

    if (filters.brand) {
      products = products.filter(product => product.brand === filters.brand);
    }

    if (filters.model) {
      products = products.filter(product => product.model === filters.model);
    }

    if (filters.year) {
      products = products.filter(product => product.year === filters.year);
    }

    if (filters.country) {
      products = products.filter(product => product.location.country === filters.country);
    }

    if (filters.minPrice !== undefined) {
      products = products.filter(product => product.price >= filters.minPrice!);
    }

    if (filters.maxPrice !== undefined) {
      products = products.filter(product => product.price <= filters.maxPrice!);
    }

    if (filters.condition) {
      products = products.filter(product => product.condition === filters.condition);
    }

    if (filters.status) {
      products = products.filter(product => product.status === filters.status);
    }

    return products;
  },

  // زيادة عدد المشاهدات
  incrementViews: (id: string): void => {
    const product = ProductsAPI.getById(id);
    if (product) {
      ProductsAPI.update(id, { views: product.views + 1 });
    }
  },

  // الحصول على المنتجات حسب البائع
  getBySeller: (sellerId: string): Product[] => {
    const products = ProductsAPI.getAll();
    return products.filter(product => product.sellerId === sellerId);
  }
};

// API للفئات
export const CategoriesAPI = {
  // الحصول على جميع الفئات
  getAll: (): Category[] => {
    try {
      const categories = JSON.parse(localStorage.getItem('categories') || '[]');
      return categories.sort((a: Category, b: Category) => a.order - b.order);
    } catch {
      return [];
    }
  },

  // الحصول على فئة بالمعرف
  getById: (id: string): Category | null => {
    const categories = CategoriesAPI.getAll();
    return categories.find(category => category.id === id) || null;
  },

  // إضافة فئة جديدة
  create: (categoryData: Omit<Category, 'id' | 'productsCount'>): Category => {
    const categories = CategoriesAPI.getAll();
    const newCategory: Category = {
      ...categoryData,
      id: generateId(),
      productsCount: 0
    };
    categories.push(newCategory);
    localStorage.setItem('categories', JSON.stringify(categories));
    return newCategory;
  },

  // تحديث فئة
  update: (id: string, updates: Partial<Category>): Category | null => {
    const categories = CategoriesAPI.getAll();
    const index = categories.findIndex(category => category.id === id);
    if (index !== -1) {
      categories[index] = { ...categories[index], ...updates };
      localStorage.setItem('categories', JSON.stringify(categories));
      return categories[index];
    }
    return null;
  },

  // حذف فئة
  delete: (id: string): boolean => {
    const categories = CategoriesAPI.getAll();
    const filteredCategories = categories.filter(category => category.id !== id);
    if (filteredCategories.length !== categories.length) {
      localStorage.setItem('categories', JSON.stringify(filteredCategories));
      return true;
    }
    return false;
  },

  // تحديث عدد المنتجات في فئة
  updateProductsCount: (categoryId: string, change: number): void => {
    const category = CategoriesAPI.getById(categoryId);
    if (category) {
      const newCount = Math.max(0, category.productsCount + change);
      CategoriesAPI.update(categoryId, { productsCount: newCount });
    }
  }
};

// API للمفضلة
export const FavoritesAPI = {
  // الحصول على المفضلة لمستخدم
  getUserFavorites: (userId: string): Favorite[] => {
    try {
      const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
      return favorites.filter((fav: Favorite) => fav.userId === userId);
    } catch {
      return [];
    }
  },

  // إضافة إلى المفضلة
  add: (userId: string, productId: string): Favorite => {
    const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    const newFavorite: Favorite = {
      id: generateId(),
      userId,
      productId,
      dateAdded: getCurrentTimestamp()
    };
    favorites.push(newFavorite);
    localStorage.setItem('favorites', JSON.stringify(favorites));
    return newFavorite;
  },

  // إزالة من المفضلة
  remove: (userId: string, productId: string): boolean => {
    const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    const filteredFavorites = favorites.filter((fav: Favorite) => 
      !(fav.userId === userId && fav.productId === productId)
    );
    if (filteredFavorites.length !== favorites.length) {
      localStorage.setItem('favorites', JSON.stringify(filteredFavorites));
      return true;
    }
    return false;
  },

  // التحقق من وجود منتج في المفضلة
  isFavorite: (userId: string, productId: string): boolean => {
    const favorites = FavoritesAPI.getUserFavorites(userId);
    return favorites.some(fav => fav.productId === productId);
  }
};

// API للمحادثات
export const ChatsAPI = {
  // الحصول على محادثات مستخدم
  getUserChats: (userId: string): Chat[] => {
    try {
      const chats = JSON.parse(localStorage.getItem('chats') || '[]');
      return chats.filter((chat: Chat) => chat.participants.includes(userId));
    } catch {
      return [];
    }
  },

  // إنشاء محادثة جديدة
  create: (participants: string[], productId?: string): Chat => {
    const chats = JSON.parse(localStorage.getItem('chats') || '[]');
    const newChat: Chat = {
      id: generateId(),
      participants,
      productId,
      lastMessage: {} as Message,
      unreadCount: {},
      dateCreated: getCurrentTimestamp(),
      dateUpdated: getCurrentTimestamp(),
      isActive: true
    };
    
    // تهيئة عدد الرسائل غير المقروءة
    participants.forEach(participantId => {
      newChat.unreadCount[participantId] = 0;
    });
    
    chats.push(newChat);
    localStorage.setItem('chats', JSON.stringify(chats));
    return newChat;
  },

  // تحديث محادثة
  update: (id: string, updates: Partial<Chat>): Chat | null => {
    const chats = JSON.parse(localStorage.getItem('chats') || '[]');
    const index = chats.findIndex((chat: Chat) => chat.id === id);
    if (index !== -1) {
      chats[index] = { 
        ...chats[index], 
        ...updates,
        dateUpdated: getCurrentTimestamp()
      };
      localStorage.setItem('chats', JSON.stringify(chats));
      return chats[index];
    }
    return null;
  }
};

// API للرسائل
export const MessagesAPI = {
  // الحصول على رسائل محادثة
  getChatMessages: (chatId: string): Message[] => {
    try {
      const messages = JSON.parse(localStorage.getItem('messages') || '[]');
      return messages.filter((msg: Message) => msg.chatId === chatId);
    } catch {
      return [];
    }
  },

  // إرسال رسالة
  send: (messageData: Omit<Message, 'id' | 'timestamp' | 'isRead'>): Message => {
    const messages = JSON.parse(localStorage.getItem('messages') || '[]');
    const newMessage: Message = {
      ...messageData,
      id: generateId(),
      timestamp: getCurrentTimestamp(),
      isRead: false
    };
    messages.push(newMessage);
    localStorage.setItem('messages', JSON.stringify(messages));

    // تحديث آخر رسالة في المحادثة
    ChatsAPI.update(messageData.chatId, { lastMessage: newMessage });
    
    return newMessage;
  }
};

// API للإشعارات
export const NotificationsAPI = {
  // الحصول على إشعارات مستخدم
  getUserNotifications: (userId: string): Notification[] => {
    try {
      const notifications = JSON.parse(localStorage.getItem('notifications') || '[]');
      return notifications.filter((notif: Notification) => notif.userId === userId);
    } catch {
      return [];
    }
  },

  // إضافة إشعار
  create: (notificationData: Omit<Notification, 'id' | 'dateCreated'>): Notification => {
    const notifications = JSON.parse(localStorage.getItem('notifications') || '[]');
    const newNotification: Notification = {
      ...notificationData,
      id: generateId(),
      dateCreated: getCurrentTimestamp()
    };
    notifications.push(newNotification);
    localStorage.setItem('notifications', JSON.stringify(notifications));
    return newNotification;
  },

  // وضع علامة مقروء على إشعار
  markAsRead: (id: string): boolean => {
    const notifications = JSON.parse(localStorage.getItem('notifications') || '[]');
    const index = notifications.findIndex((notif: Notification) => notif.id === id);
    if (index !== -1) {
      notifications[index].isRead = true;
      localStorage.setItem('notifications', JSON.stringify(notifications));
      return true;
    }
    return false;
  }
};

// API للتقارير
export const ReportsAPI = {
  // الحصول على جميع التقارير
  getAll: (): Report[] => {
    try {
      return JSON.parse(localStorage.getItem('reports') || '[]');
    } catch {
      return [];
    }
  },

  // إضافة تقرير
  create: (reportData: Omit<Report, 'id' | 'dateReported' | 'status'>): Report => {
    const reports = JSON.parse(localStorage.getItem('reports') || '[]');
    const newReport: Report = {
      ...reportData,
      id: generateId(),
      dateReported: getCurrentTimestamp(),
      status: 'pending'
    };
    reports.push(newReport);
    localStorage.setItem('reports', JSON.stringify(reports));
    return newReport;
  }
};

// تصدير جميع APIs
export default {
  UsersAPI,
  ProductsAPI,
  CategoriesAPI,
  FavoritesAPI,
  ChatsAPI,
  MessagesAPI,
  NotificationsAPI,
  ReportsAPI
};
// Database configuration and types for GitHub deployment
export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar?: string;
  country: string;
  joinDate: string;
  status: 'active' | 'blocked' | 'pending';
  isAdmin: boolean;
  productsCount: number;
  rating: number;
  lastSeen: string;
  isOnline: boolean;
}

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  currency: string;
  category: string;
  subcategory?: string;
  brand: string;
  model: string;
  year: string;
  condition: 'new' | 'used' | 'refurbished';
  images: string[];
  sellerId: string;
  location: {
    country: string;
    city: string;
    area?: string;
  };
  status: 'active' | 'pending' | 'rejected' | 'sold' | 'draft';
  dateAdded: string;
  dateUpdated: string;
  views: number;
  favorites: number;
  reports: number;
  specifications?: Record<string, string>;
  tags: string[];
}

export interface Category {
  id: string;
  name: string;
  nameEn: string;
  icon: string;
  color: string;
  description: string;
  parentId?: string;
  isActive: boolean;
  productsCount: number;
  order: number;
}

export interface Chat {
  id: string;
  participants: string[];
  productId?: string;
  lastMessage: Message;
  unreadCount: Record<string, number>;
  dateCreated: string;
  dateUpdated: string;
  isActive: boolean;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  content: string;
  type: 'text' | 'image' | 'product' | 'location' | 'offer';
  timestamp: string;
  isRead: boolean;
  attachments?: {
    type: string;
    url: string;
    name?: string;
  }[];
  metadata?: Record<string, any>;
}

export interface Favorite {
  id: string;
  userId: string;
  productId: string;
  dateAdded: string;
}

export interface Report {
  id: string;
  reporterId: string;
  targetId: string;
  targetType: 'product' | 'user' | 'message';
  reason: string;
  description?: string;
  status: 'pending' | 'reviewed' | 'resolved' | 'dismissed';
  dateReported: string;
  dateResolved?: string;
  resolvedBy?: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'message' | 'product' | 'system' | 'offer';
  isRead: boolean;
  dateCreated: string;
  actionUrl?: string;
  metadata?: Record<string, any>;
}

export interface CarBrand {
  id: string;
  name: string;
  nameEn: string;
  logo?: string;
  isActive: boolean;
  modelsCount: number;
}

export interface CarModel {
  id: string;
  brandId: string;
  name: string;
  nameEn: string;
  years: string[];
  isActive: boolean;
  productsCount: number;
}

export interface Review {
  id: string;
  reviewerId: string;
  reviewedId: string;
  productId?: string;
  rating: number;
  comment?: string;
  dateCreated: string;
  isVisible: boolean;
}

// Database helper functions for localStorage (development only)
export class LocalDatabase {
  private static getItem<T>(key: string, defaultValue: T[]): T[] {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch {
      return defaultValue;
    }
  }

  private static setItem<T>(key: string, value: T[]): void {
    localStorage.setItem(key, JSON.stringify(value));
  }

  // Users
  static getUsers(): User[] {
    return this.getItem('users', []);
  }

  static setUsers(users: User[]): void {
    this.setItem('users', users);
  }

  static addUser(user: User): void {
    const users = this.getUsers();
    users.push(user);
    this.setUsers(users);
  }

  static updateUser(userId: string, updates: Partial<User>): void {
    const users = this.getUsers();
    const index = users.findIndex(u => u.id === userId);
    if (index !== -1) {
      users[index] = { ...users[index], ...updates };
      this.setUsers(users);
    }
  }

  static deleteUser(userId: string): void {
    const users = this.getUsers();
    this.setUsers(users.filter(u => u.id !== userId));
  }

  // Products
  static getProducts(): Product[] {
    return this.getItem('products', []);
  }

  static setProducts(products: Product[]): void {
    this.setItem('products', products);
  }

  static addProduct(product: Product): void {
    const products = this.getProducts();
    products.push(product);
    this.setProducts(products);
  }

  static updateProduct(productId: string, updates: Partial<Product>): void {
    const products = this.getProducts();
    const index = products.findIndex(p => p.id === productId);
    if (index !== -1) {
      products[index] = { ...products[index], ...updates };
      this.setProducts(products);
    }
  }

  static deleteProduct(productId: string): void {
    const products = this.getProducts();
    this.setProducts(products.filter(p => p.id !== productId));
  }

  // Categories
  static getCategories(): Category[] {
    return this.getItem('categories', []);
  }

  static setCategories(categories: Category[]): void {
    this.setItem('categories', categories);
  }

  // Chats
  static getChats(): Chat[] {
    return this.getItem('chats', []);
  }

  static setChats(chats: Chat[]): void {
    this.setItem('chats', chats);
  }

  // Messages
  static getMessages(): Message[] {
    return this.getItem('messages', []);
  }

  static setMessages(messages: Message[]): void {
    this.setItem('messages', messages);
  }

  // Favorites
  static getFavorites(): Favorite[] {
    return this.getItem('favorites', []);
  }

  static setFavorites(favorites: Favorite[]): void {
    this.setItem('favorites', favorites);
  }

  // Reports
  static getReports(): Report[] {
    return this.getItem('reports', []);
  }

  static setReports(reports: Report[]): void {
    this.setItem('reports', reports);
  }

  // Notifications
  static getNotifications(): Notification[] {
    return this.getItem('notifications', []);
  }

  static setNotifications(notifications: Notification[]): void {
    this.setItem('notifications', notifications);
  }

  // Car Brands
  static getCarBrands(): CarBrand[] {
    return this.getItem('carBrands', []);
  }

  static setCarBrands(brands: CarBrand[]): void {
    this.setItem('carBrands', brands);
  }

  // Car Models
  static getCarModels(): CarModel[] {
    return this.getItem('carModels', []);
  }

  static setCarModels(models: CarModel[]): void {
    this.setItem('carModels', models);
  }

  // Reviews
  static getReviews(): Review[] {
    return this.getItem('reviews', []);
  }

  static setReviews(reviews: Review[]): void {
    this.setItem('reviews', reviews);
  }

  // Utility methods
  static generateId(): string {
    return Date.now().toString() + Math.random().toString(36).substr(2, 9);
  }

  static getCurrentUser(): User | null {
    const userData = localStorage.getItem('user');
    if (userData) {
      try {
        return JSON.parse(userData);
      } catch {
        return null;
      }
    }
    return null;
  }

  static isLoggedIn(): boolean {
    return localStorage.getItem('isLoggedIn') === 'true';
  }
}

// Migration functions for initializing database
export const initializeDatabase = () => {
  // Initialize categories if not exist
  const categories = LocalDatabase.getCategories();
  if (categories.length === 0) {
    const defaultCategories: Category[] = [
      {
        id: '1',
        name: 'قطع المحرك',
        nameEn: 'Engine Parts',
        icon: 'ri-settings-4-fill',
        color: 'blue',
        description: 'جميع قطع المحرك والأجزاء المتعلقة به',
        isActive: true,
        productsCount: 0,
        order: 1
      },
      {
        id: '2',
        name: 'نظام الفرامل',
        nameEn: 'Brake System',
        icon: 'ri-stop-circle-fill',
        color: 'red',
        description: 'قطع الفرامل والأقراص والأحذية',
        isActive: true,
        productsCount: 0,
        order: 2
      },
      {
        id: '3',
        name: 'الإطارات والجنوط',
        nameEn: 'Tires & Rims',
        icon: 'ri-steering-2-fill',
        color: 'green',
        description: 'الإطارات والجنوط بجميع الأحجام',
        isActive: true,
        productsCount: 0,
        order: 3
      },
      {
        id: '4',
        name: 'نظام الإضاءة',
        nameEn: 'Lighting System',
        icon: 'ri-lightbulb-fill',
        color: 'yellow',
        description: 'المصابيح والأنوار الأمامية والخلفية',
        isActive: true,
        productsCount: 0,
        order: 4
      },
      {
        id: '5',
        name: 'قطع الهيكل',
        nameEn: 'Body Parts',
        icon: 'ri-car-fill',
        color: 'purple',
        description: 'قطع هيكل السيارة والصدام والأبواب',
        isActive: true,
        productsCount: 0,
        order: 5
      }
    ];
    LocalDatabase.setCategories(defaultCategories);
  }

  // Initialize car brands if not exist
  const brands = LocalDatabase.getCarBrands();
  if (brands.length === 0) {
    const defaultBrands: CarBrand[] = [
      { id: 'toyota', name: 'تويوتا', nameEn: 'Toyota', isActive: true, modelsCount: 0 },
      { id: 'nissan', name: 'نيسان', nameEn: 'Nissan', isActive: true, modelsCount: 0 },
      { id: 'hyundai', name: 'هيونداي', nameEn: 'Hyundai', isActive: true, modelsCount: 0 },
      { id: 'honda', name: 'هوندا', nameEn: 'Honda', isActive: true, modelsCount: 0 },
      { id: 'ford', name: 'فورد', nameEn: 'Ford', isActive: true, modelsCount: 0 },
      { id: 'chevrolet', name: 'شيفروليه', nameEn: 'Chevrolet', isActive: true, modelsCount: 0 }
    ];
    LocalDatabase.setCarBrands(defaultBrands);
  }
};

export default LocalDatabase;
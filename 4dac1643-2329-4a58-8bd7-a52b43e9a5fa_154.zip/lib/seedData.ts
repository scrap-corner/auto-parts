// بيانات أولية لقاعدة البيانات
import { User, Product, Category, CarBrand, CarModel } from './database';

// المستخدمون الأوليون
export const seedUsers: User[] = [
  {
    id: '1',
    name: 'أحمد محمد السعد',
    email: 'ahmed@example.com',
    phone: '96850123456',
    avatar: 'https://readdy.ai/api/search-image?query=Professional%20male%20portrait%2C%20Saudi%20businessman%2C%20realistic%20photography&width=150&height=150&seq=user1&orientation=squarish',
    country: 'OM',
    joinDate: '2024-01-15',
    status: 'active',
    isAdmin: false,
    productsCount: 12,
    rating: 4.8,
    lastSeen: new Date().toISOString(),
    isOnline: true
  },
  {
    id: '2',
    name: 'فاطمة عبدالله',
    email: 'fatima@example.com',
    phone: '96850987654',
    avatar: 'https://readdy.ai/api/search-image?query=Professional%20female%20portrait%2C%20businesswoman%2C%20realistic%20photography&width=150&height=150&seq=user2&orientation=squarish',
    country: 'OM',
    joinDate: '2024-01-20',
    status: 'active',
    isAdmin: false,
    productsCount: 8,
    rating: 4.9,
    lastSeen: new Date(Date.now() - 3600000).toISOString(),
    isOnline: false
  },
  {
    id: 'admin1',
    name: 'مدير النظام',
    email: 'admin@scrapcorner.om',
    phone: '96895977544',
    avatar: 'https://readdy.ai/api/search-image?query=Professional%20admin%20portrait%2C%20system%20administrator&width=150&height=150&seq=admin1&orientation=squarish',
    country: 'OM',
    joinDate: '2024-01-01',
    status: 'active',
    isAdmin: true,
    productsCount: 0,
    rating: 5.0,
    lastSeen: new Date().toISOString(),
    isOnline: true
  }
];

// المنتجات الأولية
export const seedProducts: Product[] = [
  {
    id: '1',
    title: 'محرك تويوتا كامري 2020 - حالة ممتازة',
    description: 'محرك أصلي لتويوتا كامري موديل 2020، تم فحصه بالكامل ويعمل بحالة ممتازة. المحرك سعة 2.5 لتر، 4 سلندر.',
    price: 8500,
    currency: 'OMR',
    category: '1',
    subcategory: 'complete-engine',
    brand: 'toyota',
    model: 'كامري',
    year: '2020',
    condition: 'used',
    images: [
      'https://readdy.ai/api/search-image?query=Toyota%20Camry%20engine%202020%2C%20car%20engine%20parts%2C%20automotive%20engine%2C%20professional%20product%20photography&width=400&height=300&seq=product1_1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Toyota%20Camry%20engine%20close-up%2C%20automotive%20parts%20detail%2C%20car%20engine%20components&width=400&height=300&seq=product1_2&orientation=landscape'
    ],
    sellerId: '1',
    location: {
      country: 'OM',
      city: 'مسقط',
      area: 'الخوير'
    },
    status: 'active',
    dateAdded: '2024-02-01T10:30:00Z',
    dateUpdated: '2024-02-01T10:30:00Z',
    views: 156,
    favorites: 23,
    reports: 0,
    specifications: {
      'الحجم': '2.5 لتر',
      'عدد الأسطوانات': '4',
      'نوع الوقود': 'بنزين',
      'الحالة': 'مستعمل بحالة ممتازة',
      'الكيلومترات': '45,000 كم'
    },
    tags: ['محرك', 'تويوتا', 'كامري', '2020', 'أصلي']
  },
  {
    id: '2',
    title: 'باب أمامي يمين هيونداي النترا 2019',
    description: 'باب أمامي يمين أصلي لهيونداي النترا 2019، بحالة جيدة جداً، اللون أبيض.',
    price: 420,
    currency: 'OMR',
    category: '5',
    subcategory: 'doors',
    brand: 'hyundai',
    model: 'النترا',
    year: '2019',
    condition: 'used',
    images: [
      'https://readdy.ai/api/search-image?query=Hyundai%20Elantra%20front%20door%2C%20car%20door%20parts%2C%20automotive%20parts%2C%20white%20color&width=400&height=300&seq=product2_1&orientation=landscape'
    ],
    sellerId: '2',
    location: {
      country: 'OM',
      city: 'صلالة',
      area: 'السادة'
    },
    status: 'active',
    dateAdded: '2024-02-02T14:20:00Z',
    dateUpdated: '2024-02-02T14:20:00Z',
    views: 89,
    favorites: 12,
    reports: 0,
    specifications: {
      'الموقع': 'أمامي يمين',
      'اللون': 'أبيض',
      'الحالة': 'جيد جداً',
      'يشمل': 'الزجاج والمقبض'
    },
    tags: ['باب', 'هيونداي', 'النترا', '2019', 'أبيض']
  },
  {
    id: '3',
    title: 'إطار ميشلان 225/60 R16 - جديد',
    description: 'إطار ميشلان جديد غير مستعمل، مقاس 225/60 R16، مناسب لمعظم السيارات المتوسطة.',
    price: 95,
    currency: 'OMR',
    category: '3',
    subcategory: 'tires',
    brand: 'michelin',
    model: 'عام',
    year: '2024',
    condition: 'new',
    images: [
      'https://readdy.ai/api/search-image?query=Michelin%20tire%20225%2F60%20R16%2C%20new%20car%20tire%2C%20automotive%20tire%2C%20professional%20product%20photography&width=400&height=300&seq=product3_1&orientation=landscape'
    ],
    sellerId: '1',
    location: {
      country: 'OM',
      city: 'نزوى',
      area: 'المركز'
    },
    status: 'active',
    dateAdded: '2024-02-03T09:15:00Z',
    dateUpdated: '2024-02-03T09:15:00Z',
    views: 234,
    favorites: 45,
    reports: 0,
    specifications: {
      'المقاس': '225/60 R16',
      'الماركة': 'ميشلان',
      'الحالة': 'جديد',
      'نوع المداس': 'صيفي'
    },
    tags: ['إطار', 'ميشلان', 'جديد', '225/60', 'R16']
  }
];

// الفئات الأولية
export const seedCategories: Category[] = [
  {
    id: '1',
    name: 'أجزاء المحرك',
    nameEn: 'Engine Parts',
    icon: 'ri-settings-4-fill',
    color: 'blue',
    description: 'جميع قطع المحرك والأجزاء المتعلقة به من محركات كاملة وقطع غيار',
    isActive: true,
    productsCount: 1,
    order: 1
  },
  {
    id: '2',
    name: 'نظام الفرامل',
    nameEn: 'Brake System',
    icon: 'ri-stop-circle-fill',
    color: 'red',
    description: 'قطع الفرامل والأقراص والأحذية وجميع مكونات نظام الفرامل',
    isActive: true,
    productsCount: 0,
    order: 2
  },
  {
    id: '3',
    name: 'الإطارات والجنوط',
    nameEn: 'Tires & Rims',
    icon: 'ri-steering-2-fill',
    color: 'green',
    description: 'الإطارات والجنوط بجميع الأحجام والماركات',
    isActive: true,
    productsCount: 1,
    order: 3
  },
  {
    id: '4',
    name: 'نظام الإضاءة',
    nameEn: 'Lighting System',
    icon: 'ri-lightbulb-fill',
    color: 'yellow',
    description: 'المصابيح والأنوار الأمامية والخلفية وأنوار الإشارة',
    isActive: true,
    productsCount: 0,
    order: 4
  },
  {
    id: '5',
    name: 'قطع الهيكل',
    nameEn: 'Body Parts',
    icon: 'ri-car-fill',
    color: 'purple',
    description: 'قطع هيكل السيارة والصدام والأبواب والأجنحة',
    isActive: true,
    productsCount: 1,
    order: 5
  },
  {
    id: '6',
    name: 'نظام التكييف',
    nameEn: 'AC System',
    icon: 'ri-temp-cold-fill',
    color: 'cyan',
    description: 'قطع نظام التكييف والتبريد والتدفئة',
    isActive: true,
    productsCount: 0,
    order: 6
  },
  {
    id: '7',
    name: 'ناقل الحركة',
    nameEn: 'Transmission',
    icon: 'ri-roadster-fill',
    color: 'orange',
    description: 'قطع ناقل الحركة اليدوي والأوتوماتيكي',
    isActive: true,
    productsCount: 0,
    order: 7
  },
  {
    id: '8',
    name: 'نظام التعليق',
    nameEn: 'Suspension System',
    icon: 'ri-car-washing-fill',
    color: 'indigo',
    description: 'قطع نظام التعليق والمساعدات والسوست',
    isActive: true,
    productsCount: 0,
    order: 8
  }
];

// ماركات السيارات الأولية
export const seedCarBrands: CarBrand[] = [
  { id: 'toyota', name: 'تويوتا', nameEn: 'Toyota', isActive: true, modelsCount: 20 },
  { id: 'nissan', name: 'نيسان', nameEn: 'Nissan', isActive: true, modelsCount: 18 },
  { id: 'hyundai', name: 'هيونداي', nameEn: 'Hyundai', isActive: true, modelsCount: 15 },
  { id: 'honda', name: 'هوندا', nameEn: 'Honda', isActive: true, modelsCount: 12 },
  { id: 'ford', name: 'فورد', nameEn: 'Ford', isActive: true, modelsCount: 14 },
  { id: 'chevrolet', name: 'شيفروليه', nameEn: 'Chevrolet', isActive: true, modelsCount: 16 },
  { id: 'kia', name: 'كيا', nameEn: 'KIA', isActive: true, modelsCount: 13 },
  { id: 'bmw', name: 'بي إم دبليو', nameEn: 'BMW', isActive: true, modelsCount: 25 },
  { id: 'mercedes', name: 'مرسيدس', nameEn: 'Mercedes-Benz', isActive: true, modelsCount: 30 },
  { id: 'lexus', name: 'لكزس', nameEn: 'Lexus', isActive: true, modelsCount: 18 },
  { id: 'mazda', name: 'مازدا', nameEn: 'Mazda', isActive: true, modelsCount: 10 },
  { id: 'volkswagen', name: 'فولكس فاجن', nameEn: 'Volkswagen', isActive: true, modelsCount: 20 },
  { id: 'audi', name: 'أودي', nameEn: 'Audi', isActive: true, modelsCount: 22 },
  { id: 'mitsubishi', name: 'ميتسوبيشي', nameEn: 'Mitsubishi', isActive: true, modelsCount: 12 },
  { id: 'subaru', name: 'سوبارو', nameEn: 'Subaru', isActive: true, modelsCount: 8 }
];

// موديلات السيارات الأولية
export const seedCarModels: CarModel[] = [
  // موديلات تويوتا
  { id: 'toyota_camry', brandId: 'toyota', name: 'كامري', nameEn: 'Camry', years: ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016', '2015'], isActive: true, productsCount: 1 },
  { id: 'toyota_corolla', brandId: 'toyota', name: 'كورولا', nameEn: 'Corolla', years: ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016', '2015'], isActive: true, productsCount: 0 },
  { id: 'toyota_prado', brandId: 'toyota', name: 'برادو', nameEn: 'Prado', years: ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016', '2015'], isActive: true, productsCount: 0 },
  { id: 'toyota_rav4', brandId: 'toyota', name: 'راف4', nameEn: 'RAV4', years: ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016', '2015'], isActive: true, productsCount: 0 },
  { id: 'toyota_hilux', brandId: 'toyota', name: 'هايلكس', nameEn: 'Hilux', years: ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016', '2015'], isActive: true, productsCount: 0 },

  // موديلات نيسان
  { id: 'nissan_altima', brandId: 'nissan', name: 'ألتيما', nameEn: 'Altima', years: ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016', '2015'], isActive: true, productsCount: 0 },
  { id: 'nissan_patrol', brandId: 'nissan', name: 'باترول', nameEn: 'Patrol', years: ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016', '2015'], isActive: true, productsCount: 0 },
  { id: 'nissan_xtrail', brandId: 'nissan', name: 'إكس تريل', nameEn: 'X-Trail', years: ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016', '2015'], isActive: true, productsCount: 0 },

  // موديلات هيونداي
  { id: 'hyundai_elantra', brandId: 'hyundai', name: 'النترا', nameEn: 'Elantra', years: ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016', '2015'], isActive: true, productsCount: 1 },
  { id: 'hyundai_sonata', brandId: 'hyundai', name: 'سوناتا', nameEn: 'Sonata', years: ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016', '2015'], isActive: true, productsCount: 0 },
  { id: 'hyundai_tucson', brandId: 'hyundai', name: 'توكسون', nameEn: 'Tucson', years: ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016', '2015'], isActive: true, productsCount: 0 },

  // موديلات هوندا
  { id: 'honda_accord', brandId: 'honda', name: 'أكورد', nameEn: 'Accord', years: ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016', '2015'], isActive: true, productsCount: 0 },
  { id: 'honda_civic', brandId: 'honda', name: 'سيفيك', nameEn: 'Civic', years: ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016', '2015'], isActive: true, productsCount: 0 },
  { id: 'honda_crv', brandId: 'honda', name: 'سي آر في', nameEn: 'CR-V', years: ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016', '2015'], isActive: true, productsCount: 0 }
];

// دالة تحميل البيانات الأولية
export const loadSeedData = () => {
  // تحميل المستخدمين
  const existingUsers = JSON.parse(localStorage.getItem('users') || '[]');
  if (existingUsers.length === 0) {
    localStorage.setItem('users', JSON.stringify(seedUsers));
  }

  // تحميل المنتجات
  const existingProducts = JSON.parse(localStorage.getItem('products') || '[]');
  if (existingProducts.length === 0) {
    localStorage.setItem('products', JSON.stringify(seedProducts));
  }

  // تحميل الفئات
  const existingCategories = JSON.parse(localStorage.getItem('categories') || '[]');
  if (existingCategories.length === 0) {
    localStorage.setItem('categories', JSON.stringify(seedCategories));
  }

  // تحميل ماركات السيارات
  const existingBrands = JSON.parse(localStorage.getItem('carBrands') || '[]');
  if (existingBrands.length === 0) {
    localStorage.setItem('carBrands', JSON.stringify(seedCarBrands));
  }

  // تحميل موديلات السيارات
  const existingModels = JSON.parse(localStorage.getItem('carModels') || '[]');
  if (existingModels.length === 0) {
    localStorage.setItem('carModels', JSON.stringify(seedCarModels));
  }

  console.log('تم تحميل البيانات الأولية بنجاح');
};

export default {
  seedUsers,
  seedProducts,
  seedCategories,
  seedCarBrands,
  seedCarModels,
  loadSeedData
};
'use client';

// ملف تهيئة قاعدة البيانات للعمل مع GitHub
import { User, Product, Category, CarBrand, CarModel, Chat, Message, Favorite, Report, Notification, Review } from './database';

// البيانات الأولية للمستخدمين
export const initialUsers: User[] = [
  {
    id: 'admin1',
    name: 'مدير النظام',
    email: 'admin@scrapcorner.om',
    phone: '96895977544',
    avatar: 'https://readdy.ai/api/search-image?query=Professional%20admin%20portrait%2C%20system%20administrator%2C%20business%20professional&width=150&height=150&seq=admin_avatar&orientation=squarish',
    country: 'OM',
    joinDate: '2024-01-01T00:00:00Z',
    status: 'active',
    isAdmin: true,
    productsCount: 0,
    rating: 5.0,
    lastSeen: new Date().toISOString(),
    isOnline: true
  },
  {
    id: 'user1',
    name: 'أحمد محمد السعد',
    email: 'ahmed@example.com',
    phone: '96850123456',
    avatar: 'https://readdy.ai/api/search-image?query=Professional%20male%20portrait%2C%20Saudi%20businessman%2C%20realistic%20photography%2C%20friendly%20face&width=150&height=150&seq=user1_avatar&orientation=squarish',
    country: 'OM',
    joinDate: '2024-01-15T10:30:00Z',
    status: 'active',
    isAdmin: false,
    productsCount: 12,
    rating: 4.8,
    lastSeen: new Date(Date.now() - 1800000).toISOString(), // منذ 30 دقيقة
    isOnline: true
  },
  {
    id: 'user2',
    name: 'فاطمة عبدالله الكندي',
    email: 'fatima@example.com',
    phone: '96850987654',
    avatar: 'https://readdy.ai/api/search-image?query=Professional%20female%20portrait%2C%20businesswoman%2C%20realistic%20photography%2C%20kind%20expression&width=150&height=150&seq=user2_avatar&orientation=squarish',
    country: 'OM',
    joinDate: '2024-01-20T14:20:00Z',
    status: 'active',
    isAdmin: false,
    productsCount: 8,
    rating: 4.9,
    lastSeen: new Date(Date.now() - 3600000).toISOString(), // منذ ساعة
    isOnline: false
  },
  {
    id: 'user3',
    name: 'خالد أحمد الرواحي',
    email: 'khalid@example.com',
    phone: '96851234567',
    avatar: 'https://readdy.ai/api/search-image?query=Professional%20male%20portrait%2C%20young%20businessman%2C%20realistic%20photography%2C%20confident%20look&width=150&height=150&seq=user3_avatar&orientation=squarish',
    country: 'OM',
    joinDate: '2024-01-25T09:15:00Z',
    status: 'active',
    isAdmin: false,
    productsCount: 3,
    rating: 4.2,
    lastSeen: new Date(Date.now() - 7200000).toISOString(), // منذ ساعتين
    isOnline: false
  }
];

// البيانات الأولية للمنتجات
export const initialProducts: Product[] = [
  {
    id: 'prod1',
    title: 'محرك تويوتا كامري 2020 - حالة ممتازة',
    description: 'محرك أصلي لتويوتا كامري موديل 2020، تم فحصه بالكامل ويعمل بحالة ممتازة. المحرك سعة 2.5 لتر، 4 سلندر، بنزين. الكيلومترات 45,000 كم فقط. السعر قابل للتفاوض.',
    price: 3500,
    currency: 'OMR',
    category: '1',
    subcategory: 'complete-engine',
    brand: 'toyota',
    model: 'كامري',
    year: '2020',
    condition: 'used',
    images: [
      'https://readdy.ai/api/search-image?query=Toyota%20Camry%20engine%202020%2C%20car%20engine%20parts%2C%20automotive%20engine%2C%20professional%20product%20photography%2C%20clean%20background&width=600&height=400&seq=engine1_main&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Toyota%20Camry%20engine%20close-up%20detail%2C%20automotive%20parts%2C%20car%20engine%20components%2C%20technical%20view&width=600&height=400&seq=engine1_detail&orientation=landscape'
    ],
    sellerId: 'user1',
    location: {
      country: 'OM',
      city: 'مسقط',
      area: 'الخوير'
    },
    status: 'active',
    dateAdded: '2024-02-01T10:30:00Z',
    dateUpdated: '2024-02-01T10:30:00Z',
    views: 156,
    favorites: 23,
    reports: 0,
    specifications: {
      'الحجم': '2.5 لتر',
      'عدد الأسطوانات': '4',
      'نوع الوقود': 'بنزين',
      'الحالة': 'مستعمل بحالة ممتازة',
      'الكيلومترات': '45,000 كم',
      'رقم المحرك': '2AR-FE',
      'القوة': '178 حصان'
    },
    tags: ['محرك', 'تويوتا', 'كامري', '2020', 'أصلي', 'بنزين']
  },
  {
    id: 'prod2',
    title: 'باب أمامي يمين هيونداي النترا 2019',
    description: 'باب أمامي يمين أصلي لهيونداي النترا 2019، بحالة جيدة جداً، اللون أبيض. يشمل الزجاج والمقبض الداخلي والخارجي. لا يوجد خدوش أو صدأ.',
    price: 420,
    currency: 'OMR',
    category: '5',
    subcategory: 'doors',
    brand: 'hyundai',
    model: 'النترا',
    year: '2019',
    condition: 'used',
    images: [
      'https://readdy.ai/api/search-image?query=Hyundai%20Elantra%20front%20door%20white%20color%2C%20car%20door%20parts%2C%20automotive%20parts%2C%20professional%20product%20photography&width=600&height=400&seq=door1_main&orientation=landscape'
    ],
    sellerId: 'user2',
    location: {
      country: 'OM',
      city: 'صلالة',
      area: 'السادة'
    },
    status: 'active',
    dateAdded: '2024-02-02T14:20:00Z',
    dateUpdated: '2024-02-02T14:20:00Z',
    views: 89,
    favorites: 12,
    reports: 0,
    specifications: {
      'الموقع': 'أمامي يمين',
      'اللون': 'أبيض',
      'الحالة': 'جيد جداً',
      'يشمل': 'الزجاج والمقابض',
      'كود اللون': 'PYW',
      'المادة': 'معدن أصلي'
    },
    tags: ['باب', 'هيونداي', 'النترا', '2019', 'أبيض', 'أمامي']
  },
  {
    id: 'prod3',
    title: 'إطار ميشلان 225/60 R16 - جديد',
    description: 'إطار ميشلان جديد غير مستعمل، مقاس 225/60 R16، مناسب لمعظم السيارات المتوسطة. إطار صيفي عالي الجودة من الوكيل الرسمي.',
    price: 95,
    currency: 'OMR',
    category: '3',
    subcategory: 'tires',
    brand: 'michelin',
    model: 'عام',
    year: '2024',
    condition: 'new',
    images: [
      'https://readdy.ai/api/search-image?query=Michelin%20tire%20225%2F60%20R16%20new%2C%20car%20tire%20automotive%2C%20professional%20product%20photography%2C%20clean%20white%20background&width=600&height=400&seq=tire1_main&orientation=landscape'
    ],
    sellerId: 'user1',
    location: {
      country: 'OM',
      city: 'نزوى',
      area: 'المركز'
    },
    status: 'active',
    dateAdded: '2024-02-03T09:15:00Z',
    dateUpdated: '2024-02-03T09:15:00Z',
    views: 234,
    favorites: 45,
    reports: 0,
    specifications: {
      'المقاس': '225/60 R16',
      'الماركة': 'ميشلان',
      'الحالة': 'جديد',
      'نوع المداس': 'صيفي',
      'مؤشر السرعة': 'H',
      'مؤشر الحمولة': '98',
      'سنة الإنتاج': '2024'
    },
    tags: ['إطار', 'ميشلان', 'جديد', '225/60', 'R16', 'صيفي']
  },
  {
    id: 'prod4',
    title: 'فلتر هواء تويوتا كامري 2020-2022',
    description: 'فلتر هواء أصلي لتويوتا كامري موديلات 2020 إلى 2022، جديد في العلبة الأصلية. يحسن أداء المحرك ويوفر الوقود.',
    price: 25,
    currency: 'OMR',
    category: '1',
    subcategory: 'filters',
    brand: 'toyota',
    model: 'كامري',
    year: '2020',
    condition: 'new',
    images: [
      'https://readdy.ai/api/search-image?query=Toyota%20Camry%20air%20filter%20original%2C%20car%20air%20filter%2C%20automotive%20parts%2C%20product%20photography%20clean%20background&width=600&height=400&seq=filter1_main&orientation=landscape'
    ],
    sellerId: 'user3',
    location: {
      country: 'OM',
      city: 'صحار',
      area: 'الحرة'
    },
    status: 'active',
    dateAdded: '2024-02-04T11:45:00Z',
    dateUpdated: '2024-02-04T11:45:00Z',
    views: 67,
    favorites: 8,
    reports: 0,
    specifications: {
      'النوع': 'فلتر هواء المحرك',
      'الماركة': 'تويوتا أصلي',
      'الحالة': 'جديد',
      'رقم القطعة': '17801-36010',
      'المناسب لـ': 'كامري 2020-2022',
      'المادة': 'ورق مطوي'
    },
    tags: ['فلتر', 'تويوتا', 'كامري', 'هواء', 'جديد', 'أصلي']
  }
];

// البيانات الأولية للفئات
export const initialCategories: Category[] = [
  {
    id: '1',
    name: 'أجزاء المحرك',
    nameEn: 'Engine Parts',
    icon: 'ri-settings-4-fill',
    color: 'blue',
    description: 'جميع قطع المحرك والأجزاء المتعلقة به من محركات كاملة وقطع غيار المحرك',
    isActive: true,
    productsCount: 2,
    order: 1
  },
  {
    id: '2',
    name: 'نظام الفرامل',
    nameEn: 'Brake System',
    icon: 'ri-stop-circle-fill',
    color: 'red',
    description: 'قطع الفرامل والأقراص والأحذية وجميع مكونات نظام الفرامل',
    isActive: true,
    productsCount: 0,
    order: 2
  },
  {
    id: '3',
    name: 'الإطارات والجنوط',
    nameEn: 'Tires & Rims',
    icon: 'ri-steering-2-fill',
    color: 'green',
    description: 'الإطارات والجنوط بجميع الأحجام والماركات المختلفة',
    isActive: true,
    productsCount: 1,
    order: 3
  },
  {
    id: '4',
    name: 'نظام الإضاءة',
    nameEn: 'Lighting System',
    icon: 'ri-lightbulb-fill',
    color: 'yellow',
    description: 'المصابيح والأنوار الأمامية والخلفية وأنوار الإشارة',
    isActive: true,
    productsCount: 0,
    order: 4
  },
  {
    id: '5',
    name: 'قطع الهيكل',
    nameEn: 'Body Parts',
    icon: 'ri-car-fill',
    color: 'purple',
    description: 'قطع هيكل السيارة والصدام والأبواب والأجنحة والمرايا',
    isActive: true,
    productsCount: 1,
    order: 5
  },
  {
    id: '6',
    name: 'نظام التكييف',
    nameEn: 'AC System',
    icon: 'ri-temp-cold-fill',
    color: 'cyan',
    description: 'قطع نظام التكييف والتبريد والتدفئة والمراوح',
    isActive: true,
    productsCount: 0,
    order: 6
  },
  {
    id: '7',
    name: 'ناقل الحركة',
    nameEn: 'Transmission',
    icon: 'ri-roadster-fill',
    color: 'orange',
    description: 'قطع ناقل الحركة اليدوي والأوتوماتيكي والكلتش',
    isActive: true,
    productsCount: 0,
    order: 7
  },
  {
    id: '8',
    name: 'نظام التعليق',
    nameEn: 'Suspension System',
    icon: 'ri-car-washing-fill',
    color: 'indigo',
    description: 'قطع نظام التعليق والمساعدات والسوست والمطاط',
    isActive: true,
    productsCount: 0,
    order: 8
  }
];

// البيانات الأولية لماركات السيارات
export const initialCarBrands: CarBrand[] = [
  { id: 'toyota', name: 'تويوتا', nameEn: 'Toyota', isActive: true, modelsCount: 20 },
  { id: 'nissan', name: 'نيسان', nameEn: 'Nissan', isActive: true, modelsCount: 18 },
  { id: 'hyundai', name: 'هيونداي', nameEn: 'Hyundai', isActive: true, modelsCount: 15 },
  { id: 'honda', name: 'هوندا', nameEn: 'Honda', isActive: true, modelsCount: 12 },
  { id: 'ford', name: 'فورد', nameEn: 'Ford', isActive: true, modelsCount: 14 },
  { id: 'chevrolet', name: 'شيفروليه', nameEn: 'Chevrolet', isActive: true, modelsCount: 16 },
  { id: 'kia', name: 'كيا', nameEn: 'KIA', isActive: true, modelsCount: 13 },
  { id: 'bmw', name: 'بي إم دبليو', nameEn: 'BMW', isActive: true, modelsCount: 25 },
  { id: 'mercedes', name: 'مرسيدس', nameEn: 'Mercedes-Benz', isActive: true, modelsCount: 30 },
  { id: 'lexus', name: 'لكزس', nameEn: 'Lexus', isActive: true, modelsCount: 18 },
  { id: 'mazda', name: 'مازدا', nameEn: 'Mazda', isActive: true, modelsCount: 10 },
  { id: 'volkswagen', name: 'فولكس فاجن', nameEn: 'Volkswagen', isActive: true, modelsCount: 20 },
  { id: 'audi', name: 'أودي', nameEn: 'Audi', isActive: true, modelsCount: 22 },
  { id: 'mitsubishi', name: 'ميتسوبيشي', nameEn: 'Mitsubishi', isActive: true, modelsCount: 12 },
  { id: 'michelin', name: 'ميشلان', nameEn: 'Michelin', isActive: true, modelsCount: 0 }
];

// دالة تهيئة البيانات في localStorage
export const initializeLocalDatabase = () => {
  try {
    // تهيئة المستخدمين
    if (!localStorage.getItem('users')) {
      localStorage.setItem('users', JSON.stringify(initialUsers));
      console.log('✅ تم تهيئة جدول المستخدمين');
    }

    // تهيئة المنتجات
    if (!localStorage.getItem('products')) {
      localStorage.setItem('products', JSON.stringify(initialProducts));
      console.log('✅ تم تهيئة جدول المنتجات');
    }

    // تهيئة الفئات
    if (!localStorage.getItem('categories')) {
      localStorage.setItem('categories', JSON.stringify(initialCategories));
      console.log('✅ تم تهيئة جدول الفئات');
    }

    // تهيئة ماركات السيارات
    if (!localStorage.getItem('carBrands')) {
      localStorage.setItem('carBrands', JSON.stringify(initialCarBrands));
      console.log('✅ تم تهيئة جدول ماركات السيارات');
    }

    // تهيئة الجداول الفارغة
    const emptyTables = ['chats', 'messages', 'favorites', 'reports', 'notifications', 'reviews', 'carModels'];
    
    emptyTables.forEach(table => {
      if (!localStorage.getItem(table)) {
        localStorage.setItem(table, JSON.stringify([]));
        console.log(`✅ تم تهيئة جدول ${table}`);
      }
    });

    console.log('🎉 تم تهيئة قاعدة البيانات بنجاح!');
    
    return true;
  } catch (error) {
    console.error('❌ خطأ في تهيئة قاعدة البيانات:', error);
    return false;
  }
};

// دالة إعادة تعيين البيانات
export const resetDatabase = () => {
  try {
    localStorage.removeItem('users');
    localStorage.removeItem('products');
    localStorage.removeItem('categories');
    localStorage.removeItem('carBrands');
    localStorage.removeItem('chats');
    localStorage.removeItem('messages');
    localStorage.removeItem('favorites');
    localStorage.removeItem('reports');
    localStorage.removeItem('notifications');
    localStorage.removeItem('reviews');
    localStorage.removeItem('carModels');
    
    console.log('🗑️ تم مسح جميع البيانات');
    return initializeLocalDatabase();
  } catch (error) {
    console.error('❌ خطأ في إعادة تعيين قاعدة البيانات:', error);
    return false;
  }
};

// دالة تصدير البيانات لـ GitHub
export const exportDataForGitHub = () => {
  const data = {
    users: JSON.parse(localStorage.getItem('users') || '[]'),
    products: JSON.parse(localStorage.getItem('products') || '[]'),
    categories: JSON.parse(localStorage.getItem('categories') || '[]'),
    carBrands: JSON.parse(localStorage.getItem('carBrands') || '[]'),
    chats: JSON.parse(localStorage.getItem('chats') || '[]'),
    messages: JSON.parse(localStorage.getItem('messages') || '[]'),
    favorites: JSON.parse(localStorage.getItem('favorites') || '[]'),
    reports: JSON.parse(localStorage.getItem('reports') || '[]'),
    notifications: JSON.parse(localStorage.getItem('notifications') || '[]'),
    reviews: JSON.parse(localStorage.getItem('reviews') || '[]'),
    carModels: JSON.parse(localStorage.getItem('carModels') || '[]'),
    exportDate: new Date().toISOString(),
    version: '1.0.0'
  };
  
  const dataStr = JSON.stringify(data, null, 2);
  const dataBlob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(dataBlob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = `scrapcorner-data-${new Date().toISOString().split('T')[0]}.json`;
  link.click();
  
  URL.revokeObjectURL(url);
  console.log('📁 تم تصدير البيانات بنجاح');
};

export default {
  initializeLocalDatabase,
  resetDatabase,
  exportDataForGitHub,
  initialUsers,
  initialProducts,
  initialCategories,
  initialCarBrands
};

// مدير الإشعارات المتقدم
export class NotificationManager {
  private static instance: NotificationManager;
  private subscription: PushSubscription | null = null;
  private isInitialized = false;

  static getInstance(): NotificationManager {
    if (!NotificationManager.instance) {
      NotificationManager.instance = new NotificationManager();
    }
    return NotificationManager.instance;
  }

  // تهيئة نظام الإشعارات
  async initialize(): Promise<boolean> {
    if (this.isInitialized) return true;

    try {
      // فحص دعم الإشعارات
      if (!('Notification' in window) || !('serviceWorker' in navigator)) {
        console.warn('المتصفح لا يدعم الإشعارات');
        return false;
      }

      // تسجيل Service Worker
      const registration = await navigator.serviceWorker.register('/sw.js');
      console.log('تم تسجيل Service Worker بنجاح');

      // طلب إذن الإشعارات
      const permission = await this.requestPermission();
      if (permission !== 'granted') {
        console.warn('لم يتم منح إذن الإشعارات');
        return false;
      }

      // الاشتراك في الإشعارات
      await this.subscribeToNotifications(registration);
      
      this.isInitialized = true;
      return true;
    } catch (error) {
      console.error('خطأ في تهيئة نظام الإشعارات:', error);
      return false;
    }
  }

  // طلب إذن الإشعارات
  async requestPermission(): Promise<NotificationPermission> {
    if (Notification.permission === 'granted') {
      return 'granted';
    }

    const permission = await Notification.requestPermission();
    this.savePermissionStatus(permission);
    return permission;
  }

  // الاشتراك في الإشعارات
  private async subscribeToNotifications(registration: ServiceWorkerRegistration): Promise<void> {
    try {
      // في الإنتاج، ستحتاج لمفتاح VAPID حقيقي من Firebase أو خدمة أخرى
      const vapidKey = 'BMxUk2RJt_5sGFEkIXDjBn7CjkuJ7RNhzwH8LQGZ-LH2Rt_4HmWGr7_7hDj4xNm8';
      
      this.subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: this.urlBase64ToUint8Array(vapidKey)
      });

      // حفظ معلومات الاشتراك
      this.saveSubscription(this.subscription);
      
      console.log('تم الاشتراك في الإشعارات بنجاح');
    } catch (error) {
      console.error('خطأ في الاشتراك:', error);
      throw error;
    }
  }

  // إرسال إشعار محلي
  async showLocalNotification(title: string, options: NotificationOptions = {}): Promise<void> {
    if (Notification.permission !== 'granted') {
      console.warn('ليس لديك إذن لعرض الإشعارات');
      return;
    }

    const defaultOptions: NotificationOptions = {
      icon: '/icon-192x192.png',
      badge: '/icon-192x192.png',
      requireInteraction: true,
      tag: 'scrap-corner-notification',
      ...options
    };

    try {
      const notification = new Notification(title, defaultOptions);
      
      // معالجة النقر على الإشعار
      notification.onclick = () => {
        window.focus();
        if (options.data?.url) {
          window.location.href = options.data.url;
        }
        notification.close();
      };

      // حفظ إحصائية الإشعار
      this.logNotification('local', title, defaultOptions.body || '');

    } catch (error) {
      console.error('خطأ في عرض الإشعار المحلي:', error);
    }
  }

  // إشعار رسالة جديدة
  async showMessageNotification(
    senderName: string, 
    messageText: string, 
    chatId: string, 
    senderAvatar?: string
  ): Promise<void> {
    const title = `رسالة جديدة من ${senderName}`;
    const body = messageText.length > 100 ? messageText.substring(0, 100) + '...' : messageText;

    await this.showLocalNotification(title, {
      body,
      icon: senderAvatar || '/icon-192x192.png',
      tag: `message-${chatId}`,
      data: {
        type: 'message',
        chatId,
        url: `/chat/${chatId}`,
        senderName,
        timestamp: Date.now()
      },
      actions: [
        {
          action: 'reply',
          title: 'رد سريع'
        },
        {
          action: 'view',
          title: 'عرض المحادثة'
        },
        {
          action: 'dismiss',
          title: 'تجاهل'
        }
      ]
    });

    // تشغيل صوت الإشعار
    this.playNotificationSound();
    
    // تحديث عداد الرسائل غير المقروءة
    this.updateUnreadCount();
  }

  // إشعار طلب جديد
  async showOrderNotification(buyerName: string, productName: string, orderId: string): Promise<void> {
    const title = 'طلب شراء جديد';
    const body = `${buyerName} يريد شراء ${productName}`;

    await this.showLocalNotification(title, {
      body,
      tag: `order-${orderId}`,
      data: {
        type: 'order',
        orderId,
        url: `/orders/${orderId}`,
        buyerName,
        productName,
        timestamp: Date.now()
      },
      actions: [
        {
          action: 'accept',
          title: 'قبول الطلب'
        },
        {
          action: 'view',
          title: 'عرض التفاصيل'
        }
      ]
    });
  }

  // إشعار عام
  async showGeneralNotification(title: string, message: string, url?: string): Promise<void> {
    await this.showLocalNotification(title, {
      body: message,
      tag: 'general-notification',
      data: {
        type: 'general',
        url: url || '/',
        timestamp: Date.now()
      }
    });
  }

  // تشغيل صوت الإشعار
  private playNotificationSound(): void {
    try {
      // يمكن استخدام ملف صوتي محفوظ أو صوت نظام
      const audio = new Audio();
      audio.src = 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmgfBzuB0fDLeCsEKmq+7Z0';
      audio.volume = 0.3;
      audio.play().catch(() => {
        // تجاهل أخطاء تشغيل الصوت
      });
    } catch (error) {
      // تجاهل الأخطاء
    }
  }

  // تحديث عداد الرسائل غير المقروءة
  private updateUnreadCount(): void {
    const unreadMessages = this.getUnreadMessagesCount();
    
    // تحديث شارة التطبيق
    if ('setAppBadge' in navigator) {
      (navigator as any).setAppBadge(unreadMessages > 0 ? unreadMessages : null);
    }

    // إرسال رسالة لـ Service Worker
    if (navigator.serviceWorker && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'UPDATE_BADGE',
        count: unreadMessages
      });
    }
  }

  // الحصول على عدد الرسائل غير المقروءة
  private getUnreadMessagesCount(): number {
    try {
      const unreadCount = localStorage.getItem('unreadMessagesCount');
      return unreadCount ? parseInt(unreadCount) : 0;
    } catch {
      return 0;
    }
  }

  // حفظ معلومات الاشتراك
  private saveSubscription(subscription: PushSubscription): void {
    try {
      localStorage.setItem('pushSubscription', JSON.stringify(subscription));
      
      // في التطبيق الحقيقي، يجب إرسال معلومات الاشتراك للخادم
      // this.sendSubscriptionToServer(subscription);
    } catch (error) {
      console.error('خطأ في حفظ الاشتراك:', error);
    }
  }

  // حفظ حالة إذن الإشعارات
  private savePermissionStatus(permission: NotificationPermission): void {
    try {
      localStorage.setItem('notificationPermission', permission);
      localStorage.setItem('permissionRequestTime', Date.now().toString());
    } catch (error) {
      console.error('خطأ في حفظ حالة الإذن:', error);
    }
  }

  // تسجيل إحصائية الإشعار
  private logNotification(type: string, title: string, body: string): void {
    try {
      const notification = {
        type,
        title,
        body,
        timestamp: Date.now(),
        id: this.generateNotificationId()
      };

      const history = JSON.parse(localStorage.getItem('notificationHistory') || '[]');
      history.unshift(notification);
      
      // حفظ آخر 100 إشعار
      if (history.length > 100) {
        history.splice(100);
      }
      
      localStorage.setItem('notificationHistory', JSON.stringify(history));
    } catch (error) {
      console.error('خطأ في تسجيل الإشعار:', error);
    }
  }

  // توليد معرف فريد للإشعار
  private generateNotificationId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  // تحويل VAPID key إلى Uint8Array
  private urlBase64ToUint8Array(base64String: string): Uint8Array {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
      .replace(/\-/g, '+')
      .replace(/_/g, '/');

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);

    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }

  // الحصول على تاريخ الإشعارات
  getNotificationHistory(): any[] {
    try {
      return JSON.parse(localStorage.getItem('notificationHistory') || '[]');
    } catch {
      return [];
    }
  }

  // مسح تاريخ الإشعارات
  clearNotificationHistory(): void {
    localStorage.removeItem('notificationHistory');
  }

  // فحص حالة الإشعارات
  getNotificationStatus(): {
    supported: boolean;
    permission: NotificationPermission;
    subscribed: boolean;
  } {
    return {
      supported: 'Notification' in window,
      permission: 'Notification' in window ? Notification.permission : 'denied',
      subscribed: !!this.subscription
    };
  }
}

// تصدير مثيل واحد للاستخدام العام
export const notificationManager = NotificationManager.getInstance();

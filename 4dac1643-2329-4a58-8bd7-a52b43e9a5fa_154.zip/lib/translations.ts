
export type Language = 'ar' | 'en';

export const translations = {
  ar: {
    // Navigation & Common
    home: 'الرئيسية',
    search: 'البحث',
    chat: 'المحادثات',
    favorites: 'المفضلة',
    profile: 'الحساب',
    back: 'رجوع',
    loading: 'جاري التحميل...',
    welcome: 'مرحباً بك في',

    // App Name & Description
    appName: 'سكراب كورنر',
    appDescription: 'منصة قطع غيار السيارات',
    welcomeMessage: 'ابحث واشتري قطع غيار سيارتك بأفضل الأسعار',

    // Authentication
    login: 'تسجيل الدخول',
    register: 'إنشاء حساب',
    logout: 'تسجيل خروج',
    email: 'البريد الإلكتروني',
    password: 'كلمة المرور',
    fullName: 'الاسم الكامل',
    phone: 'رقم الجوال',
    forgotPassword: 'نسيت كلمة المرور؟',
    noAccount: 'ليس لديك حساب؟',
    haveAccount: 'لديك حساب بالفعل؟',

    // Actions
    sell: 'بيع قطعة',
    buy: 'شراء قطعة',
    sellNow: 'بيع الآن',
    buyNow: 'شراء الآن',
    sellSubtitle: 'اعرض قطعك للبيع',
    buySubtitle: 'ابحث واشتر قطع الغيار',
    viewAll: 'عرض الكل',
    viewMore: 'عرض المزيد',
    viewDetails: 'عرض التفاصيل',
    addProduct: 'إضافة منتج',
    manageProducts: 'إدارة منتجاتي',
    contact: 'تواصل',
    view: 'عرض',
    listProduct: 'أدرج منتجك',

    // Product Info
    price: 'السعر',
    location: 'الموقع',
    condition: 'الحالة',
    seller: 'البائع',
    rating: 'التقييم',
    new: 'جديد',
    usedExcellent: 'مستعمل - ممتاز',
    usedGood: 'مستعمل - جيد',
    discount: 'خصم',

    // Search & Categories
    searchPlaceholder: 'ابحث عن القطعة التي تحتاجها...',
    browseCategories: 'تصفح الأقسام',
    carBrands: 'ماركات السيارات',
    spareParts: 'أقسام قطع الغيار',
    searchResults: 'نتائج البحث',
    noResults: 'لا توجد نتائج مطابقة لبحثك',
    tryDifferentSearch: 'جرب تغيير معايير البحث',
    clearFilters: 'مسح جميع المرشحات',
    browseProducts: 'تصفح المنتجات',

    // Chat
    conversations: 'المحادثات',
    newMessage: 'رسالة جديدة',
    typeMessage: 'اكتب رسالتك...',
    online: 'متصل الآن',
    lastSeen: 'آخر ظهور',
    noConversations: 'لا توجد محادثات',
    startConversation: 'ابدأ محادثة جديدة مع البائعين والمشترين',

    // Profile & Settings
    myAccount: 'حسابي',
    myProducts: 'منتجاتي',
    myPurchases: 'مشترياتي',
    settings: 'الإعدادات',
    support: 'الدعم الفني',
    manageYourProducts: 'إدارة منتجاتك المعروضة',
    purchaseHistory: 'عرض تاريخ المشتريات',
    savedProducts: 'المنتجات المحفوظة',
    accountSettings: 'إعدادات الحساب',
    contactUs: 'تواصل معنا',

    // Stats
    totalProducts: 'منتج متاح',
    activeSellers: 'بائع نشط',
    satisfiedCustomers: 'عميل راضٍ',
    positiveRating: 'تقييم إيجابي',
    platformStats: 'إحصائيات المنصة',

    // Empty States
    noFavorites: 'لا توجد مفضلات',
    noFavoritesMessage: 'لم تقم بإضافة أي منتجات للمفضلة بعد',

    // Common Actions
    save: 'حفظ',
    cancel: 'إلغاء',
    edit: 'تعديل',
    delete: 'حذف',
    confirm: 'تأكيد',
    close: 'إغلاق',

    // Theme & Display
    lightMode: 'النمط الفاتح',
    darkMode: 'النمط الليلي',

    // Notifications
    notifications: 'الإشعارات',
    unreadNotifications: 'إشعار غير مقروء',
    noNotifications: 'لا توجد إشعارات',

    // Country & Location
    selectCountry: 'اختر الدولة',
    currency: 'العملة',

    // Time
    posted: 'تم النشر',
    hourAgo: 'منذ ساعة',
    threeHoursAgo: 'منذ 3 ساعات',
    sixHoursAgo: 'منذ 6 ساعات',
    twelveHoursAgo: 'منذ 12 ساعة',
    yesterday: 'أمس',

    // Featured & Latest
    featuredProducts: 'المنتجات المميزة',
    latestAds: 'أحدث الإعلانات',

    // Car parts categories
    engineParts: 'أجزاء المحرك',
    brakes: 'فرامل',
    tires: 'إطارات',
    lights: 'أنوار',
    ac: 'تكييف',
    transmission: 'ناقل حركة',
    suspension: 'تعليق',
    exhaust: 'عادم',
    fuel: 'وقود',
    cooling: 'تبريد',
    interior: 'داخلية',
    exterior: 'خارجية',

    // Sale page
    sellCarPart: 'بيع قطعة غيار',
    adTitle: 'عنوان الإعلان',
    category: 'القسم',
    chooseCategory: 'اختر القسم',
    brand: 'الماركة',
    chooseBrand: 'اختر الماركة',
    model: 'الموديل',
    year: 'سنة الصنع',
    chooseCondition: 'اختر الحالة',
    priceInSAR: 'السعر (ريال)',
    city: 'المدينة',
    description: 'الوصف',
    contactInfo: 'معلومات التواصل',
    whatsappNumber: 'رقم الواتساب',
    phoneForCalls: 'رقم الهاتف للاتصال',
    preferredContact: 'الطريقة المفضلة للتواصل',
    whatsappOnly: 'واتساب فقط',
    callsOnly: 'اتصال فقط',
    both: 'الاثنان',
    images: 'الصور',
    publishAd: 'نشر الإعلان',
    dragImages: 'اسحب الصور هنا أو',
    browseFiles: 'تصفح الملفات',
    maxImages: 'الحد الأقصى 5 صور، كل صورة أقل من 5 ميجا',

    // Countries
    saudiArabia: 'السعودية',
    uae: 'الإمارات',
    kuwait: 'الكويت',
    qatar: 'قطر',
    bahrain: 'البحرين',
    oman: 'عمان',
    riyal: 'ريال',
    dirham: 'درهم',
    dinar: 'دينار',

    // Car brands
    toyota: 'تويوتا',
    nissan: 'نيسان',
    hyundai: 'هيونداي',
    honda: 'هوندا',
    ford: 'فورد',
    chevrolet: 'شيفروليه',
    kia: 'كيا',
    bmw: 'بي إم دبليو',
    mercedes: 'مرسيدس',
    lexus: 'لكزس',

    // Login page
    signInToContinue: 'سجل دخولك للمتابعة',
    createNewAccount: 'أنشئ حسابك الجديد',
    enterFullName: 'أدخل اسمك الكامل',
    whatsappNumber2: 'رقم الواتساب',
    verificationCodeSent: 'سيتم إرسال كود التحقق على هذا الرقم عبر الواتساب',
    signIn: 'تسجيل الدخول',
    createAccount: 'إنشاء الحساب والتحقق',
    dontHaveAccount: 'ليس لديك حساب؟',
    alreadyHaveAccount: 'لديك حساب بالفعل؟',
    createNewAccount2: 'إنشاء حساب جديد',
    continueWithGoogle: 'المتابعة بحساب جوجل',
    continueWithApple: 'المتابعة بحساب أبل',

    // Results text
    result: 'نتيجة',
    searchingIn: 'البحث في',
    resultsInLocalCurrency: 'النتائج بالعملة المحلية'
  },
  en: {
    // Navigation & Common
    home: 'Home',
    search: 'Search',
    chat: 'Chat',
    favorites: 'Favorites',
    profile: 'Profile',
    back: 'Back',
    loading: 'Loading...',
    welcome: 'Welcome to',

    // App Name & Description
    appName: 'Scrap Corner',
    appDescription: 'Auto Parts Platform',
    welcomeMessage: 'Find and buy auto parts for your car at the best prices',

    // Authentication
    login: 'Login',
    register: 'Sign Up',
    logout: 'Logout',
    email: 'Email',
    password: 'Password',
    fullName: 'Full Name',
    phone: 'Phone Number',
    forgotPassword: 'Forgot Password?',
    noAccount: 'Don\'t have an account?',
    haveAccount: 'Already have an account?',

    // Actions
    sell: 'Sell Part',
    buy: 'Buy Part',
    sellNow: 'Sell Now',
    buyNow: 'Buy Now',
    sellSubtitle: 'List your parts for sale',
    buySubtitle: 'Find and buy auto parts',
    viewAll: 'View All',
    viewMore: 'View More',
    viewDetails: 'View Details',
    addProduct: 'Add Product',
    manageProducts: 'Manage Products',
    contact: 'Contact',
    view: 'View',
    listProduct: 'List Your Product',

    // Product Info
    price: 'Price',
    location: 'Location',
    condition: 'Condition',
    seller: 'Seller',
    rating: 'Rating',
    new: 'New',
    usedExcellent: 'Used - Excellent',
    usedGood: 'Used - Good',
    discount: 'Off',

    // Search & Categories
    searchPlaceholder: 'Search for the part you need...',
    browseCategories: 'Browse Categories',
    carBrands: 'Car Brands',
    spareParts: 'Spare Parts Categories',
    searchResults: 'Search Results',
    noResults: 'No results match your search',
    tryDifferentSearch: 'Try changing search criteria',
    clearFilters: 'Clear All Filters',
    browseProducts: 'Browse Products',

    // Chat
    conversations: 'Conversations',
    newMessage: 'New Message',
    typeMessage: 'Type your message...',
    online: 'Online now',
    lastSeen: 'Last seen',
    noConversations: 'No conversations',
    startConversation: 'Start a new conversation with sellers and buyers',

    // Profile & Settings
    myAccount: 'My Account',
    myProducts: 'My Products',
    myPurchases: 'My Purchases',
    settings: 'Settings',
    support: 'Support',
    manageYourProducts: 'Manage your listed products',
    purchaseHistory: 'View purchase history',
    savedProducts: 'Saved products',
    accountSettings: 'Account settings',
    contactUs: 'Contact us',

    // Stats
    totalProducts: 'Available Products',
    activeSellers: 'Active Sellers',
    satisfiedCustomers: 'Satisfied Customers',
    positiveRating: 'Positive Rating',
    platformStats: 'Platform Statistics',

    // Empty States
    noFavorites: 'No Favorites',
    noFavoritesMessage: 'You haven\'t added any products to favorites yet',

    // Common Actions
    save: 'Save',
    cancel: 'Cancel',
    edit: 'Edit',
    delete: 'Delete',
    confirm: 'Confirm',
    close: 'Close',

    // Theme & Display
    lightMode: 'Light Mode',
    darkMode: 'Dark Mode',

    // Notifications
    notifications: 'Notifications',
    unreadNotifications: 'unread notifications',
    noNotifications: 'No notifications',

    // Country & Location
    selectCountry: 'Select Country',
    currency: 'Currency',

    // Time
    posted: 'Posted',
    hourAgo: '1 hour ago',
    threeHoursAgo: '3 hours ago',
    sixHoursAgo: '6 hours ago',
    twelveHoursAgo: '12 hours ago',
    yesterday: 'Yesterday',

    // Featured & Latest
    featuredProducts: 'Featured Products',
    latestAds: 'Latest Ads',

    // Car parts categories
    engineParts: 'Engine Parts',
    brakes: 'Brakes',
    tires: 'Tires',
    lights: 'Lights',
    ac: 'Air Conditioning',
    transmission: 'Transmission',
    suspension: 'Suspension',
    exhaust: 'Exhaust',
    fuel: 'Fuel System',
    cooling: 'Cooling System',
    interior: 'Interior',
    exterior: 'Exterior',

    // Sale page
    sellCarPart: 'Sell Car Part',
    adTitle: 'Ad Title',
    category: 'Category',
    chooseCategory: 'Choose Category',
    brand: 'Brand',
    chooseBrand: 'Choose Brand',
    model: 'Model',
    year: 'Year',
    chooseCondition: 'Choose Condition',
    priceInSAR: 'Price (SAR)',
    city: 'City',
    description: 'Description',
    contactInfo: 'Contact Information',
    whatsappNumber: 'WhatsApp Number',
    phoneForCalls: 'Phone for Calls',
    preferredContact: 'Preferred Contact Method',
    whatsappOnly: 'WhatsApp Only',
    callsOnly: 'Calls Only',
    both: 'Both',
    images: 'Images',
    publishAd: 'Publish Ad',
    dragImages: 'Drag images here or',
    browseFiles: 'Browse Files',
    maxImages: 'Maximum 5 images, each less than 5MB',

    // Countries
    saudiArabia: 'Saudi Arabia',
    uae: 'UAE',
    kuwait: 'Kuwait',
    qatar: 'Qatar',
    bahrain: 'Bahrain',
    oman: 'Oman',
    riyal: 'Riyal',
    dirham: 'Dirham',
    dinar: 'Dinar',

    // Car brands
    toyota: 'Toyota',
    nissan: 'Nissan',
    hyundai: 'Hyundai',
    honda: 'Honda',
    ford: 'Ford',
    chevrolet: 'Chevrolet',
    kia: 'KIA',
    bmw: 'BMW',
    mercedes: 'Mercedes',
    lexus: 'Lexus',

    // Login page
    signInToContinue: 'Sign in to continue',
    createNewAccount: 'Create your new account',
    enterFullName: 'Enter your full name',
    whatsappNumber2: 'WhatsApp Number',
    verificationCodeSent: 'Verification code will be sent to this number via WhatsApp',
    signIn: 'Sign In',
    createAccount: 'Create Account & Verify',
    dontHaveAccount: 'Don\'t have an account?',
    alreadyHaveAccount: 'Already have an account?',
    createNewAccount2: 'Create New Account',
    continueWithGoogle: 'Continue with Google',
    continueWithApple: 'Continue with Apple',

    // Results text
    result: 'result',
    searchingIn: 'Searching in',
    resultsInLocalCurrency: 'Results in local currency'
  }
};

export const getTranslation = (key: string, language: Language = 'ar') => {
  const keys = key.split('.');
  let value: any = translations[language];

  for (const k of keys) {
    value = value?.[k];
  }

  return value || key;
};
